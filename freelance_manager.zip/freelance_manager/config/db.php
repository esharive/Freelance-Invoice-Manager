<?php
$host = 'localhost';
$user = 'joshuasi_josh'; // must match the MySQL username in cPanel
$pass = 'raMen00d1es.'; // the one you just reset
$dbname = 'joshuasi_invoicedb'; // must match your database name

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die('DB Connection error: ' . $conn->connect_error);
}
?>
