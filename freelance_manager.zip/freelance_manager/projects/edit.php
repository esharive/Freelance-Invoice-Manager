<?php
// projects/edit.php - polished, responsive edit project page
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: /my_works/freelance_manager/login.php');
    exit;
}
require_once __DIR__ . '/../config/db.php';

$uid = (int)($_SESSION['user_id'] ?? 0);
$errors = [];
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$id) {
    header('Location: list.php');
    exit;
}

// helper
function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

// fetch project and verify ownership through clients table
$q = $conn->prepare("
  SELECT p.*, c.user_id
  FROM projects p
  JOIN clients c ON p.client_id = c.id
  WHERE p.id = ? LIMIT 1
");
if (!$q) {
    die('DB error: ' . h($conn->error));
}
$q->bind_param('i', $id);
$q->execute();
$project = $q->get_result()->fetch_assoc();
$q->close();

if (!$project || (int)$project['user_id'] !== $uid) {
    die('Project not found or access denied.');
}

// fetch user's clients for dropdown
$cstmt = $conn->prepare("SELECT id,name FROM clients WHERE user_id=? ORDER BY name ASC");
if (!$cstmt) {
    die('DB error: ' . h($conn->error));
}
$cstmt->bind_param('i', $uid);
$cstmt->execute();
$clients = $cstmt->get_result();

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
}
$csrf_token = $_SESSION['csrf_token'];

// old values (prefill from DB or POST)
$old = [
    'client_id'   => $project['client_id'],
    'title'       => $project['title'],
    'description' => $project['description'],
    'status'      => $project['status'],
    'start_date'  => $project['start_date'],
    'due_date'    => $project['due_date']
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF check
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf_token) {
        $errors[] = 'Invalid request (CSRF). Please reload and try again.';
    }

    $client_id = isset($_POST['client_id']) ? (int)$_POST['client_id'] : 0;
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $status = in_array($_POST['status'] ?? '', ['pending','in_progress','completed']) ? $_POST['status'] : 'pending';
    $start_date = !empty($_POST['start_date']) ? $_POST['start_date'] : null;
    $due_date = !empty($_POST['due_date']) ? $_POST['due_date'] : null;

    // repopulate old values so UI shows submitted values on error
    $old = [
        'client_id' => $client_id,
        'title' => $title,
        'description' => $description,
        'status' => $status,
        'start_date' => $start_date,
        'due_date' => $due_date
    ];

    if (!$client_id || !$title) $errors[] = 'Client and title are required.';

    // verify client belongs to user
    if (empty($errors)) {
        $chk = $conn->prepare("SELECT id FROM clients WHERE id=? AND user_id=? LIMIT 1");
        if (!$chk) {
            $errors[] = 'DB error: ' . h($conn->error);
        } else {
            $chk->bind_param('ii', $client_id, $uid);
            $chk->execute();
            $chk->store_result();
            if ($chk->num_rows === 0) $errors[] = 'Invalid client selection.';
            $chk->close();
        }
    }

    // perform update
    if (empty($errors)) {
        $upd = $conn->prepare("UPDATE projects SET client_id=?, title=?, description=?, status=?, start_date=?, due_date=? WHERE id=?");
        if (!$upd) {
            $errors[] = 'DB error: ' . h($conn->error);
        } else {
            // bind (client_id int, title s, description s, status s, start_date s, due_date s, id int)
            // for null dates, bind_param accepts null as PHP NULL (works with mysqli)
            $upd->bind_param('isssssi', $client_id, $title, $description, $status, $start_date, $due_date, $id);
            if ($upd->execute()) {
                header('Location: list.php');
                exit;
            } else {
                $errors[] = 'Could not update project: ' . h($upd->error);
            }
            $upd->close();
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Edit Project — Freelance Manager</title>

  <!-- styles -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    :root{
      --bg:#f4f7fb; --card:#ffffff; --muted:#6c757d;
      --brand:#0d6efd; --accent:#0b5ed7; --radius:12px;
    }
    body{font-family:'Inter',system-ui,Arial;background:linear-gradient(180deg,var(--bg),#eef4ff);color:#071428;margin:0;}
    .container{max-width:1100px}
    .card-ui{background:var(--card);border-radius:var(--radius);padding:22px;box-shadow:0 12px 36px rgba(11,78,200,0.06);border:1px solid rgba(11,78,200,0.04)}
    .grid{display:grid;grid-template-columns:1fr 380px;gap:20px}
    @media (max-width:991px){ .grid{grid-template-columns:1fr} .preview-card{order:-1} }
    .field {transition:all .22s cubic-bezier(.2,.9,.3,1)}
    .preview-card{background:linear-gradient(180deg,#fff,#fbfdff);border-radius:12px;padding:18px;border:1px solid rgba(11,78,200,0.04)}
    .muted{color:var(--muted)}
    .cta{border-radius:10px;padding:.6rem 1rem}
    .fade-up{opacity:0;transform:translateY(12px);transition:all .44s cubic-bezier(.2,.9,.3,1)}
    .fade-up.in{opacity:1;transform:none}
    .label-small{font-size:.85rem;color:var(--muted)}
    .client-filter {position:relative}
    .char-count{font-size:.82rem;color:var(--muted)}
  </style>
</head>
<body>
  <div class="container py-5">
    <div class="card-ui fade-up in">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
          <h4 class="mb-0">Edit Project</h4>
          <div class="muted small">Project ID: <?php echo h($project['id']); ?></div>
        </div>
        <div>
          <a class="btn btn-outline-secondary btn-sm" href="/my_works/freelance_manager/projects/list.php"><i class="bi bi-arrow-left"></i> Projects</a>
          <a class="btn btn-outline-danger btn-sm" href="/my_works/freelance_manager/logout.php">Logout</a>
        </div>
      </div>

      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
          <strong>Fix the following:</strong>
          <ul class="mb-0">
            <?php foreach ($errors as $err): ?>
              <li><?php echo h($err); ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>

      <div class="grid">
        <!-- form -->
        <div>
          <form method="post" id="editForm" novalidate>
            <input type="hidden" name="csrf_token" value="<?php echo h($csrf_token); ?>">

            <div class="mb-3 field">
              <label class="label-small">Client</label>
              <?php if ($clients->num_rows === 0): ?>
                <div class="alert alert-warning">You have no clients. <a href="/my_works/freelance_manager/clients/add.php">Add a client</a> first.</div>
              <?php else: ?>
                <div class="client-filter mb-2">
                  <input id="clientFilter" class="form-control" placeholder="Filter clients..." type="text" aria-label="Filter clients">
                </div>
                <select name="client_id" id="clientSelect" class="form-select mb-3" required>
                  <option value="">-- choose client --</option>
                  <?php
                    $clients->data_seek(0);
                    while ($c = $clients->fetch_assoc()):
                  ?>
                    <option value="<?php echo (int)$c['id']; ?>" <?php if ((int)$old['client_id'] === (int)$c['id']) echo 'selected'; ?>>
                      <?php echo h($c['name']); ?>
                    </option>
                  <?php endwhile; ?>
                </select>
              <?php endif; ?>
            </div>

            <div class="mb-3 field">
              <label class="label-small">Title</label>
              <input id="title" name="title" value="<?php echo h($old['title']); ?>" class="form-control" required>
            </div>

            <div class="mb-3 field">
              <label class="label-small">Description</label>
              <textarea id="description" name="description" rows="6" class="form-control"><?php echo h($old['description']); ?></textarea>
              <div class="d-flex justify-content-between mt-1">
                <div class="char-count" id="descCount">0 chars</div>
                <div class="muted small">Markdown supported</div>
              </div>
            </div>

            <div class="row g-3">
              <div class="col-md-6 field">
                <label class="label-small">Status</label>
                <select name="status" id="status" class="form-select">
                  <option value="pending" <?php if ($old['status']=='pending') echo 'selected'; ?>>Pending</option>
                  <option value="in_progress" <?php if ($old['status']=='in_progress') echo 'selected'; ?>>In progress</option>
                  <option value="completed" <?php if ($old['status']=='completed') echo 'selected'; ?>>Completed</option>
                </select>
              </div>
              <div class="col-md-3 field">
                <label class="label-small">Start date</label>
                <input type="date" name="start_date" id="start_date" value="<?php echo h($old['start_date']); ?>" class="form-control">
              </div>
              <div class="col-md-3 field">
                <label class="label-small">Due date</label>
                <input type="date" name="due_date" id="due_date" value="<?php echo h($old['due_date']); ?>" class="form-control">
              </div>
            </div>

            <div class="mt-4 d-flex gap-2 align-items-center">
              <button id="saveBtn" type="submit" class="btn btn-primary cta"><i class="bi bi-save me-2"></i> Save changes</button>
              <a href="list.php" class="btn btn-outline-secondary">Cancel</a>
              <div class="ms-auto muted small">Last updated: <?php echo h($project['created_at']); ?></div>
            </div>
          </form>
        </div>

        <!-- preview -->
        <div class="preview-card">
          <div class="d-flex justify-content-between align-items-start mb-2">
            <div>
              <div class="muted small">Live preview</div>
              <div class="h5 mb-1" id="previewTitle"><?php echo h($old['title'] ?: 'Project title'); ?></div>
              <div class="muted small" id="previewClient"><?php
                // show the client name for selected client id (best-effort DB lookup)
                $clientName = 'Client — not selected';
                if ($old['client_id']) {
                    $tmp = $conn->prepare("SELECT name FROM clients WHERE id=? LIMIT 1");
                    if ($tmp) {
                        $tmp->bind_param('i', $old['client_id']);
                        $tmp->execute();
                        $tmpR = $tmp->get_result()->fetch_assoc();
                        if ($tmpR) $clientName = $tmpR['name'];
                        $tmp->close();
                    }
                }
                echo h($clientName);
              ?></div>
            </div>
            <div class="text-end">
              <span class="badge bg-light text-dark" id="previewStatus"><?php echo h(ucfirst(str_replace('_',' ',$old['status']))); ?></span>
            </div>
          </div>

          <hr>

          <div id="previewDesc" class="muted" style="min-height:120px;"><?php echo nl2br(h($old['description'] ?: 'Project description preview. Edit fields to update this live.')); ?></div>

          <div class="mt-3 d-flex justify-content-between small muted">
            <div>Start: <span id="previewStart"><?php echo h($old['start_date'] ?: '—'); ?></span></div>
            <div>Due: <span id="previewDue"><?php echo h($old['due_date'] ?: '—'); ?></span></div>
          </div>

          <div class="mt-3 d-flex gap-2">
            <a class="btn btn-outline-primary btn-sm" id="previewInvoiceBtn" href="#"><i class="bi bi-receipt"></i> Create invoice</a>
            <a class="btn btn-outline-secondary btn-sm" href="/my_works/freelance_manager/projects/list.php"><i class="bi bi-kanban"></i> All projects</a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- scripts -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    (function(){
      // elements
      const title = document.getElementById('title');
      const description = document.getElementById('description');
      const descCount = document.getElementById('descCount');
      const previewTitle = document.getElementById('previewTitle');
      const previewDesc = document.getElementById('previewDesc');
      const clientFilter = document.getElementById('clientFilter');
      const clientSelect = document.getElementById('clientSelect');
      const previewClient = document.getElementById('previewClient');
      const status = document.getElementById('status');
      const previewStatus = document.getElementById('previewStatus');
      const previewStart = document.getElementById('previewStart');
      const previewDue = document.getElementById('previewDue');

      // helpers
      function escapeHtml(s){ return s.replace(/[&<>"']/g, function(m){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]; }); }
      function nl2br(s){ return s.replace(/\n/g,'<br>'); }

      // init counter & preview
      function updateDescCount(){ descCount.textContent = description.value.length + ' chars'; }
      function updatePreviewDesc(){ previewDesc.innerHTML = description.value.trim() ? nl2br(escapeHtml(description.value)) : 'Project description preview. Edit fields to update this live.'; }
      updateDescCount();

      // events
      if (title) title.addEventListener('input', () => { previewTitle.textContent = title.value.trim() || 'Project title'; });

      if (description) {
        description.addEventListener('input', () => { updateDescCount(); updatePreviewDesc(); });
      }

      if (status) status.addEventListener('change', () => { previewStatus.textContent = status.value.replace('_',' '); });

      const startDate = document.getElementById('start_date');
      const dueDate = document.getElementById('due_date');
      if (startDate) startDate.addEventListener('change', () => { previewStart.textContent = startDate.value || '—'; });
      if (dueDate) dueDate.addEventListener('change', () => { previewDue.textContent = dueDate.value || '—'; });

      if (clientFilter && clientSelect) {
        clientFilter.addEventListener('input', function(){
          const q = this.value.trim().toLowerCase();
          Array.from(clientSelect.options).forEach(opt => {
            if (!opt.value) return; // skip placeholder
            const txt = opt.text.toLowerCase();
            opt.style.display = (!q || txt.includes(q)) ? '' : 'none';
          });
        });

        clientSelect.addEventListener('change', function(){
          const txt = clientSelect.options[clientSelect.selectedIndex]?.text || 'Client — not selected';
          previewClient.textContent = txt;
        });
      }

      // form submit UX
      const editForm = document.getElementById('editForm');
      const saveBtn = document.getElementById('saveBtn');
      if (editForm) {
        editForm.addEventListener('submit', function(){
          saveBtn.disabled = true;
          saveBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Saving...';
        });
      }

      // entrance animation (small stagger)
      document.querySelectorAll('.fade-up').forEach((el,i)=> setTimeout(()=> el.classList.add('in'), 80 + i*60));
    })();
  </script>
</body>
</html>
