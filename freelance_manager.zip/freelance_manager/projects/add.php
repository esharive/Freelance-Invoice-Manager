<?php
// projects/add.php - attractive, responsive add-project page
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: /my_works/freelance_manager/login.php');
    exit;
}
require_once __DIR__ . '/../config/db.php';

$uid = (int)($_SESSION['user_id'] ?? 0);
$errors = [];

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
}
$csrf_token = $_SESSION['csrf_token'];

// fetch user's clients for dropdown
$cstmt = $conn->prepare("SELECT id,name FROM clients WHERE user_id=? ORDER BY name ASC");
if (!$cstmt) {
    die('DB error: ' . htmlspecialchars($conn->error));
}
$cstmt->bind_param('i', $uid);
$cstmt->execute();
$clients = $cstmt->get_result();

// helper
function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

// old values
$old = [
    'client_id' => '',
    'title' => '',
    'description' => '',
    'status' => 'pending',
    'start_date' => '',
    'due_date' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf_token) {
        $errors[] = 'Invalid request (CSRF). Please reload the page and try again.';
    }

    $client_id = isset($_POST['client_id']) ? (int)$_POST['client_id'] : 0;
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $status = in_array($_POST['status'] ?? '', ['pending','in_progress','completed']) ? $_POST['status'] : 'pending';
    $start_date = !empty($_POST['start_date']) ? $_POST['start_date'] : null;
    $due_date = !empty($_POST['due_date']) ? $_POST['due_date'] : null;

    // repopulate on error
    $old = [
        'client_id' => $client_id,
        'title' => $title,
        'description' => $description,
        'status' => $status,
        'start_date' => $start_date,
        'due_date' => $due_date
    ];

    if (!$client_id) $errors[] = 'Client is required.';
    if (!$title) $errors[] = 'Project title is required.';

    // check client ownership
    if (empty($errors)) {
        $chk = $conn->prepare("SELECT id FROM clients WHERE id=? AND user_id=? LIMIT 1");
        if (!$chk) { $errors[] = 'DB error: ' . htmlspecialchars($conn->error); }
        else {
            $chk->bind_param('ii', $client_id, $uid);
            $chk->execute();
            $chk->store_result();
            if ($chk->num_rows === 0) $errors[] = 'Invalid client selection.';
            $chk->close();
        }
    }

    if (empty($errors)) {
        $ins = $conn->prepare("INSERT INTO projects (client_id,title,description,status,start_date,due_date,created_at) VALUES (?,?,?,?,?,?,NOW())");
        if (!$ins) {
            $errors[] = 'DB error: ' . htmlspecialchars($conn->error);
        } else {
            $ins->bind_param('isssss', $client_id, $title, $description, $status, $start_date, $due_date);
            if ($ins->execute()) {
                header('Location: list.php');
                exit;
            } else {
                $errors[] = 'Could not create project: ' . htmlspecialchars($ins->error);
            }
            $ins->close();
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Create Project — Freelance Manager</title>

  <!-- Fonts & Bootstrap -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    :root{
      --bg:#f4f7fb; --card:#fff; --muted:#6c757d;
      --brand:#0d6efd; --accent:#0b5ed7; --radius:12px;
    }
    body{font-family:'Inter',system-ui,Arial;background:linear-gradient(180deg,var(--bg),#eef4ff);color:#071428;margin:0;}
    .container{max-width:1100px}
    .topbar{display:flex;align-items:center;justify-content:space-between;padding:18px 0}
    .brand{display:flex;align-items:center;gap:.8rem}
    .brand .logo{width:44px;height:44px;border-radius:10px;background:linear-gradient(135deg,var(--brand),var(--accent));display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800}
    .card-ui{background:var(--card);border-radius:var(--radius);padding:20px;box-shadow:0 10px 30px rgba(11,78,200,0.06);border:1px solid rgba(11,78,200,0.04)}
    .form-grid{display:grid;grid-template-columns:1fr 380px;gap:20px}
    @media (max-width:991px){ .form-grid{grid-template-columns:1fr; } .preview-card{order:-1} }
    label.small{font-size:.85rem;color:var(--muted)}
    .field {transition:all .22s cubic-bezier(.2,.9,.3,1)}
    .field:focus-within{transform:translateY(-3px);box-shadow:0 8px 30px rgba(11,78,200,0.06)}
    .client-select {position:relative}
    .client-filter {position:absolute;right:10px;top:8px;border:0;background:transparent}
    .preview-card{background:linear-gradient(180deg,#fff,#fbfdff);border-radius:12px;padding:18px;border:1px solid rgba(11,78,200,0.04)}
    .preview-ttl{font-weight:700;font-size:1.05rem}
    .muted{color:var(--muted)}
    .cta{border-radius:10px;padding:.6rem 1rem}
    .fade-up{opacity:0;transform:translateY(12px);transition:all .44s cubic-bezier(.2,.9,.3,1)}
    .fade-up.in{opacity:1;transform:none}
    .char-count{font-size:.82rem;color:var(--muted)}
  </style>
</head>
<body>
  <div class="container py-5">
    <!-- top -->
    <div class="topbar fade-up in">
      <div class="brand">
        <div class="logo"><i class="bi bi-kanban-fill"></i></div>
        <div>
          <div style="font-weight:700">Freelance Manager</div>
          <div class="muted small">Create a new project</div>
        </div>
      </div>
      <div class="d-flex align-items-center gap-2">
        <div class="muted small">Signed in as <strong><?php echo h($_SESSION['user_name'] ?? ''); ?></strong></div>
        <a href="/my_works/freelance_manager/logout.php" class="btn btn-outline-secondary btn-sm">Logout</a>
      </div>
    </div>

    <div class="card-ui mt-3 fade-up in" id="mainCard">
      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
          <strong>Fix the following:</strong>
          <ul class="mb-0">
            <?php foreach ($errors as $err): ?>
              <li><?php echo h($err); ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>

      <div class="form-grid">
        <!-- left: form -->
        <div>
          <form method="post" id="projectForm" novalidate>
            <input type="hidden" name="csrf_token" value="<?php echo h($csrf_token); ?>">

            <div class="mb-3 field">
              <label class="form-label small">Client</label>
              <?php if ($clients->num_rows === 0): ?>
                <div class="alert alert-warning">You have no clients. <a href="/my_works/freelance_manager/clients/add.php">Add a client</a> first.</div>
              <?php else: ?>
                <div class="client-select">
                  <input id="clientFilter" class="form-control mb-2" placeholder="Filter clients by name..." type="text" aria-label="Filter clients">
                  <select name="client_id" id="clientSelect" class="form-select" required>
                    <option value="">-- choose client --</option>
                    <?php
                      // rewind result pointer if necessary (some drivers don't allow reusing); we assume fresh
                      $clients->data_seek(0);
                      while ($c = $clients->fetch_assoc()):
                    ?>
                      <option value="<?php echo (int)$c['id']; ?>" <?php if ((int)$old['client_id'] === (int)$c['id']) echo 'selected'; ?>>
                        <?php echo h($c['name']); ?>
                      </option>
                    <?php endwhile; ?>
                  </select>
                </div>
              <?php endif; ?>
            </div>

            <div class="mb-3 field">
              <label class="form-label small">Title</label>
              <input id="title" name="title" value="<?php echo h($old['title']); ?>" class="form-control" placeholder="Project title" required>
            </div>

            <div class="mb-3 field">
              <label class="form-label small">Description</label>
              <textarea id="description" name="description" rows="6" class="form-control" placeholder="Describe the project (optional)"><?php echo h($old['description']); ?></textarea>
              <div class="d-flex justify-content-between mt-1">
                <div class="char-count" id="descCount">0 chars</div>
                <div class="muted small">Markdown is supported</div>
              </div>
            </div>

            <div class="row g-3">
              <div class="col-md-6 field">
                <label class="form-label small">Status</label>
                <select name="status" class="form-select">
                  <option value="pending" <?php if ($old['status'] === 'pending') echo 'selected'; ?>>Pending</option>
                  <option value="in_progress" <?php if ($old['status'] === 'in_progress') echo 'selected'; ?>>In progress</option>
                  <option value="completed" <?php if ($old['status'] === 'completed') echo 'selected'; ?>>Completed</option>
                </select>
              </div>

              <div class="col-md-3 field">
                <label class="form-label small">Start date</label>
                <input type="date" name="start_date" value="<?php echo h($old['start_date']); ?>" class="form-control">
              </div>

              <div class="col-md-3 field">
                <label class="form-label small">Due date</label>
                <input type="date" name="due_date" value="<?php echo h($old['due_date']); ?>" class="form-control">
              </div>
            </div>

            <div class="mt-4 d-flex gap-2 align-items-center">
              <button id="createBtn" type="submit" class="btn btn-primary cta">
                <span id="createIcon" class="me-2"><i class="bi bi-check2-circle"></i></span>
                Create Project
              </button>
              <a href="list.php" class="btn btn-outline-secondary">Back to projects</a>
              <div class="ms-auto muted small">Autosave: off</div>
            </div>
          </form>
        </div>

        <!-- right: live preview -->
        <div class="preview-card preview-card--animated">
          <div style="display:flex;justify-content:space-between;align-items:start;gap:10px">
            <div>
              <div class="muted small">Project preview</div>
              <div class="preview-ttl" id="previewTitle"><?php echo h($old['title'] ?: 'Project title will appear here'); ?></div>
              <div class="muted small" id="previewClient"><?php
                // show selected client name if any
                if ($old['client_id']) {
                    // fetch name quickly from database (best-effort)
                    $tmp = $conn->prepare("SELECT name FROM clients WHERE id=? LIMIT 1");
                    if ($tmp) {
                        $tmp->bind_param('i', $old['client_id']);
                        $tmp->execute();
                        $r = $tmp->get_result()->fetch_assoc();
                        echo h($r['name'] ?? '');
                        $tmp->close();
                    }
                } else {
                    echo 'Client — not selected';
                }
              ?></div>
            </div>
            <div class="text-end">
              <div class="badge bg-light text-dark" id="previewStatus"><?php echo h(ucfirst(str_replace('_',' ',$old['status']))); ?></div>
            </div>
          </div>

          <hr>

          <div id="previewDesc" class="muted" style="min-height:80px;">
            <?php echo nl2br(h($old['description'] ?: 'Project description preview — start typing to see it update live.')); ?>
          </div>

          <div class="mt-3 d-flex justify-content-between">
            <div class="small muted">Start: <span id="previewStart"><?php echo h($old['start_date'] ?: '—'); ?></span></div>
            <div class="small muted">Due: <span id="previewDue"><?php echo h($old['due_date'] ?: '—'); ?></span></div>
          </div>

          <div class="mt-3 d-flex gap-2">
            <a id="previewInvoiceBtn" class="btn btn-outline-primary btn-sm" href="#" style="pointer-events:none;opacity:.6"><i class="bi bi-receipt"></i> Create invoice</a>
            <a class="btn btn-outline-secondary btn-sm" href="/my_works/freelance_manager/clients/list.php"><i class="bi bi-people"></i> Manage clients</a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

  <script>
    // interactive bits
    (function(){
      const title = document.getElementById('title');
      const description = document.getElementById('description');
      const descCount = document.getElementById('descCount');
      const previewTitle = document.getElementById('previewTitle');
      const previewDesc = document.getElementById('previewDesc');
      const previewClient = document.getElementById('previewClient');
      const clientFilter = document.getElementById('clientFilter');
      const clientSelect = document.getElementById('clientSelect');
      const statusSelect = document.querySelector('[name="status"]');
      const previewStatus = document.getElementById('previewStatus');
      const previewStart = document.getElementById('previewStart');
      const previewDue = document.getElementById('previewDue');

      // char counter
      function updateDescCount(){
        const len = description.value.length;
        descCount.textContent = len + ' chars';
      }
      updateDescCount();
      description.addEventListener('input', function(){ updateDescCount(); updatePreviewDesc(); });

      // title preview
      title.addEventListener('input', function(){ previewTitle.textContent = this.value.trim() || 'Project title will appear here'; });

      // preview desc (simple sanitized)
      function escapeHtml(s){ return s.replace(/[&<>"']/g, function(m){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]; }); }
      function nl2br(s){ return s.replace(/\n/g, '<br>'); }
      function updatePreviewDesc(){
        const v = description.value.trim();
        previewDesc.innerHTML = v ? nl2br(escapeHtml(v)) : 'Project description preview — start typing to see it update live.';
      }

      // status preview
      statusSelect.addEventListener('change', function(){
        previewStatus.textContent = this.value.replace('_',' ');
      });

      // dates preview
      document.querySelector('[name="start_date"]').addEventListener('change', function(){ previewStart.textContent = this.value || '—'; });
      document.querySelector('[name="due_date"]').addEventListener('change', function(){ previewDue.textContent = this.value || '—'; });

      // client filter (simple)
      if (clientFilter && clientSelect) {
        clientFilter.addEventListener('input', function(){
          const q = this.value.trim().toLowerCase();
          Array.from(clientSelect.options).forEach(opt => {
            if (!opt.value) return; // skip placeholder
            const txt = opt.text.toLowerCase();
            opt.style.display = (!q || txt.includes(q)) ? '' : 'none';
          });
        });

        clientSelect.addEventListener('change', function(){
          const selectedText = clientSelect.options[clientSelect.selectedIndex]?.text || 'Client — not selected';
          previewClient.textContent = selectedText;
        });
      }

      // small form submit animation
      const createBtn = document.getElementById('createBtn');
      const createIcon = document.getElementById('createIcon');
      const projectForm = document.getElementById('projectForm');

      projectForm.addEventListener('submit', function(){
        createBtn.disabled = true;
        createBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Creating...';
      });

    })();
  </script>
</body>
</html>
