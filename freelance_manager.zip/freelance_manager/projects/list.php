<?php
// projects/list.php - modern, responsive, animated list of projects
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: /my_works/freelance_manager/login.php'); exit; }
require_once __DIR__ . '/../config/db.php';

$uid = (int)($_SESSION['user_id'] ?? 0);

// CSRF token for destructive actions
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
}
$csrf_token = $_SESSION['csrf_token'];

// fetch projects for this user
$stmt = $conn->prepare("
  SELECT p.id,p.title,p.status,p.start_date,p.due_date,p.created_at, c.name AS client_name
  FROM projects p
  JOIN clients c ON p.client_id = c.id
  WHERE c.user_id = ?
  ORDER BY p.created_at DESC
");
if (!$stmt) {
    die('DB prepare error: ' . htmlspecialchars($conn->error));
}
$stmt->bind_param('i', $uid);
$stmt->execute();
$res = $stmt->get_result();

// small helper
function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Projects — Freelance Manager</title>

  <!-- Fonts & bootstrap -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    :root{
      --bg:#f4f7fb;
      --card:#fff;
      --muted:#6c757d;
      --brand:#0d6efd;
      --accent-2:#0b5ed7;
      --radius:12px;
    }
    html,body{height:100%;font-family:'Inter',system-ui,Arial;}
    body{background:linear-gradient(180deg,var(--bg),#eef4ff); margin:0; color:#0b1a2b;}
    .container{max-width:1200px}
    .page-head{display:flex;align-items:center;justify-content:space-between;gap:1rem;margin:28px 0}
    .brand-pill{background:linear-gradient(135deg,var(--brand),var(--accent-2));color:#fff;padding:.5rem .8rem;border-radius:10px;font-weight:700;display:inline-flex;align-items:center;gap:.5rem}
    .app-card{background:var(--card);border-radius:var(--radius);box-shadow:0 10px 30px rgba(11,78,200,0.06);border:1px solid rgba(11,78,200,0.04);padding:18px}
    .controls .form-control{min-width:180px}
    .table-modern{border-collapse:collapse;width:100%}
    .table-modern thead th{border-bottom:1px solid rgba(0,0,0,0.06);background:transparent;padding:12px 10px;text-align:left;font-weight:600}
    .table-modern tbody td{padding:12px 10px;vertical-align:middle}
    .row-hover tbody tr{transition:transform .18s ease, box-shadow .18s ease}
    .row-hover tbody tr:hover{transform:translateY(-6px); box-shadow:0 10px 30px rgba(11,78,200,0.06)}
    .badge-status {padding:.35rem .6rem;border-radius:999px;font-weight:700;font-size:.85rem}
    .badge-ok{background:#e6f4ea;color:#0b6b3b}
    .badge-wip{background:#fff7e6;color:#7a4f00}
    .badge-late{background:#ffecec;color:#8a1c1c}
    .muted{color:var(--muted)}
    .empty-state{display:flex;align-items:center;gap:14px;padding:30px;border-radius:12px;background:linear-gradient(180deg,#fff,#fbfdff);border:1px solid rgba(11,78,200,0.04)}
    .fade-in{opacity:0;transform:translateY(8px);transition:all .42s cubic-bezier(.2,.9,.3,1)}
    .fade-in.in{opacity:1;transform:none}
    @media (max-width:767px){ .controls { flex-direction:column; gap:.6rem } .controls .form-control{width:100%} .brand-pill{font-size:.95rem} }
  </style>
</head>
<body>
  <div class="container py-4">
    <div class="page-head fade-in" id="head">
      <div>
        <div class="brand-pill"><i class="bi bi-kanban-fill"></i> Projects</div>
        <div class="muted small mt-2">Overview of your projects and quick actions</div>
      </div>
      <div class="d-flex align-items-center gap-2">
        <a href="/my_works/freelance_manager/projects/add.php" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg"></i> New Project</a>
        <a href="/my_works/freelance_manager/index.php" class="btn btn-outline-secondary btn-sm"><i class="bi bi-speedometer2"></i> Dashboard</a>
      </div>
    </div>

    <div class="app-card mt-3 fade-in" id="card" >
      <div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
        <div class="d-flex align-items-center gap-2 controls">
          <div class="input-group">
            <span class="input-group-text bg-white border-0"><i class="bi bi-search"></i></span>
            <input id="q" class="form-control" placeholder="Search title or client..." aria-label="Search projects">
          </div>

          <select id="statusFilter" class="form-select">
            <option value="">All status</option>
            <option value="active">Active</option>
            <option value="completed">Completed</option>
            <option value="on-hold">On hold</option>
            <option value="cancelled">Cancelled</option>
          </select>

          <div class="ms-2 small-muted">Showing <strong id="countSpan"><?php echo $res->num_rows; ?></strong> projects</div>
        </div>

        <div class="d-flex gap-2">
          <button id="refreshBtn" class="btn btn-outline-secondary btn-sm" title="Refresh list"><i class="bi bi-arrow-clockwise"></i></button>
          <div class="dropdown">
            <button class="btn btn-outline-primary btn-sm dropdown-toggle" data-bs-toggle="dropdown">Bulk</button>
            <ul class="dropdown-menu dropdown-menu-end">
              <li><a class="dropdown-item" href="#" id="bulkComplete">Mark selected completed</a></li>
              <li><a class="dropdown-item" href="#" id="bulkDelete">Delete selected</a></li>
            </ul>
          </div>
        </div>
      </div>

      <?php if ($res->num_rows === 0): ?>
        <div class="empty-state">
          <div style="font-size:2rem;color:var(--brand)"><i class="bi bi-kanban"></i></div>
          <div>
            <div style="font-weight:700">No projects yet</div>
            <div class="muted">Create your first project to track work, generate invoices and manage clients.</div>
            <div class="mt-3"><a href="/my_works/freelance_manager/projects/add.php" class="btn btn-primary btn-sm">Create project</a></div>
          </div>
        </div>
      <?php else: ?>
        <div class="table-responsive">
          <table class="table-modern row-hover w-100" id="projectsTable" role="table">
            <thead>
              <tr>
                <th style="width:38px"><input type="checkbox" id="selectAll"></th>
                <th>Title</th>
                <th>Client</th>
                <th>Status</th>
                <th>Start</th>
                <th>Due</th>
                <th>Added</th>
                <th style="width:170px">Actions</th>
              </tr>
            </thead>
            <tbody id="projectsTbody">
              <?php while ($r = $res->fetch_assoc()): 
                $status = strtolower($r['status'] ?? '');
                // map status to badge classes
                $badgeClass = 'badge-secondary';
                if (strpos($status,'complete') !== false || $status === 'completed') $badgeClass = 'badge-ok';
                elseif (strpos($status,'hold') !== false || $status === 'on-hold') $badgeClass = 'badge-wip';
                elseif (strpos($status,'late') !== false || $status === 'overdue') $badgeClass = 'badge-late';
                else $badgeClass = 'badge-wip';
              ?>
                <tr data-title="<?php echo h(strtolower($r['title'])); ?>" data-client="<?php echo h(strtolower($r['client_name'])); ?>" data-status="<?php echo h($status); ?>" data-id="<?php echo (int)$r['id']; ?>">
                  <td><input type="checkbox" class="row-check" value="<?php echo (int)$r['id']; ?>"></td>
                  <td style="min-width:220px;"><div style="font-weight:700"><?php echo h($r['title']); ?></div></td>
                  <td><?php echo h($r['client_name']); ?></td>
                  <td><span class="badge-status <?php echo $badgeClass; ?>"><?php echo h(ucfirst($r['status'])); ?></span></td>
                  <td><?php echo h($r['start_date']); ?></td>
                  <td><?php echo h($r['due_date']); ?></td>
                  <td class="muted"><?php echo h($r['created_at']); ?></td>
                  <td>
                    <div class="d-flex gap-2">
                      <a href="view.php?id=<?php echo (int)$r['id']; ?>" class="btn btn-outline-secondary btn-sm" title="View"><i class="bi bi-eye"></i></a>
                      <a href="edit.php?id=<?php echo (int)$r['id']; ?>" class="btn btn-outline-primary btn-sm" title="Edit"><i class="bi bi-pencil"></i></a>

                      <!-- Delete: uses a small form + JS confirmation -->
                      <form class="d-inline deleteForm" method="post" action="delete.php?id=<?php echo (int)$r['id']; ?>" style="margin:0">
                        <input type="hidden" name="csrf_token" value="<?php echo h($csrf_token); ?>">
                        <button type="button" class="btn btn-outline-danger btn-sm btn-delete" data-id="<?php echo (int)$r['id']; ?>" title="Delete"><i class="bi bi-trash"></i></button>
                      </form>
                    </div>
                  </td>
                </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>

    </div>

    <div class="mt-4 small muted text-center">Tip: Use the search box to quickly filter projects. Deleting a project will also remove local invoices related to it.</div>
  </div>

  <!-- Delete confirmation modal -->
  <div class="modal fade" id="confirmDeleteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-body">
          <div class="d-flex gap-3 align-items-center">
            <div class="bg-danger text-white rounded-circle p-3"><i class="bi bi-exclamation-triangle-fill"></i></div>
            <div>
              <h5 class="mb-1">Confirm delete</h5>
              <div class="muted">Are you sure you want to delete this project? This action cannot be undone.</div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button id="modalCancel" type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button id="modalConfirm" type="button" class="btn btn-danger">Delete project</button>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function(){
      // entrance
      document.querySelectorAll('.fade-in').forEach((el,i)=> setTimeout(()=> el.classList.add('in'), 60 + i*60));

      const q = document.getElementById('q');
      const statusFilter = document.getElementById('statusFilter');
      const tbody = document.getElementById('projectsTbody');
      const rows = Array.from(tbody ? tbody.querySelectorAll('tr') : []);
      const countSpan = document.getElementById('countSpan');

      function refreshCount() {
        const visible = rows.filter(r => r.style.display !== 'none').length;
        countSpan.textContent = visible;
      }

      function filterRows() {
        const query = q.value.trim().toLowerCase();
        const status = statusFilter.value.trim().toLowerCase();
        rows.forEach(row => {
          const title = row.dataset.title || '';
          const client = row.dataset.client || '';
          const st = (row.dataset.status || '').toLowerCase();
          let show = true;
          if (query) {
            show = title.includes(query) || client.includes(query);
          }
          if (show && status) show = st === status;
          row.style.display = show ? '' : 'none';
        });
        refreshCount();
      }

      q.addEventListener('input', debounce(filterRows, 180));
      statusFilter.addEventListener('change', filterRows);

      // select all
      document.getElementById('selectAll')?.addEventListener('change', function(){
        const checked = this.checked;
        document.querySelectorAll('.row-check').forEach(ch => ch.checked = checked);
      });

      // Refresh button (simple visual)
      document.getElementById('refreshBtn').addEventListener('click', function(){
        this.classList.add('active');
        setTimeout(()=> this.classList.remove('active'), 600);
        // optional: could re-fetch via AJAX. For now just re-run filter
        filterRows();
      });

      // Delete modal + AJAX fallback
      let deleteTargetForm = null;
      const confirmModal = new bootstrap.Modal(document.getElementById('confirmDeleteModal'));
      document.querySelectorAll('.btn-delete').forEach(btn => {
        btn.addEventListener('click', function(e){
          deleteTargetForm = this.closest('form');
          confirmModal.show();
        });
      });

      document.getElementById('modalConfirm').addEventListener('click', async function(){
        if (!deleteTargetForm) return;
        const form = deleteTargetForm;
        const action = form.getAttribute('action') || window.location.href;
        const formData = new FormData(form);

        // show spinner on confirm button
        const btn = this;
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span>Deleting...';

        try {
          // attempt AJAX POST; server must accept POST to delete (our delete.php uses POST)
          const resp = await fetch(action, {
            method: 'POST',
            body: formData,
            credentials: 'same-origin',
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
          });
          // If server returned JSON with success, use that; otherwise assume success on 200
          if (resp.ok) {
            // remove row visually
            const id = form.querySelector('button.btn-delete')?.dataset.id;
            const row = document.querySelector('tr[data-id="'+id+'"]');
            if (row) {
              row.style.transition = 'opacity .35s, transform .35s';
              row.style.opacity = '0';
              row.style.transform = 'translateX(20px)';
              setTimeout(()=> row.remove(), 380);
            }
            confirmModal.hide();
            setTimeout(()=> refreshCount(), 420);
          } else {
            // show error alert
            showAlert('Could not delete project. Server returned status ' + resp.status, 'danger');
            confirmModal.hide();
          }
        } catch (err) {
          showAlert('Network error while deleting. Try again.', 'danger');
        } finally {
          btn.disabled = false;
          btn.innerHTML = 'Delete project';
        }
      });

      // simple alert helper
      function showAlert(message, type='info') {
        const tmp = document.createElement('div');
        tmp.className = 'alert alert-' + type + ' mt-3';
        tmp.innerHTML = message;
        document.querySelector('.app-card').prepend(tmp);
        setTimeout(()=> tmp.remove(), 5000);
      }

      // debounce helper
      function debounce(fn, ms){ let t; return (...a)=>{ clearTimeout(t); t=setTimeout(()=>fn(...a), ms); }; }

      // Bulk action (simple)
      document.getElementById('bulkDelete').addEventListener('click', function(e){
        e.preventDefault();
        const selected = Array.from(document.querySelectorAll('.row-check:checked')).map(ch => ch.value);
        if (selected.length === 0) { showAlert('No projects selected', 'warning'); return; }
        if (!confirm('Delete ' + selected.length + ' selected project(s)? This cannot be undone.')) return;
        // For safety, perform full-page POST to a bulk-delete endpoint or iterate single deletes.
        // Here we'll submit sequential POSTs (not ideal for large sets).
        (async ()=> {
          for (const id of selected) {
            const form = new FormData();
            form.append('csrf_token', '<?php echo h($csrf_token); ?>');
            try {
              await fetch('delete.php?id=' + encodeURIComponent(id), { method: 'POST', body: form, credentials: 'same-origin' });
              const row = document.querySelector('tr[data-id="'+id+'"]');
              if (row) row.remove();
            } catch(e){}
          }
          refreshCount();
        })();
      });

      document.getElementById('bulkComplete').addEventListener('click', function(e){
        e.preventDefault();
        const selected = Array.from(document.querySelectorAll('.row-check:checked')).map(ch => ch.value);
        if (selected.length === 0) { showAlert('No projects selected', 'warning'); return; }
        // For simplicity, we do a simplistic visual update; ideally you'd call a POST endpoint to update DB.
        selected.forEach(id => {
          const row = document.querySelector('tr[data-id="'+id+'"]');
          if (row) {
            const badge = row.querySelector('.badge-status');
            if (badge) {
              badge.className = 'badge-status badge-ok';
              badge.textContent = 'Completed';
            }
          }
        });
        showAlert(selected.length + ' project(s) marked completed (client-side).', 'success');
      });

    }); // DOMContentLoaded
  </script>
</body>
</html>
