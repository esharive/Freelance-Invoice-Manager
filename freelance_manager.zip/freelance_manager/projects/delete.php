<?php
// projects/delete.php
// Delete a project (ownership verified). Uses layout.php for page chrome.
// Place this in: /my_works/freelance_manager/projects/delete.php

session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: /my_works/freelance_manager/login.php');
    exit;
}

require_once __DIR__ . '/../config/db.php';
$uid = (int)($_SESSION['user_id'] ?? 0);

// page metadata for layout
$page_title = 'Delete Project';
$active = 'projects';
$breadcrumbs = [
    ['label' => 'Dashboard', 'url' => '/my_works/freelance_manager/index.php'],
    ['label' => 'Projects', 'url' => '/my_works/freelance_manager/projects/list.php'],
    ['label' => 'Delete', 'url' => '']
];

// helper
function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

// project id expected
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$id) {
    // redirect back if no id
    header('Location: list.php');
    exit;
}

// verify ownership and fetch project for display
$check = $conn->prepare("
  SELECT p.id, p.title, p.client_id, c.name AS client_name
  FROM projects p
  JOIN clients c ON p.client_id = c.id
  WHERE p.id = ? AND c.user_id = ?
  LIMIT 1
");
if (!$check) {
    die('DB error: ' . h($conn->error));
}
$check->bind_param('ii', $id, $uid);
$check->execute();
$projRow = $check->get_result()->fetch_assoc();
$check->close();

if (!$projRow) {
    // not found / access denied
    header('Location: list.php');
    exit;
}

// simple CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
}
$csrf = $_SESSION['csrf_token'];

$errors = [];
$success = false;

// handle POST (delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // check csrf
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf) {
        $errors[] = 'Invalid request (CSRF). Please reload and try again.';
    } else {
        // re-check ownership for safety
        $chk2 = $conn->prepare("SELECT p.id FROM projects p JOIN clients c ON p.client_id=c.id WHERE p.id=? AND c.user_id=? LIMIT 1");
        if (!$chk2) {
            $errors[] = 'DB error: ' . h($conn->error);
        } else {
            $chk2->bind_param('ii', $id, $uid);
            $chk2->execute();
            $chk2->store_result();
            if ($chk2->num_rows === 0) {
                $errors[] = 'Not authorized to delete this project.';
            }
            $chk2->close();
        }
    }

    if (empty($errors)) {
        // optional: delete related records (invoices, invoice_items, payments) if your app expects cascade
        // We'll try to delete the project row only; adjust if you want to cascade.
        $del = $conn->prepare("DELETE FROM projects WHERE id = ?");
        if (!$del) {
            $errors[] = 'DB error: ' . h($conn->error);
        } else {
            $del->bind_param('i', $id);
            if ($del->execute()) {
                $success = true;
                // redirect to list after a short delay (JS will handle UX). Also set a flash (optional).
                $_SESSION['flash_success'] = 'Project deleted successfully.';
                header('Location: list.php');
                exit;
            } else {
                $errors[] = 'Could not delete project: ' . h($del->error);
            }
            $del->close();
        }
    }
}

// capture content for layout
ob_start();
?>
<div class="container py-5">
  <div class="row justify-content-center">
    <div class="col-lg-9">
      <div class="card p-4 shadow-sm border-0" style="border-radius:14px; background: linear-gradient(180deg,#fff,#fbfdff);">
        <div class="d-flex align-items-start gap-3 mb-3">
          <div class="display-6 text-primary"><i class="bi bi-trash-fill"></i></div>
          <div>
            <h3 class="mb-0">Delete Project</h3>
            <div class="text-muted small">You are about to permanently delete this project and all of its project-level metadata.</div>
          </div>
        </div>

        <div class="row gx-4">
          <div class="col-md-8">
            <div class="p-3 rounded" style="background:#ffffff;border:1px solid rgba(11,78,200,0.04);">
              <h5 class="mb-2"><?php echo h($projRow['title']); ?></h5>
              <div class="muted mb-2">Client: <strong><?php echo h($projRow['client_name']); ?></strong></div>
              <p class="small text-muted">Deleting a project cannot be undone. If this project has invoices, payments, or invoice items, consider exporting or archiving them before deletion.</p>

              <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                  <ul class="mb-0">
                    <?php foreach ($errors as $err): ?>
                      <li><?php echo h($err); ?></li>
                    <?php endforeach; ?>
                  </ul>
                </div>
              <?php endif; ?>

              <div class="d-flex gap-2 align-items-center mt-3">
                <button id="confirmBtn" class="btn btn-danger btn-lg shadow-sm"><i class="bi bi-trash me-2"></i> Delete project</button>
                <a href="list.php" class="btn btn-outline-secondary">Cancel</a>
                <div class="ms-auto text-muted small">Project ID: <?php echo (int)$projRow['id']; ?></div>
              </div>
            </div>
          </div>

          <div class="col-md-4">
            <div class="p-3 rounded preview-card" style="background:linear-gradient(180deg,#fff,#fcfeff);border:1px solid rgba(11,78,200,0.04)">
              <div class="small text-muted">Summary</div>
              <div class="mt-2">
                <div><strong>Title</strong><div><?php echo h($projRow['title']); ?></div></div>
                <div class="mt-2"><strong>Client</strong><div><?php echo h($projRow['client_name']); ?></div></div>
                <div class="mt-2"><strong>Created</strong><div class="muted small">Check project details for creation date.</div></div>
              </div>

              <hr>

              <div class="small muted">Pro tip: If you only want to hide the project temporarily, consider renaming it with a prefix like <code>ARCHIVE/</code> instead of deleting.</div>
            </div>
          </div>
        </div>

        <!-- hidden form (submitted by JS when the user confirms in modal) -->
        <form id="deleteForm" method="post" class="d-none" aria-hidden="true">
          <input type="hidden" name="csrf_token" value="<?php echo h($csrf); ?>">
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Confirm modal -->
<div class="modal fade" id="confirmModal" tabindex="-1" aria-labelledby="confirmModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content" style="border-radius:12px;">
      <div class="modal-header">
        <h5 class="modal-title" id="confirmModalLabel"><i class="bi bi-exclamation-triangle-fill text-warning me-2"></i> Confirm deletion</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p class="mb-2">This will permanently delete the project <strong><?php echo h($projRow['title']); ?></strong>. Any associated records (projects-only) will be removed. This action cannot be undone.</p>
        <p class="small text-muted">If this project has invoices or payments you want to keep, export them first.</p>
      </div>
      <div class="modal-footer">
        <button id="modalCancel" type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
        <button id="modalDelete" type="button" class="btn btn-danger">Yes — delete</button>
      </div>
    </div>
  </div>
</div>

<!-- Toast -->
<div class="position-fixed bottom-0 end-0 p-3" style="z-index:1200">
  <div id="actionToast" class="toast align-items-center text-bg-dark border-0" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="d-flex">
      <div class="toast-body">Working…</div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
  </div>
</div>

<script>
  // interactive behavior
  document.addEventListener('DOMContentLoaded', function(){
    const confirmBtn = document.getElementById('confirmBtn');
    const deleteForm = document.getElementById('deleteForm');
    const modalDelete = document.getElementById('modalDelete');
    const confirmModalEl = document.getElementById('confirmModal');
    const toastEl = document.getElementById('actionToast');

    const bsModal = new bootstrap.Modal(confirmModalEl);
    const bsToast = toastEl ? new bootstrap.Toast(toastEl) : null;

    // show modal when user clicks Delete
    confirmBtn.addEventListener('click', function(){
      bsModal.show();
    });

    // when user confirms in modal, submit the hidden form
    modalDelete.addEventListener('click', function(){
      // show working toast
      if (bsToast) {
        toastEl.querySelector('.toast-body').textContent = 'Deleting project…';
        bsToast.show();
      }

      // small visual delay to show toast/modal then submit
      setTimeout(function(){
        deleteForm.submit();
      }, 450);
    });

    // subtle entrance animation for content
    document.querySelectorAll('.card, .preview-card').forEach(function(el,i){
      el.style.opacity = 0;
      el.style.transform = 'translateY(10px)';
      setTimeout(function(){
        el.style.transition = 'all .45s cubic-bezier(.2,.9,.3,1)';
        el.style.opacity = 1;
        el.style.transform = 'none';
      }, 80 + i*80);
    });
  });
</script>
<?php
$content = ob_get_clean();
include __DIR__ . '/../layout.php';
