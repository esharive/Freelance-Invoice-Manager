<?php
// projects/view.php
// View a single project: details, invoices, actions.
// Standalone page (no layout.php). Uses Bootstrap 5 CDN and interactive JS.
// Place in: /freelance_manager/projects/view.php

session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: /freelance_manager/login.php');
    exit;
}
require_once __DIR__ . '/../config/db.php';

$uid = (int) $_SESSION['user_id'];

function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

// project id
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    die('No project id.');
}

// handle status update (simple POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    $newStatus = in_array($_POST['status'] ?? '', ['pending','in_progress','completed']) ? $_POST['status'] : 'pending';
    $upd = $conn->prepare("
      UPDATE projects p
      JOIN clients c ON p.client_id = c.id
      SET p.status = ?
      WHERE p.id = ? AND c.user_id = ?
    ");
    if ($upd) {
        $upd->bind_param('sii', $newStatus, $id, $uid);
        $upd->execute();
    }
    // redirect to avoid resubmission
    header('Location: view.php?id=' . $id);
    exit;
}

// fetch project & ensure ownership (via client user_id)
$stmt = $conn->prepare("
  SELECT p.*, c.id AS client_id, c.name AS client_name, c.company AS client_company
  FROM projects p
  JOIN clients c ON p.client_id = c.id
  WHERE p.id = ? AND c.user_id = ?
  LIMIT 1
");
if (!$stmt) {
    die('DB error: ' . h($conn->error));
}
$stmt->bind_param('ii', $id, $uid);
$stmt->execute();
$project = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$project) {
    die('Project not found or access denied.');
}

// fetch invoices for this project
$invStmt = $conn->prepare("
  SELECT i.id, i.invoice_number, i.amount, i.currency, i.status, i.due_date, i.created_at
  FROM invoices i
  WHERE i.project_id = ?
  ORDER BY i.created_at DESC
");
$invStmt->bind_param('i', $id);
$invStmt->execute();
$invoices = $invStmt->get_result();
$invStmt->close();

// compute invoices counts and totals (for cool counters)
$totalInvoices = 0;
$totalInvoiced = 0.0;
$totalPaid = 0.0;
$currencySamples = [];
foreach ($invoices as $row) {
    $totalInvoices++;
    $totalInvoiced += (float)$row['amount'];
    $currencySamples[$row['currency']] = true;
}
// Rewind invoice result for display: re-query for display to avoid issues with fetch loop above
$invStmt2 = $conn->prepare("
  SELECT i.id, i.invoice_number, i.amount, i.currency, i.status, i.due_date, i.created_at
  FROM invoices i
  WHERE i.project_id = ?
  ORDER BY i.created_at DESC
");
$invStmt2->bind_param('i', $id);
$invStmt2->execute();
$invoicesDisplay = $invStmt2->get_result();
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?php echo h($project['title']); ?> — Project — Freelance Manager</title>

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    :root{
      --brand:#0d6efd;
      --muted:#6c757d;
      --card-bg:#ffffff;
      --glass: rgba(255,255,255,0.7);
    }
    body{font-family:Inter,system-ui,Arial,Helvetica,sans-serif;background:linear-gradient(180deg,#f6fbff,#f4f7fb);color:#0b1a2b}
    .container{max-width:1200px}
    .topbar{backdrop-filter: blur(6px); background: linear-gradient(90deg, rgba(255,255,255,0.6), rgba(255,255,255,0.55)); border-radius:12px; padding:18px; box-shadow:0 8px 30px rgba(11,78,200,0.06)}
    .project-hero{border-radius:12px;padding:22px;background:linear-gradient(180deg,#ffffff,#fbfdff);box-shadow:0 18px 40px rgba(11,78,200,0.04)}
    .stat{background:linear-gradient(180deg,#fff,#fbfdff);border-radius:12px;padding:14px;box-shadow:0 8px 22px rgba(11,78,200,0.04)}
    .badge-status {padding:6px 10px;border-radius:999px;font-weight:600}
    .status-pending{background:#fff3cd;color:#856404}
    .status-in_progress{background:#cfe2ff;color:#084298}
    .status-completed{background:#d1e7dd;color:#0f5132}
    .fade-in {opacity:0; transform:translateY(12px); transition: all .56s cubic-bezier(.2,.9,.3,1)}
    .fade-in.in {opacity:1; transform:none}
    .invoice-row:hover { transform: translateY(-4px); box-shadow: 0 8px 28px rgba(11,78,200,0.04); transition: .18s ease; }
    .btn-ghost { border-radius:10px; padding:8px 12px; }
    @media (max-width:767px){ .project-hero{padding:14px} .stat{padding:10px} }
  </style>
</head>
<body>
  <div class="container py-5">
    <!-- topbar -->
    <div class="topbar mb-4 d-flex justify-content-between align-items-center fade-in" id="topbar">
      <div>
        <h3 class="mb-0">Project</h3>
        <div class="small text-muted">Project details & actions — <?php echo h($project['client_name'] . ($project['client_company'] ? ' — ' . $project['client_company'] : '')); ?></div>
      </div>
      <div class="d-flex gap-2 align-items-center">
        <a href="/freelance_manager/projects/list.php" class="btn btn-outline-secondary btn-sm btn-ghost"><i class="bi bi-arrow-left"></i> Back</a>
        <a href="/freelance_manager/projects/edit.php?id=<?php echo (int)$project['id']; ?>" class="btn btn-primary btn-sm"><i class="bi bi-pencil-square"></i> Edit</a>
        <a href="/freelance_manager/projects/delete.php?id=<?php echo (int)$project['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this project and all related records? This cannot be undone.');"><i class="bi bi-trash"></i> Delete</a>
      </div>
    </div>

    <!-- hero -->
    <div class="project-hero mb-4 fade-in" id="hero">
      <div class="d-flex flex-column flex-md-row justify-content-between gap-3 align-items-start">
        <div class="flex-grow-1">
          <div class="d-flex align-items-center gap-3">
            <div style="width:64px;height:64px;border-radius:14px;background:linear-gradient(135deg,var(--brand),#0b5ed7);display:flex;align-items:center;justify-content:center;color:#fff;font-size:22px;box-shadow:0 12px 30px rgba(11,78,200,0.12);">
              <i class="bi bi-kanban"></i>
            </div>
            <div>
              <h2 class="mb-1" style="font-weight:700"><?php echo h($project['title']); ?></h2>
              <div class="small text-muted"><?php echo nl2br(h($project['description'])); ?></div>
              <div class="mt-2">
                <span class="badge badge-status <?php echo 'status-' . h($project['status']); ?>"><?php echo ucfirst(str_replace('_',' ',$project['status'])); ?></span>
                <small class="text-muted ms-2">Start: <?php echo h($project['start_date'] ?: '—'); ?> • Due: <?php echo h($project['due_date'] ?: '—'); ?></small>
              </div>
            </div>
          </div>
        </div>

        <div class="d-flex gap-3 align-items-center">
          <div class="stat text-center">
            <div class="muted small">Invoices</div>
            <div class="h4 mb-0" id="countInvoices"><?php echo (int)$totalInvoices; ?></div>
          </div>
          <div class="stat text-center">
            <div class="muted small">Total invoiced</div>
            <div class="h5 mb-0"><?php echo number_format((float)$totalInvoiced,2); ?> <?php echo h(array_keys($currencySamples)[0] ?? ''); ?></div>
          </div>
          <div class="text-end">
            <a href="/freelance_manager/invoices/add.php?project_id=<?php echo (int)$project['id']; ?>" class="btn btn-success"><i class="bi bi-plus-lg"></i> New Invoice</a>
          </div>
        </div>
      </div>

      <!-- quick status change -->
      <div class="mt-3 d-flex gap-2 align-items-center">
        <form method="post" class="d-flex gap-2 align-items-center" onsubmit="return confirm('Change project status?');">
          <input type="hidden" name="action" value="update_status">
          <select name="status" class="form-select form-select-sm" style="width:auto">
            <option value="pending" <?php if($project['status']=='pending') echo 'selected'; ?>>Pending</option>
            <option value="in_progress" <?php if($project['status']=='in_progress') echo 'selected'; ?>>In Progress</option>
            <option value="completed" <?php if($project['status']=='completed') echo 'selected'; ?>>Completed</option>
          </select>
          <button type="submit" class="btn btn-outline-primary btn-sm">Update status</button>
        </form>

        <button class="btn btn-outline-secondary btn-sm" id="btnCopyTitle" data-copy="<?php echo h($project['title']); ?>"><i class="bi bi-clipboard"></i> Copy title</button>
      </div>
    </div>

    <!-- two-column: invoices + timeline/details -->
    <div class="row g-4">
      <div class="col-lg-8">
        <div class="card p-3 fade-in">
          <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="mb-0">Invoices for this project</h5>
            <div class="small text-muted"><?php echo (int)$totalInvoices; ?> total</div>
          </div>

          <?php if ($invoicesDisplay->num_rows === 0): ?>
            <div class="p-4 text-center text-muted">No invoices yet. Create your first invoice for this project to bill your client.</div>
          <?php else: ?>
            <div class="list-group">
              <?php while ($inv = $invoicesDisplay->fetch_assoc()): ?>
                <div class="list-group-item d-flex justify-content-between align-items-center invoice-row">
                  <div>
                    <div style="font-weight:700"><?php echo h($inv['invoice_number'] ?: ('#' . $inv['id'])); ?></div>
                    <div class="small text-muted"><?php echo h($inv['created_at']); ?> • Due <?php echo h($inv['due_date'] ?: '—'); ?></div>
                  </div>

                  <div class="text-end">
                    <div class="mb-1">
                      <span class="fw-bold"><?php echo h($inv['currency']) . ' ' . number_format((float)$inv['amount'],2); ?></span>
                      <span class="small text-muted d-block"><?php echo ucfirst(h($inv['status'])); ?></span>
                    </div>
                    <div class="d-flex gap-2 justify-content-end">
                      <a class="btn btn-sm btn-outline-secondary" href="/freelance_manager/invoices/view.php?id=<?php echo (int)$inv['id']; ?>" target="_blank"><i class="bi bi-eye"></i></a>
                      <a class="btn btn-sm btn-outline-primary" href="/freelance_manager/invoices/edit.php?id=<?php echo (int)$inv['id']; ?>"><i class="bi bi-pencil"></i></a>
                      <a class="btn btn-sm btn-success" href="/freelance_manager/payments/add.php?invoice_id=<?php echo (int)$inv['id']; ?>"><i class="bi bi-cash-stack"></i></a>
                      <button class="btn btn-sm btn-ghost btn-outline-info" onclick="copyText('<?php echo h($inv['invoice_number'] ?: ('#' . $inv['id'])); ?>')"><i class="bi bi-clipboard"></i></button>
                    </div>
                  </div>
                </div>
              <?php endwhile; ?>
            </div>
          <?php endif; ?>

        </div>
      </div>

      <div class="col-lg-4">
        <div class="card p-3 fade-in">
          <h6 class="mb-3">Project details</h6>
          <dl class="row">
            <dt class="col-5 text-muted">Client</dt><dd class="col-7"><?php echo h($project['client_name']); ?></dd>

            <dt class="col-5 text-muted">Created</dt><dd class="col-7"><?php echo h($project['created_at']); ?></dd>

            <dt class="col-5 text-muted">Status</dt><dd class="col-7"><span class="badge badge-status <?php echo 'status-' . h($project['status']); ?>"><?php echo ucfirst(str_replace('_',' ',$project['status'])); ?></span></dd>

            <dt class="col-5 text-muted">Start</dt><dd class="col-7"><?php echo h($project['start_date'] ?: '—'); ?></dd>

            <dt class="col-5 text-muted">Due</dt><dd class="col-7"><?php echo h($project['due_date'] ?: '—'); ?></dd>
          </dl>

          <hr>

          <h6 class="mb-2">Quick actions</h6>
          <div class="d-grid gap-2">
            <a href="/freelance_manager/invoices/add.php?project_id=<?php echo (int)$project['id']; ?>" class="btn btn-primary">Create Invoice</a>
            <a href="/freelance_manager/clients/edit.php?id=<?php echo (int)$project['client_id']; ?>" class="btn btn-outline-secondary">Edit Client</a>
          </div>

        </div>

        <div class="card p-3 mt-3 fade-in">
          <h6 class="mb-2">Notes</h6>
          <div class="small text-muted"><?php echo nl2br(h($project['notes'] ?? 'No notes for this project.')); ?></div>
        </div>
      </div>
    </div>

    <footer class="text-center text-muted mt-5 small">Freelance Manager — built for freelancers & small businesses</footer>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // entrance animations
    document.addEventListener('DOMContentLoaded', function(){
      document.querySelectorAll('.fade-in').forEach((el,i)=>{
        setTimeout(()=>el.classList.add('in'), 80 + i*80);
      });

      // copy project title button
      document.getElementById('btnCopyTitle')?.addEventListener('click', function(){
        const txt = this.dataset.copy || '';
        if (!txt) return;
        navigator.clipboard?.writeText(txt).then(()=> {
          this.innerHTML = '<i class="bi bi-check2"></i> Copied';
          setTimeout(()=> this.innerHTML = '<i class="bi bi-clipboard"></i> Copy title', 1400);
        }).catch(()=> {
          alert('Copy failed. Please copy manually.');
        });
      });
    });

    // helper to copy invoice number
    function copyText(txt) {
      if (!txt) return;
      navigator.clipboard?.writeText(txt).then(()=> {
        const n = new NotificationToast('Copied: ' + txt);
        n.show();
      }).catch(()=> alert('Copy failed.'));
    }

    // small toast (non-bootstrap) for feedback
    function NotificationToast(message) {
      this.message = message;
      this.show = function(){
        const el = document.createElement('div');
        el.style.position = 'fixed';
        el.style.bottom = '20px';
        el.style.right = '20px';
        el.style.background = '#0d6efd';
        el.style.color = '#fff';
        el.style.padding = '10px 14px';
        el.style.borderRadius = '10px';
        el.style.boxShadow = '0 8px 24px rgba(13,110,253,0.12)';
        el.style.zIndex = 9999;
        el.style.fontSize = '14px';
        el.textContent = this.message;
        document.body.appendChild(el);
        setTimeout(()=> el.style.opacity = '0.98', 10);
        setTimeout(()=> el.remove(), 2200);
      }
    }
  </script>
</body>
</html>
