<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
echo "Error display is ON<br><br>";

include 'login.php'; // <-- change this to the file giving the error
?>
