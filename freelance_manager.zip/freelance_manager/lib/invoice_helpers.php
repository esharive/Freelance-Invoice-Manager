<?php
// lib/invoice_helpers.php
// Helper functions for invoice item totals and PDF generation.

// Safe vendor/autoload include (avoid fatal when composer/vendor not present)
$vendorAutoload = __DIR__ . '/../vendor/autoload.php';
$hasVendor = false;
if (file_exists($vendorAutoload)) {
    require_once $vendorAutoload; // dompdf, phpmailer, etc.
    $hasVendor = true;
}

require_once __DIR__ . '/../config/db.php';

use Dompdf\Dompdf;
use Dompdf\Options;

/**
 * Compute line totals and invoice total from arrays of items.
 * Each item is an array with keys: description, qty, unit_price
 * Returns array: ['items' => [ {description,qty,unit_price,line_total}, ... ], 'total' => float]
 */
function compute_items_total(array $descriptions, array $qtys, array $unit_prices) : array {
    $items = [];
    $total = 0.0;

    $count = max(count($descriptions), count($qtys), count($unit_prices));
    for ($i = 0; $i < $count; $i++) {
        $desc = trim($descriptions[$i] ?? '');
        $qraw = $qtys[$i] ?? '';
        $praw = $unit_prices[$i] ?? '';

        // skip totally empty rows
        if ($desc === '' && trim($qraw) === '' && trim($praw) === '') continue;

        $qty = $qraw === '' ? 0.0 : (float)$qraw;
        $unit = $praw === '' ? 0.0 : (float)$praw;
        $line_total = round($qty * $unit, 2);

        // skip rows with no description and zero amounts
        if ($desc === '' && $line_total <= 0) continue;

        $items[] = [
            'description' => $desc,
            'qty' => $qty,
            'unit_price' => $unit,
            'line_total' => $line_total
        ];
        $total += $line_total;
    }

    return ['items' => $items, 'total' => round($total, 2)];
}

/**
 * Generate invoice PDF and save to invoices_pdfs folder.
 * Returns saved file path on success, or false on failure.
 *
 * $opts:
 *   - 'stream' => false (don't stream), true to stream inline (not used here)
 */
function generateInvoicePdf(int $invoice_id, array $opts = []) {
    global $conn;

    // ensure Dompdf is available
    if (!class_exists('\Dompdf\Dompdf')) {
        error_log("generateInvoicePdf: Dompdf not available. Install dompdf via Composer to enable PDF generation.");
        return false;
    }

    // fetch invoice + project + client + user for header
    $stmt = $conn->prepare("
      SELECT i.*, p.title AS project_title, p.description AS project_description,
             c.name AS client_name, c.email AS client_email, c.phone AS client_phone, c.company AS client_company,
             u.company_name AS user_company, u.company_email AS user_email, u.company_phone AS user_phone, u.company_address AS user_address, u.logo AS user_logo
      FROM invoices i
      JOIN projects p ON i.project_id = p.id
      JOIN clients c ON p.client_id = c.id
      JOIN users u ON c.user_id = u.id
      WHERE i.id = ?
      LIMIT 1
    ");
    $stmt->bind_param('i', $invoice_id);
    $stmt->execute();
    $inv = $stmt->get_result()->fetch_assoc();
    if (!$inv) return false;

    // fetch invoice items
    $si = $conn->prepare("SELECT description, qty, unit_price, line_total FROM invoice_items WHERE invoice_id = ? ORDER BY id ASC");
    $si->bind_param('i', $invoice_id);
    $si->execute();
    $items_res = $si->get_result();
    $items = $items_res->fetch_all(MYSQLI_ASSOC);

    // currency symbol map
    $map = ['NGN'=>'₦','USD'=>'$','EUR'=>'€','GBP'=>'£'];
    $currency = $inv['currency'] ?: ($inv['default_currency'] ?? 'USD');
    $symbol = $map[$currency] ?? $currency;

    // build HTML
    $html = '<!doctype html><html><head><meta charset="utf-8"><style>
    body{font-family:DejaVu Sans, Arial,Helvetica,sans-serif;padding:20px;color:#333;font-size:14px}
    .header{display:flex;justify-content:space-between;align-items:center}
    table{width:100%;border-collapse:collapse;margin-top:20px}
    th,td{border:1px solid #ccc;padding:8px;text-align:left;vertical-align:top}
    .right{text-align:right}
    .small{font-size:0.9em;color:#555}
    </style></head><body>';

    // header
    $html .= '<div class="header"><div>';
    if (!empty($inv['user_logo'])) {
        $logo_path = __DIR__ . '/../uploads/logos/' . $inv['user_logo'];
        if (file_exists($logo_path)) {
            $html .= '<img src="data:image/png;base64,'.base64_encode(file_get_contents($logo_path)).'" style="max-height:60px;"><br>';
        }
    }
    $html .= '<h2>' . htmlspecialchars($inv['user_company'] ?? 'Your Business Name') . '</h2>';
    if (!empty($inv['user_address'])) $html .= '<div class="small">' . nl2br(htmlspecialchars($inv['user_address'])) . '</div>';
    if (!empty($inv['user_email'])) $html .= '<div class="small">' . htmlspecialchars($inv['user_email']) . '</div>';
    if (!empty($inv['user_phone'])) $html .= '<div class="small">' . htmlspecialchars($inv['user_phone']) . '</div>';
    $html .= '</div>';

    $inv_number = $inv['invoice_number'] ?? ('INV-' . date('Y') . '-' . str_pad($inv['id'],6,'0',STR_PAD_LEFT));
    $html .= '<div><strong>Invoice ' . htmlspecialchars($inv_number) . '</strong><br>Created: ' . htmlspecialchars($inv['created_at']) . '<br>Due: ' . htmlspecialchars($inv['due_date']) . '</div>';
    $html .= '</div>';

    // client
    $html .= '<h3>Bill to</h3><div><strong>' . htmlspecialchars($inv['client_name']) . '</strong>';
    if ($inv['client_company']) $html .= ' — ' . htmlspecialchars($inv['client_company']);
    if ($inv['client_email']) $html .= '<br>' . htmlspecialchars($inv['client_email']);
    if ($inv['client_phone']) $html .= '<br>' . htmlspecialchars($inv['client_phone']);
    $html .= '</div>';

    // items table
    $html .= '<table><thead><tr><th>Description</th><th style="width:90px">Qty</th><th style="width:130px">Unit</th><th style="width:130px">Line total</th></tr></thead><tbody>';
    foreach ($items as $it) {
        $html .= '<tr>';
        $html .= '<td>' . nl2br(htmlspecialchars($it['description'])) . '</td>';
        $html .= '<td class="right">' . number_format((float)$it['qty'], 2) . '</td>';
        $html .= '<td class="right">' . $symbol . ' ' . number_format((float)$it['unit_price'], 2) . '</td>';
        $html .= '<td class="right">' . $symbol . ' ' . number_format((float)$it['line_total'], 2) . '</td>';
        $html .= '</tr>';
    }
    $html .= '</tbody>';

    // totals
    $html .= '<tr><td colspan="3" class="right"><strong>Total</strong></td><td class="right"><strong>' . $symbol . ' ' . number_format((float)$inv['amount'], 2) . '</strong></td></tr>';
    $html .= '</table>';

    $html .= '<p style="margin-top:20px">Status: <strong>' . htmlspecialchars($inv['status']) . '</strong></p>';
    $html .= '<p style="margin-top:20px">Thank you for your business.</p>';
    $html .= '</body></html>';

    // render with Dompdf (safely)
    try {
        $dompdfOptions = new Options();
        $dompdfOptions->set('isRemoteEnabled', true);
        $dompdfOptions->set('defaultFont', 'DejaVu Sans');

        $dompdf = new Dompdf($dompdfOptions);
        $dompdf->loadHtml($html, 'UTF-8');
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();
    } catch (Throwable $e) {
        error_log("generateInvoicePdf: Dompdf render error for invoice {$invoice_id}: " . $e->getMessage());
        return false;
    }

    // save
    $saveDir = __DIR__ . '/../invoices_pdfs/';
    if (!is_dir($saveDir)) mkdir($saveDir, 0755, true);
    $filename = 'invoice_' . $inv['id'] . '_' . date('Ymd_His') . '.pdf';
    $savePath = $saveDir . $filename;
    file_put_contents($savePath, $dompdf->output());

    // stream inline if requested
    if (!empty($opts['stream'])) {
        $dompdf->stream($filename, ["Attachment" => 0]);
        exit;
    }

    return $savePath;
}
