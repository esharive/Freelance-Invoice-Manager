<?php
// lib/send_mail.php
// Sends HTML emails using PHPMailer and environment config from .env
// Returns true on success, or an error string on failure.

if (!defined('APP_BASE')) {
    define('APP_BASE', '/my_works/freelance_manager/');
}

$vendorAutoload = __DIR__ . '/../vendor/autoload.php';
$hasVendor = false;
if (file_exists($vendorAutoload)) {
    require_once $vendorAutoload;
    $hasVendor = true;
}

if (class_exists('\Dotenv\Dotenv')) {
    try {
        \Dotenv\Dotenv::createImmutable(__DIR__ . '/..')->safeLoad();
    } catch (Throwable $e) {
        // ignore
    }
}

$mail_cfg = [
    'host'       => $_ENV['MAIL_HOST'] ?? $_ENV['MAILER_HOST'] ?? 'smtp.gmail.com',
    'username'   => $_ENV['MAIL_USERNAME'] ?? $_ENV['MAIL_USER'] ?? '',
    'password'   => $_ENV['MAIL_PASSWORD'] ?? $_ENV['MAIL_PASS'] ?? '',
    'secure'     => strtolower($_ENV['MAIL_ENCRYPTION'] ?? $_ENV['MAIL_ENC'] ?? 'tls'),
    'port'       => isset($_ENV['MAIL_PORT']) ? (int) $_ENV['MAIL_PORT'] : 587,
    'from_email' => $_ENV['MAIL_FROM'] ?? ($_ENV['MAIL_USERNAME'] ?? 'no-reply@example.com'),
    'from_name'  => $_ENV['MAIL_FROM_NAME'] ?? ($_SESSION['user_name'] ?? 'Freelance Manager'),
    'debug'      => (isset($_ENV['APP_DEBUG']) && strtolower($_ENV['APP_DEBUG']) === 'true'),
    // allow self-signed / skip peer verification for debugging only (set MAIL_ALLOW_SELF_SIGNED=true in .env to enable)
    'allow_self_signed' => (isset($_ENV['MAIL_ALLOW_SELF_SIGNED']) && strtolower($_ENV['MAIL_ALLOW_SELF_SIGNED']) === 'true'),
    'log_file'   => __DIR__ . '/../storage/logs/mail.log'
];

function logMail($msg) {
    global $mail_cfg;
    $t = '[' . date('Y-m-d H:i:s') . '] ' . $msg . PHP_EOL;
    @file_put_contents($mail_cfg['log_file'], $t, FILE_APPEND | LOCK_EX);
}

function sendMail($toEmail, $toName, $subject, $htmlBody, $altBody = '', $attachments = []) {
    global $mail_cfg, $hasVendor;

    if (!filter_var($toEmail, FILTER_VALIDATE_EMAIL)) {
        return "Invalid recipient email address: {$toEmail}";
    }

    if ($hasVendor && class_exists('\PHPMailer\PHPMailer\PHPMailer')) {
        try {
            $mail = new \PHPMailer\PHPMailer\PHPMailer(true);

            if (!empty($mail_cfg['debug'])) {
                $mail->SMTPDebug = 2;
                $mail->Debugoutput = 'html';
            } else {
                $mail->SMTPDebug = 0;
            }

            $mail->isSMTP();
            $mail->Host       = $mail_cfg['host'];
            $mail->SMTPAuth   = true;
            $mail->Username   = $mail_cfg['username'];
            $mail->Password   = $mail_cfg['password'];

            if ($mail_cfg['secure'] === 'ssl') {
                $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
            } else {
                $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
            }

            $mail->Port = $mail_cfg['port'];

            // optional: allow self-signed for debugging (NOT recommended for production)
            if (!empty($mail_cfg['allow_self_signed'])) {
                $mail->SMTPOptions = [
                    'ssl' => [
                        'verify_peer' => false,
                        'verify_peer_name' => false,
                        'allow_self_signed' => true
                    ]
                ];
            }

            $mail->setFrom($mail_cfg['from_email'], $mail_cfg['from_name']);
            $mail->addAddress($toEmail, $toName);

            // Attachments array expected as list of absolute paths or ['path' => 'name.pdf']
            foreach ($attachments as $k => $v) {
                if (is_string($k)) {
                    // associative: path => name
                    $path = $k;
                    $name = $v;
                } else {
                    $path = $v;
                    $name = null;
                }
                if (file_exists($path)) {
                    $mail->addAttachment($path, $name);
                } else {
                    logMail("Warning: attachment not found: {$path}");
                }
            }

            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body    = $htmlBody;
            $mail->AltBody = $altBody ?: strip_tags($htmlBody);

            $mail->send();
            logMail("Sent email to {$toEmail} subject: {$subject}");
            return true;
        } catch (Throwable $e) {
            $err = $e->getMessage();
            logMail("PHPMailer error sending to {$toEmail}: {$err}");
            return 'PHPMailer Error: ' . ($err ?: 'Unknown error');
        }
    }

    // fallback to mail()
    $headers = [];
    $headers[] = 'MIME-Version: 1.0';
    $headers[] = 'Content-type: text/html; charset=UTF-8';
    $headers[] = 'From: ' . $mail_cfg['from_name'] . ' <' . $mail_cfg['from_email'] . '>';
    $headers[] = 'Reply-To: ' . $mail_cfg['from_email'];
    $headers[] = 'X-Mailer: PHP/' . phpversion();

    $headers_str = implode("\r\n", $headers);

    $sent = @mail($toEmail, $subject, $htmlBody, $headers_str);
    if ($sent) {
        logMail("Fallback mail() accepted for {$toEmail} subject: {$subject}");
        return true;
    }

    logMail("mail() failed for {$toEmail}");
    return 'mail() failed: no mailer available and PHPMailer not installed.';
}
