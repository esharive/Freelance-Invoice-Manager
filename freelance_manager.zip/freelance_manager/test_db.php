<?php
require_once __DIR__ . '/config/db.php';
echo 'DB connection OK — ' . $dbname;
?>
