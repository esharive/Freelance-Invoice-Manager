<?php
// payments/list.php
// Fully self-contained payments list (no layout.php).
// - Bootstrap 5 responsive layout
// - Interactive JS: search, filter, export visible rows to CSV, animated entrance
// - Shows payments and totals by currency
// Place in: /freelance_manager/payments/list.php

session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: /freelance_manager/login.php');
    exit;
}
require_once __DIR__ . '/../config/db.php';

$uid = (int)($_SESSION['user_id'] ?? 0);

// helpers
function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
function get_currency_symbol($code) {
    $map = [
        'NGN' => '₦', 'USD' => '$', 'EUR' => '€', 'GBP' => '£',
        'JPY' => '¥', 'CNY' => '¥', 'CAD' => 'C$', 'AUD' => 'A$'
    ];
    return $map[$code] ?? $code;
}

// fetch payments for this user's invoices
$stmt = $conn->prepare("
  SELECT pay.id AS payment_id, pay.amount, pay.currency, pay.method, pay.transaction_ref, pay.paid_at,
         i.id AS invoice_id, i.invoice_number, i.currency AS invoice_currency, i.amount AS invoice_amount,
         p.title AS project_title, c.name AS client_name
  FROM payments pay
  JOIN invoices i ON pay.invoice_id = i.id
  JOIN projects p ON i.project_id = p.id
  JOIN clients c ON p.client_id = c.id
  WHERE c.user_id = ?
  ORDER BY pay.paid_at DESC, pay.id DESC
");
if (!$stmt) {
    die('DB prepare error: ' . h($conn->error));
}
$stmt->bind_param('i', $uid);
$stmt->execute();
$res = $stmt->get_result();

// totals grouped by currency
$totStmt = $conn->prepare("
  SELECT pay.currency AS currency, IFNULL(SUM(pay.amount),0) AS total
  FROM payments pay
  JOIN invoices i ON pay.invoice_id = i.id
  JOIN projects p ON i.project_id = p.id
  JOIN clients c ON p.client_id = c.id
  WHERE c.user_id = ?
  GROUP BY pay.currency
");
$totStmt->bind_param('i', $uid);
$totStmt->execute();
$totRes = $totStmt->get_result();
$totals_by_currency = [];
while ($tr = $totRes->fetch_assoc()) {
    $totals_by_currency[$tr['currency']] = (float)$tr['total'];
}

// collect currencies present (for filter)
$currencyList = array_keys($totals_by_currency);
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Payments — Freelance Manager</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">

  <!-- Bootstrap and icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    :root{
      --bg: #f4f7fb;
      --card: #ffffff;
      --brand: #0d6efd;
      --muted: #6c757d;
      --radius: 12px;
    }
    body{font-family:Inter,system-ui,Segoe UI,Arial;background:linear-gradient(180deg,var(--bg),#eef4ff);color:#0b1a2b;margin:0;}
    .container{max-width:1200px}
    .app-head{display:flex;justify-content:space-between;align-items:center;gap:1rem;padding:22px 0}
    .hero-pill{background:linear-gradient(90deg,var(--brand),#0b5ed7);color:#fff;padding:.5rem .9rem;border-radius:10px;font-weight:700;display:inline-flex;gap:.6rem;align-items:center}
    .card-surface{background:var(--card);border-radius:12px;padding:18px;box-shadow:0 10px 30px rgba(11,78,200,0.06);border:1px solid rgba(11,78,200,0.04)}
    .small-muted{color:var(--muted)}
    .table-hover-animated tbody tr{transition:transform .18s ease, box-shadow .18s ease}
    .table-hover-animated tbody tr:hover{transform:translateY(-6px);box-shadow:0 10px 30px rgba(11,78,200,0.06)}
    .currency-pill{padding:.28rem .6rem;border-radius:999px;font-weight:700;font-size:.9rem;background:#f1f7ff;color:#084298}
    .fade-in{opacity:0;transform:translateY(8px);transition:all .44s cubic-bezier(.2,.9,.3,1)}
    .fade-in.in{opacity:1;transform:none}
    .export-btn{min-width:170px}
    @media (max-width:767px){ .app-head {flex-direction:column;align-items:flex-start} .hero-pill{margin-bottom:.6rem} }
  </style>
</head>
<body>
  <div class="container py-5">
    <div class="app-head fade-in" id="head">
      <div>
        <div class="hero-pill"><i class="bi bi-cash-stack"></i> Payments</div>
        <div class="small-muted mt-2">List of recorded payments with per-currency totals and quick actions</div>
      </div>
      <div class="d-flex gap-2">
        <a href="/freelance_manager/invoices/list.php" class="btn btn-outline-secondary btn-sm"><i class="bi bi-receipt"></i> Invoices</a>
        <a href="/freelance_manager/index.php" class="btn btn-outline-primary btn-sm"><i class="bi bi-speedometer2"></i> Dashboard</a>
      </div>
    </div>

    <div class="card-surface mt-3 fade-in" id="card">
      <div class="d-flex flex-column flex-md-row justify-content-between align-items-start gap-3 mb-3">
        <div class="d-flex gap-2 w-100 flex-wrap align-items-center">
          <div class="input-group" style="min-width:260px; max-width:520px;">
            <span class="input-group-text bg-white border-0"><i class="bi bi-search"></i></span>
            <input id="q" class="form-control" placeholder="Search by client, project, invoice or tx ref">
          </div>

          <select id="currencyFilter" class="form-select" style="width:180px;">
            <option value="">All currencies</option>
            <?php foreach ($currencyList as $c): ?>
              <option value="<?php echo h($c); ?>"><?php echo h($c . ' — ' . get_currency_symbol($c)); ?></option>
            <?php endforeach; ?>
          </select>

          <div class="ms-auto d-flex gap-2">
            <button id="exportBtn" class="btn btn-outline-success export-btn"><i class="bi bi-download"></i> Export visible CSV</button>
            <button id="refreshBtn" class="btn btn-outline-secondary"><i class="bi bi-arrow-clockwise"></i> Refresh</button>
          </div>
        </div>
      </div>

      <?php if ($res->num_rows === 0): ?>
        <div class="text-center p-4 small-muted">No payments recorded yet.</div>
      <?php else: ?>
        <div class="table-responsive">
          <table class="table table-hover-animated align-middle" id="paymentsTable">
            <thead>
              <tr>
                <th style="width:80px">ID</th>
                <th>Invoice</th>
                <th>Project</th>
                <th>Client</th>
                <th class="text-end">Amount</th>
                <th>Method</th>
                <th>Transaction</th>
                <th>Paid at</th>
                <th style="width:120px">Actions</th>
              </tr>
            </thead>
            <tbody id="tb">
              <?php while ($r = $res->fetch_assoc()): ?>
                <tr data-client="<?php echo h(strtolower($r['client_name'])); ?>"
                    data-project="<?php echo h(strtolower($r['project_title'])); ?>"
                    data-invoice="<?php echo h(strtolower($r['invoice_number'] ?: $r['invoice_id'])); ?>"
                    data-tx="<?php echo h(strtolower($r['transaction_ref'])); ?>"
                    data-currency="<?php echo h($r['currency']); ?>">

                  <td><?php echo (int)$r['payment_id']; ?></td>

                  <td>
                    <a href="/freelance_manager/invoices/view.php?id=<?php echo (int)$r['invoice_id']; ?>" target="_blank">
                      <?php echo h($r['invoice_number'] ?: '#' . $r['invoice_id']); ?>
                    </a>
                    <div class="small-muted"><?php echo h($r['invoice_currency']); ?></div>
                  </td>

                  <td><?php echo h($r['project_title']); ?></td>
                  <td><?php echo h($r['client_name']); ?></td>

                  <td class="text-end">
                    <span class="currency-pill"><?php echo h($r['currency']); ?></span>
                    <div style="font-weight:700"><?php echo get_currency_symbol($r['currency']) . ' ' . number_format((float)$r['amount'],2); ?></div>
                  </td>

                  <td><?php echo h($r['method']); ?></td>
                  <td><?php echo h($r['transaction_ref']); ?></td>
                  <td><?php echo h($r['paid_at']); ?></td>
                  <td>
                    <div class="d-flex gap-2">
                      <a class="btn btn-sm btn-outline-secondary" href="/freelance_manager/invoices/view.php?id=<?php echo (int)$r['invoice_id']; ?>&receipt=<?php echo (int)$r['payment_id']; ?>" target="_blank" title="Open receipt"><i class="bi bi-file-earmark-text"></i></a>
                      <button class="btn btn-sm btn-outline-primary" onclick="copyRow(this)" title="Copy amount"><i class="bi bi-clipboard"></i></button>
                    </div>
                  </td>
                </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>

        <?php if (!empty($totals_by_currency)): ?>
          <div class="mt-4 row g-3">
            <div class="col-md-7">
              <div class="card p-3">
                <h6 class="mb-3">Totals received (by currency)</h6>
                <div class="row g-2">
                  <?php foreach ($totals_by_currency as $cur => $sum): ?>
                    <div class="col-6 col-md-4">
                      <div class="p-3" style="background:linear-gradient(180deg,#fff,#fbfdff);border-radius:10px;border:1px solid rgba(11,78,200,0.04)">
                        <div class="small-muted"><?php echo h($cur); ?> — <?php echo h(get_currency_symbol($cur)); ?></div>
                        <div style="font-weight:700;font-size:1.15rem"><?php echo get_currency_symbol($cur) . ' ' . number_format($sum,2); ?></div>
                      </div>
                    </div>
                  <?php endforeach; ?>
                </div>
              </div>
            </div>

            <div class="col-md-5">
              <div class="card p-3 small-muted">
                <h6 class="mb-2">Quick tips</h6>
                <ul class="small">
                  <li>Click invoice to open it and view attached receipts.</li>
                  <li>Use the search box to quickly find payments by client, project, invoice or transaction ref.</li>
                  <li>Export visible rows to CSV to share or import into bookkeeping tools.</li>
                </ul>
              </div>
            </div>
          </div>
        <?php endif; ?>

      <?php endif; ?>
    </div>

    <div class="text-center small-muted mt-4">Freelance Manager — payments overview</div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function(){
      // animation entrance
      document.querySelectorAll('.fade-in').forEach((el,i)=> setTimeout(()=> el.classList.add('in'), 60 + i*60));

      const q = document.getElementById('q');
      const currencyFilter = document.getElementById('currencyFilter');
      const tb = document.getElementById('tb');
      const rows = Array.from(tb ? tb.querySelectorAll('tr') : []);
      const refreshBtn = document.getElementById('refreshBtn');
      const exportBtn = document.getElementById('exportBtn');

      function filter() {
        const qv = q.value.trim().toLowerCase();
        const cur = currencyFilter.value.trim();
        rows.forEach(r => {
          let show = true;
          if (qv) {
            const texts = [
              r.dataset.client || '',
              r.dataset.project || '',
              r.dataset.invoice || '',
              r.dataset.tx || ''
            ];
            show = texts.some(t => t.indexOf(qv) !== -1);
          }
          if (show && cur) show = (r.dataset.currency === cur);
          r.style.display = show ? '' : 'none';
        });
      }

      q.addEventListener('input', debounce(filter, 160));
      currencyFilter.addEventListener('change', filter);

      refreshBtn.addEventListener('click', function(){
        this.classList.add('active');
        setTimeout(()=> this.classList.remove('active'), 600);
        filter();
      });

      // Export visible rows to CSV
      exportBtn.addEventListener('click', function(){
        const visibleRows = rows.filter(r => r.style.display !== 'none');
        if (visibleRows.length === 0) { alert('No rows visible to export.'); return; }
        const csv = [];
        const header = ['Payment ID','Invoice','Invoice Amount','Currency','Paid Amount','Method','Transaction Ref','Paid at','Project','Client'];
        csv.push(header.join(','));
        visibleRows.forEach(r => {
          const cells = Array.from(r.querySelectorAll('td'));
          const paymentId = cells[0].innerText.trim();
          const invoiceLink = cells[1].querySelector('a');
          const invoiceText = invoiceLink ? invoiceLink.innerText.trim() : cells[1].innerText.trim();
          const invoiceCurrency = cells[1].querySelector('.small-muted') ? cells[1].querySelector('.small-muted').innerText.trim() : '';
          const project = cells[2].innerText.trim();
          const client = cells[3].innerText.trim();
          const amount = cells[4].querySelector('div') ? cells[4].querySelector('div').innerText.trim() : cells[4].innerText.trim();
          const method = cells[5].innerText.trim();
          const tx = cells[6].innerText.trim();
          const paidAt = cells[7].innerText.trim();
          const row = [ paymentId, quoteCSV(invoiceText), invoiceCurrency, amount, method, quoteCSV(tx), paidAt, quoteCSV(project), quoteCSV(client) ];
          // align with header (note: invoice amount separate column omitted for simplicity)
          csv.push([paymentId, invoiceText, invoiceCurrency, amount, method, tx, paidAt, project, client].map(quoteCSV).join(','));
        });
        downloadCSV(csv.join('\n'), 'payments_export_' + new Date().toISOString().slice(0,19).replace(/[:T]/g,'_') + '.csv');
      });

      // helper to copy amount/row (button within row)
      window.copyRow = function(btn) {
        const tr = btn.closest('tr');
        if (!tr) return;
        const amountEl = tr.querySelector('td:nth-child(5) div');
        const text = amountEl ? amountEl.innerText.trim() : tr.cells[4].innerText.trim();
        navigator.clipboard?.writeText(text).then(()=> {
          btn.innerHTML = '<i class="bi bi-check2"></i>';
          setTimeout(()=> btn.innerHTML = '<i class="bi bi-clipboard"></i>', 1200);
        }).catch(()=> alert('Copy failed'));
      };

      // CSV helpers
      function quoteCSV(val) {
        if (val == null) return '""';
        val = String(val).replace(/"/g, '""');
        return '"' + val + '"';
      }
      function downloadCSV(content, filename) {
        const blob = new Blob([content], {type: 'text/csv;charset=utf-8;'});
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url; a.download = filename; document.body.appendChild(a); a.click();
        setTimeout(()=> { URL.revokeObjectURL(url); a.remove(); }, 200);
      }

      function debounce(fn, ms){ let t; return (...a)=>{ clearTimeout(t); t=setTimeout(()=>fn(...a), ms); }; }
    });
  </script>
</body>
</html>
