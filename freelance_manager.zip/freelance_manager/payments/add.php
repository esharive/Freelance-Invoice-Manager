<?php
// payments/add.php - record a payment for an invoice (safer UI + modern interactions)
session_start();
if (!isset($_SESSION['user_id'])) { header('Location: /my_works/freelance_manager/login.php'); exit; }
require_once __DIR__ . '/../config/db.php';

// Always redirect to item-level payments
$id = isset($_GET['invoice_id']) ? (int)$_GET['invoice_id'] : 0;
header("Location: /my_works/freelance_manager/invoices/mark_paid.php?id=" . $id);
exit;

$uid = (int)($_SESSION['user_id'] ?? 0);
$errors = [];
$sent_ok = false;

// CSRF token
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
$csrf_token = $_SESSION['csrf_token'];

// invoice id from GET or POST
$invoice_id = isset($_GET['invoice_id']) ? (int)$_GET['invoice_id'] : (int)($_POST['invoice_id'] ?? 0);
if (!$invoice_id) {
    die('No invoice id provided.');
}

// helper
function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

// fetch invoice with ownership check
$chk = $conn->prepare("
  SELECT i.id, i.amount AS invoice_amount, i.currency AS invoice_currency, i.status AS invoice_status,
         p.title AS project_title, c.name AS client_name
  FROM invoices i
  JOIN projects p ON i.project_id = p.id
  JOIN clients c ON p.client_id = c.id
  WHERE i.id = ? AND c.user_id = ?
  LIMIT 1
");
if (!$chk) {
    die('DB error: ' . h($conn->error));
}
$chk->bind_param('ii', $invoice_id, $uid);
$chk->execute();
$inv = $chk->get_result()->fetch_assoc();
if (!$inv) die('Invoice not found or access denied.');

// fetch current payments list and totals
$ps = $conn->prepare("SELECT id, amount, currency, method, transaction_ref, paid_at FROM payments WHERE invoice_id = ? ORDER BY paid_at ASC");
$ps->bind_param('i', $invoice_id);
$ps->execute();
$payments_list = $ps->get_result();

// total paid / balance
$sumStmt = $conn->prepare("SELECT IFNULL(SUM(amount),0) AS total_paid FROM payments WHERE invoice_id = ?");
$sumStmt->bind_param('i', $invoice_id);
$sumStmt->execute();
$paid_row = $sumStmt->get_result()->fetch_assoc();
$total_paid = (float)($paid_row['total_paid'] ?? 0.0);
$balance = round((float)$inv['invoice_amount'] - $total_paid, 2);

// currency options - default to invoice currency first
$currency_options = [$inv['invoice_currency']];
foreach (['NGN','USD','EUR','GBP'] as $c) if (!in_array($c, $currency_options)) $currency_options[] = $c;

// POST handling
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf_token) {
        $errors[] = 'Invalid request (CSRF). Please reload and try again.';
    }

    $amount_raw = trim($_POST['amount'] ?? '');
    $amount = $amount_raw === '' ? null : (float)$amount_raw;
    $currency = strtoupper(trim($_POST['currency'] ?? $inv['invoice_currency']));
    $method = trim($_POST['method'] ?? '');
    $transaction_ref = trim($_POST['transaction_ref'] ?? '');
    $paid_at_input = trim($_POST['paid_at'] ?? '');
    $paid_at = $paid_at_input ? date('Y-m-d H:i:s', strtotime($paid_at_input)) : date('Y-m-d H:i:s');

    // server-side recompute totals (race condition safety)
    $sumStmt->execute();
    $paid_row2 = $sumStmt->get_result()->fetch_assoc();
    $current_total_paid = (float)($paid_row2['total_paid'] ?? 0.0);
    $current_balance = round((float)$inv['invoice_amount'] - $current_total_paid, 2);

    // validations (mirror your previous business rules)
    if ($amount === null || $amount <= 0) $errors[] = 'Enter a valid payment amount.';
    if ($currency === '') $errors[] = 'Currency required.';
    if ($method === '') $errors[] = 'Payment method required.';

    if ($current_balance <= 0) {
        $errors[] = 'This invoice is already fully paid. No further payments are required.';
    }

    if ($amount !== null && $amount > $current_balance) {
        $errors[] = 'Payment amount exceeds remaining balance. Enter an amount up to ' . number_format($current_balance, 2) . ' (or adjust the invoice).';
    }

    // duplicate tx ref check (if provided)
    if ($transaction_ref !== '') {
        $dup = $conn->prepare("SELECT COUNT(*) AS cnt FROM payments WHERE invoice_id = ? AND transaction_ref = ?");
        $dup->bind_param('is', $invoice_id, $transaction_ref);
        $dup->execute();
        $dup_row = $dup->get_result()->fetch_assoc();
        if ((int)($dup_row['cnt'] ?? 0) > 0) {
            $errors[] = 'A payment with that transaction reference already exists for this invoice.';
        }
    }

    if (empty($errors)) {
        $ins = $conn->prepare("
          INSERT INTO payments (invoice_id, amount, currency, method, transaction_ref, paid_at)
          VALUES (?, ?, ?, ?, ?, ?)
        ");
        if (!$ins) {
            $errors[] = 'DB error (prepare): ' . h($conn->error);
        } else {
            $ins->bind_param('idssss', $invoice_id, $amount, $currency, $method, $transaction_ref, $paid_at);
            if ($ins->execute()) {
                // recompute total paid and update invoice status
                $sumStmt->execute();
                $row2 = $sumStmt->get_result()->fetch_assoc();
                $new_total_paid = (float)($row2['total_paid'] ?? 0.0);

                if (round($new_total_paid, 2) >= round((float)$inv['invoice_amount'], 2)) {
                    $now = date('Y-m-d H:i:s');
                    $upd = $conn->prepare("UPDATE invoices SET status='paid', paid_at = ? WHERE id = ?");
                    $upd->bind_param('si', $now, $invoice_id);
                    $upd->execute();
                } elseif ($new_total_paid > 0) {
                    $upd = $conn->prepare("UPDATE invoices SET status='partially_paid', paid_at = NULL WHERE id = ?");
                    $upd->bind_param('i', $invoice_id);
                    $upd->execute();
                }

                // redirect back to invoice view (preserves UX)
                header('Location: ../invoices/view.php?id=' . $invoice_id);
                exit;
            } else {
                $errors[] = 'Could not record payment. Try again.';
            }
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Record Payment — Invoice #<?php echo h($inv['id']); ?></title>

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    :root{
      --primary: #0b5cff;
      --muted: #6c757d;
      --card-radius: 14px;
    }
    body{background:linear-gradient(180deg,#f6f9ff, #fbfcff);font-family:Inter,system-ui,Arial;color:#0b1a2b;padding:28px}
    .app-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px}
    .app-card{border-radius:var(--card-radius);box-shadow:0 10px 30px rgba(11,78,200,0.06);background:#fff;padding:18px}
    .muted{color:var(--muted)}
    .accent{color:var(--primary)}
    .hero {padding:18px;border-radius:12px;background:linear-gradient(90deg, rgba(11,78,200,0.06), rgba(11,78,200,0.02));box-shadow:0 8px 20px rgba(11,78,200,0.03);margin-bottom:18px}
    .fade-up{opacity:0;transform:translateY(14px);transition:all .5s cubic-bezier(.2,.9,.3,1)}
    .fade-up.visible{opacity:1;transform:none}
    .currency-badge{font-weight:700;padding:.25rem .55rem;border-radius:8px;background:#eef5ff;color:var(--primary)}
    .small-muted{font-size:.9rem;color:var(--muted)}
    .form-floating .form-control:focus{box-shadow:none;border-color:var(--primary)}
    .btn-attach{border-radius:10px}
  </style>
</head>
<body>
  <div class="container">
    <div class="app-header fade-up" id="topHero">
      <div>
        <h2 class="mb-1">Record Payment</h2>
        <div class="muted small">Invoice #<?php echo h($inv['id']); ?> — <?php echo h($inv['project_title']); ?></div>
      </div>
      <div class="text-end">
        <a href="/my_works/freelance_manager/invoices/view.php?id=<?php echo (int)$inv['id']; ?>" class="btn btn-outline-secondary btn-sm me-2"><i class="bi bi-eye"></i> Open invoice</a>
        <a href="/my_works/freelance_manager/payments/list.php" class="btn btn-outline-primary btn-sm"><i class="bi bi-list"></i> Payments</a>
      </div>
    </div>

    <?php if (!empty($errors)): ?>
      <div class="alert alert-danger fade-up visible">
        <strong>There were problems:</strong>
        <ul class="mb-0">
          <?php foreach ($errors as $e): ?><li><?php echo h($e); ?></li><?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <div class="row g-4">
      <div class="col-lg-6">
        <div class="app-card fade-up" id="formCard">
          <div class="d-flex justify-content-between align-items-start mb-3">
            <div>
              <h5 class="mb-0">Payment details</h5>
              <div class="small-muted">Record a payment for this invoice</div>
            </div>
            <div class="text-end">
              <div class="currency-badge"><?php echo h($inv['invoice_currency']); ?></div>
              <div class="small-muted">Balance: <strong><?php echo number_format($balance,2); ?></strong></div>
            </div>
          </div>

          <form id="paymentForm" method="post" novalidate>
            <input type="hidden" name="csrf_token" value="<?php echo h($csrf_token); ?>">
            <input type="hidden" name="invoice_id" value="<?php echo (int)$inv['id']; ?>">

            <div class="mb-3">
              <label class="form-label">Amount received now</label>
              <div class="input-group">
                <span class="input-group-text"><?php echo h($inv['invoice_currency']); ?></span>
                <input id="amount" name="amount" type="number" step="0.01" class="form-control" required
                  value="<?php echo h($balance > 0 ? number_format($balance,2,'.','') : ''); ?>" />
              </div>
              <div class="small-muted mt-1">Enter up to remaining balance: <strong id="remainingText"><?php echo number_format($balance,2); ?></strong></div>
            </div>

            <div class="row gx-2">
              <div class="col-md-6 mb-3">
                <label class="form-label">Currency</label>
                <select id="currency" name="currency" class="form-select" required>
                  <?php foreach ($currency_options as $c): ?>
                    <option value="<?php echo h($c); ?>" <?php echo $c === $inv['invoice_currency'] ? 'selected' : ''; ?>><?php echo h($c); ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="col-md-6 mb-3">
                <label class="form-label">Method</label>
                <select name="method" class="form-select" required>
                  <option value="">-- choose method --</option>
                  <option value="Bank Transfer">Bank Transfer</option>
                  <option value="Cash">Cash</option>
                  <option value="Paystack">Paystack</option>
                  <option value="Stripe">Stripe</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>

            <div class="mb-3">
              <label class="form-label">Transaction reference (optional)</label>
              <div class="input-group">
                <input id="txref" name="transaction_ref" class="form-control" placeholder="Bank ref or TX12345">
                <button type="button" class="btn btn-outline-secondary" id="genRefBtn" title="Generate random reference"><i class="bi bi-shuffle"></i></button>
              </div>
              <div class="small-muted mt-1">Optional but helpful for reconciliation.</div>
            </div>

            <div class="mb-3">
              <label class="form-label">Paid at</label>
              <input name="paid_at" type="datetime-local" class="form-control" value="<?php echo date('Y-m-d\TH:i'); ?>">
            </div>

            <div class="d-flex gap-2">
              <button id="submitBtn" type="submit" class="btn btn-primary btn-attach"><i class="bi bi-check2-circle"></i> Record Payment</button>
              <a class="btn btn-outline-secondary" href="/my_works/freelance_manager/invoices/view.php?id=<?php echo (int)$inv['id']; ?>">Cancel</a>
            </div>
          </form>
        </div>
      </div>

      <div class="col-lg-6">
        <div class="app-card fade-up" id="paymentsCard">
          <h6 class="mb-3">Existing payments</h6>
          <div class="small-muted mb-2">Payments already recorded for this invoice</div>

          <?php if ($payments_list->num_rows === 0): ?>
            <div class="text-center small-muted py-4">No payments recorded yet.</div>
          <?php else: ?>
            <div style="max-height:420px;overflow:auto">
              <table class="table table-sm">
                <thead class="table-light sticky-top">
                  <tr>
                    <th>#</th>
                    <th class="text-end">Amount</th>
                    <th>Currency</th>
                    <th>Method</th>
                    <th>Ref</th>
                    <th>Paid at</th>
                  </tr>
                </thead>
                <tbody>
                  <?php while ($row = $payments_list->fetch_assoc()): ?>
                    <tr>
                      <td><?php echo (int)$row['id']; ?></td>
                      <td class="text-end"><?php echo number_format($row['amount'],2); ?></td>
                      <td><?php echo h($row['currency']); ?></td>
                      <td><?php echo h($row['method']); ?></td>
                      <td><span class="small txref-click" style="cursor:pointer" title="Click to copy"><?php echo h($row['transaction_ref']); ?></span></td>
                      <td><?php echo h($row['paid_at']); ?></td>
                    </tr>
                  <?php endwhile; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>

        </div>
      </div>
    </div>

    <div class="text-center small-muted mt-4">Tip: Record exact transaction references for faster reconciliation. Use the shuffle button to generate a quick reference if none is available.</div>
  </div>

  <!-- confirmation modal -->
  <div class="modal fade" id="confirmModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content" style="border-radius:12px;">
        <div class="modal-header">
          <h5 class="modal-title">Confirm payment</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <p class="mb-0">You're about to record a payment of <strong id="confirmAmount"></strong> for invoice <strong>#<?php echo (int)$inv['id']; ?></strong>. Proceed?</p>
        </div>
        <div class="modal-footer">
          <button id="confirmCancel" type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button id="confirmOk" type="button" class="btn btn-primary">Yes, record payment</button>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // small entrance animations
    document.addEventListener('DOMContentLoaded', ()=> {
      document.querySelectorAll('.fade-up').forEach((el,i)=> setTimeout(()=>el.classList.add('visible'), 80 + i*60));
    });

    const balance = <?php echo json_encode((float)$balance); ?>;
    const amountInput = document.getElementById('amount');
    const remainingText = document.getElementById('remainingText');
    const txrefInput = document.getElementById('txref');
    const genRefBtn = document.getElementById('genRefBtn');
    const paymentForm = document.getElementById('paymentForm');
    const submitBtn = document.getElementById('submitBtn');

    // update remaining display when amount edited
    amountInput.addEventListener('input', () => {
      const v = parseFloat(amountInput.value || 0);
      const rem = (balance - (isNaN(v) ? 0 : v)).toFixed(2);
      remainingText.textContent = rem >= 0 ? rem : rem;
      if (!isNaN(v) && v > balance) {
        amountInput.classList.add('is-invalid');
      } else {
        amountInput.classList.remove('is-invalid');
      }
    });

    // generate pseudo-random tx ref
    genRefBtn.addEventListener('click', () => {
      const r = 'TX' + Math.random().toString(36).substring(2,10).toUpperCase();
      txrefInput.value = r;
      txrefInput.focus();
      txrefInput.select();
    });

    // copy tx refs in the payments list
    document.querySelectorAll('.txref-click').forEach(el => {
      el.addEventListener('click', async () => {
        try {
          await navigator.clipboard.writeText(el.textContent.trim());
          el.classList.add('text-success');
          setTimeout(()=>el.classList.remove('text-success'), 900);
        } catch (e) { console.warn('Clipboard failed', e); }
      });
    });

    // disable double-submit + confirmation modal
    paymentForm.addEventListener('submit', (ev) => {
      ev.preventDefault();
      // basic client-side validation
      const amountVal = parseFloat(amountInput.value || 0);
      if (isNaN(amountVal) || amountVal <= 0) { amountInput.focus(); return; }
      if (amountVal > balance) {
        if (!confirm('Entered amount exceeds remaining balance. Continue anyway?')) return;
      }
      // show confirm modal
      const confirmModal = new bootstrap.Modal(document.getElementById('confirmModal'));
      document.getElementById('confirmAmount').textContent = amountVal.toFixed(2) + ' ' + (document.getElementById('currency').value || '');
      // handle confirm ok
      const okBtn = document.getElementById('confirmOk');
      function onOk(){
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Recording...';
        paymentForm.submit();
      }
      okBtn.addEventListener('click', onOk, {once:true});
      confirmModal.show();
    });
  </script>
</body>
</html>
