<?php
// clients/edit.php
session_start();

// Compute a robust base path for building links (auto-detect where this script lives).
$base_dir = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
$BASE_PATH = $base_dir === '/' ? '' : $base_dir;

if (!isset($_SESSION['user_id'])) { header('Location: ' . $BASE_PATH . '/login.php'); exit; }
require_once __DIR__ . '/../config/db.php';

$uid = (int)($_SESSION['user_id']);
$errors = [];
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// small helper
function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

// CSRF token (simple)
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
}
$csrf_token = $_SESSION['csrf_token'];

// fetch client
if ($id) {
    $stmt = $conn->prepare("SELECT id,name,email,phone,company,notes FROM clients WHERE id=? AND user_id=? LIMIT 1");
    if (!$stmt) { die('DB error: ' . htmlspecialchars($conn->error)); }
    $stmt->bind_param('ii', $id, $uid);
    $stmt->execute();
    $res = $stmt->get_result();
    $client = $res->fetch_assoc();
    $stmt->close();
    if (!$client) {
        die('Client not found or access denied.');
    }
} else {
    die('No client id.');
}

// Handle POST (regular or AJAX)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // JSON/AJAX detection
    $isAjax = (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest');

    // CSRF
    $posted_csrf = $_POST['csrf_token'] ?? '';
    if (!$posted_csrf || !hash_equals($csrf_token, $posted_csrf)) {
        $errors[] = 'Invalid request (CSRF). Please refresh and try again.';
    }

    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $company = trim($_POST['company'] ?? '');
    $notes = trim($_POST['notes'] ?? '');

    if ($name === '') $errors[] = 'Client name is required.';
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Email address is not valid.';

    if (empty($errors)) {
        $upd = $conn->prepare("UPDATE clients SET name=?, email=?, phone=?, company=?, notes=? WHERE id=? AND user_id=?");
        if (!$upd) {
            $errors[] = 'DB prepare failed: ' . $conn->error;
        } else {
            // bind types: s = string, i = int
            $upd->bind_param('sssssii', $name, $email, $phone, $company, $notes, $id, $uid);
            if ($upd->execute()) {
                // Success: respond according to request type
                $redirectUrl = $BASE_PATH . '/clients/list.php';
                if ($isAjax) {
                    header('Content-Type: application/json');
                    echo json_encode(['success' => true, 'message' => 'Client updated', 'redirect' => $redirectUrl]);
                    exit;
                } else {
                    header('Location: ' . $redirectUrl);
                    exit;
                }
            } else {
                $errors[] = 'Could not update client. Try again.';
            }
            $upd->close();
        }
    }

    if ($isAjax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'errors' => $errors]);
        exit;
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Edit Client — Freelance Manager</title>

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    :root{
      --accent:#0d6efd;
      --muted:#6c757d;
      --card-bg: #ffffff;
      --page-bg: #f4f7fb;
    }
    body{ background: linear-gradient(180deg,var(--page-bg),#eef4ff); color:#0b1a2b; font-family:Inter,system-ui,Arial,Helvetica,sans-serif; }
    .container{ max-width:980px; }
    .app-card { background:var(--card-bg); border-radius:12px; box-shadow:0 10px 30px rgba(11,78,200,0.06); border:1px solid rgba(11,78,200,0.04); }
    .brand-pill { background:linear-gradient(135deg,var(--accent),#0b5ed7); color:#fff; padding:8px 12px; border-radius:12px; font-weight:600; display:inline-flex; align-items:center; gap:.5rem; }
    .form-floating > .form-control:focus { box-shadow: none; border-color: var(--accent); }
    .animated-input { transition: transform .22s cubic-bezier(.2,.9,.3,1); }
    .animated-input:focus { transform: translateY(-2px); }
    .btn-primary:focus { box-shadow: 0 6px 18px rgba(13,110,253,0.12); }
    .fade-in { opacity:0; transform:translateY(8px); transition: all .48s cubic-bezier(.2,.9,.3,1); }
    .fade-in.in { opacity:1; transform:none; }
    .shake { animation: shake .6s; }
    @keyframes shake { 10%,90%{transform:translateX(-1px)} 20%,80%{transform:translateX(2px)} 30%,50%,70%{transform:translateX(-4px)} 40%,60%{transform:translateX(4px)} }
    .success-burst { position:fixed; right:20px; top:20px; z-index:1200; display:flex; gap:.75rem; align-items:center; background:#e9f7ef; color:#0b6b3b; padding:12px 16px; border-radius:12px; box-shadow:0 10px 30px rgba(11,78,200,0.06); }
    .muted { color: var(--muted); }
    .small-muted { font-size:.9rem; color:var(--muted); }

    /* tiny responsive polish */
    @media (max-width:767px){
      .brand-pill{ font-size:.95rem; padding:6px 10px; }
    }
  </style>
</head>
<body>
  <div class="container py-5">
    <div class="row mb-4">
      <div class="col-12 d-flex align-items-center justify-content-between">
        <div>
          <div class="brand-pill"><i class="bi bi-people-fill"></i> Clients</div>
          <div class="small-muted mt-2">Edit client profile — smooth, fast and responsive</div>
        </div>
        <div>
          <a href="<?= $BASE_PATH ?>/clients/list.php" class="btn btn-outline-primary"><i class="bi bi-list-ul"></i> All clients</a>
        </div>
      </div>
    </div>

    <div class="app-card p-4 fade-in" id="cardMain">
      <div class="d-flex align-items-start justify-content-between mb-3">
        <div>
          <h3 class="mb-1">Edit client</h3>
          <div class="small-muted">Manage contact details and notes for this client.</div>
        </div>
        <div class="text-end">
          <small class="text-muted">Added ID: <?php echo (int)$client['id']; ?></small>
        </div>
      </div>

      <!-- errors area (server-side) -->
      <?php if (!empty($errors) && $_SERVER['REQUEST_METHOD'] !== 'POST'): ?>
        <div class="alert alert-danger"><?php foreach ($errors as $err) echo '<div>'.h($err).'</div>'; ?></div>
      <?php endif; ?>

      <form id="editClientForm" method="post" novalidate>
        <input type="hidden" name="csrf_token" value="<?php echo h($csrf_token); ?>">
        <div class="row g-3">
          <div class="col-md-6">
            <div class="form-floating">
              <input type="text" name="name" id="name" class="form-control animated-input" placeholder="Client name" required value="<?php echo h($client['name']); ?>">
              <label for="name">Client name *</label>
            </div>
            <div class="form-text small-muted mt-1">Full name for invoices and communication.</div>
          </div>

          <div class="col-md-6">
            <div class="form-floating">
              <input type="email" name="email" id="email" class="form-control animated-input" placeholder="name@example.com" value="<?php echo h($client['email']); ?>">
              <label for="email">Email</label>
            </div>
            <div class="form-text small-muted mt-1">Optional — used for emailing invoices.</div>
          </div>

          <div class="col-md-6">
            <div class="form-floating">
              <input type="tel" name="phone" id="phone" class="form-control animated-input" placeholder="Phone" value="<?php echo h($client['phone']); ?>">
              <label for="phone">Phone</label>
            </div>
          </div>

          <div class="col-md-6">
            <div class="form-floating">
              <input type="text" name="company" id="company" class="form-control animated-input" placeholder="Company" value="<?php echo h($client['company']); ?>">
              <label for="company">Company</label>
            </div>
          </div>

          <div class="col-12">
            <div class="form-floating">
              <textarea name="notes" id="notes" class="form-control animated-input" placeholder="Notes" style="height:110px;"><?php echo h($client['notes']); ?></textarea>
              <label for="notes">Notes</label>
            </div>
            <div class="form-text small-muted mt-1">Internal notes (not visible to client).</div>
          </div>

          <div class="col-12 d-flex gap-2 align-items-center">
            <button id="saveBtn" type="submit" class="btn btn-primary btn-lg shadow-sm">
              <span id="saveSpinner" class="spinner-border spinner-border-sm me-2 d-none" role="status" aria-hidden="true"></span>
              <i class="bi bi-save2 me-1"></i> Save changes
            </button>

            <a href="<?= $BASE_PATH ?>/clients/list.php" class="btn btn-outline-secondary">Cancel</a>

            <div class="ms-auto">
              <a href="<?= $BASE_PATH ?>/clients/delete.php?id=<?php echo (int)$client['id']; ?>" class="btn btn-link text-danger" id="deleteLink"><i class="bi bi-trash"></i> Delete</a>
            </div>
          </div>
        </div>
      </form>
    </div>

    <div class="text-center mt-3 small-muted">Tip: You can also press <kbd>Enter</kbd> inside any field to submit.</div>
  </div>

  <!-- success burst placeholder -->
  <div id="successBurst" class="success-burst d-none">
    <i class="bi bi-check-circle" style="font-size:1.4rem"></i>
    <div>
      <div style="font-weight:700">Saved</div>
      <div class="small-muted">Client updated successfully</div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    (function(){
      // expose base path to JS (safely encoded)
      const BASE_PATH = <?= json_encode($BASE_PATH); ?>;

      const form = document.getElementById('editClientForm');
      const saveBtn = document.getElementById('saveBtn');
      const spinner = document.getElementById('saveSpinner');
      const card = document.getElementById('cardMain');
      const successBurst = document.getElementById('successBurst');

      // entrance animation
      document.addEventListener('DOMContentLoaded', ()=>{ setTimeout(()=>card.classList.add('in'), 80); });

      // client-side live validation hints
      const emailInput = document.getElementById('email');
      emailInput.addEventListener('input', () => {
        const val = emailInput.value.trim();
        if (val && !/^\S+@\S+\.\S+$/.test(val)) {
          emailInput.classList.add('is-invalid');
          emailInput.setCustomValidity('Invalid email');
        } else {
          emailInput.classList.remove('is-invalid');
          emailInput.setCustomValidity('');
        }
      });

      // progressive AJAX submit
      form.addEventListener('submit', async function(e){
        e.preventDefault();

        // basic client-side required
        const nameVal = document.getElementById('name').value.trim();
        if (!nameVal) {
          // shake and show error
          card.classList.add('shake');
          setTimeout(()=>card.classList.remove('shake'), 700);
          document.getElementById('name').focus();
          return;
        }

        // show spinner, disable button
        spinner.classList.remove('d-none');
        saveBtn.disabled = true;

        // prepare form data
        const fd = new FormData(form);

        try {
          const resp = await fetch(window.location.href, {
            method: 'POST',
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
            body: fd,
            credentials: 'same-origin'
          });
          const data = await resp.json();
          if (data.success) {
            // show success animation
            successBurst.classList.remove('d-none');
            setTimeout(()=> successBurst.classList.add('in'), 20);
            setTimeout(()=> {
              successBustRemove();
            }, 1600);

            // redirect if provided
            if (data.redirect) {
              setTimeout(()=> window.location.href = data.redirect, 900);
            } else {
              // otherwise re-enable
              spinner.classList.add('d-none');
              saveBtn.disabled = false;
            }
          } else {
            // build alert from errors
            const list = (data.errors || []).map(e => '<div>' + e.replace(/</g,'&lt;') + '</div>').join('');
            const tmp = document.createElement('div');
            tmp.className = 'alert alert-danger mt-3';
            tmp.innerHTML = '<strong>Could not save:</strong>' + list;
            card.parentElement.insertBefore(tmp, card.nextSibling);
            setTimeout(()=> tmp.scrollIntoView({behavior:'smooth', block:'center'}), 100);
            spinner.classList.add('d-none');
            saveBtn.disabled = false;
          }
        } catch (err) {
          const tmp = document.createElement('div');
          tmp.className = 'alert alert-danger mt-3';
          tmp.innerHTML = '<strong>Network error:</strong> Could not submit form — try again.';
          card.parentElement.insertBefore(tmp, card.nextSibling);
          spinner.classList.add('d-none');
          saveBtn.disabled = false;
        }
      });

      function successBustRemove(){
        successBurst.classList.remove('in');
        successBurst.classList.add('d-none');
      }

      // confirm delete
      const deleteLink = document.getElementById('deleteLink');
      deleteLink.addEventListener('click', function(e){
        if (!confirm('Delete this client and all associated local data? This cannot be undone.')) {
          e.preventDefault();
        }
      });

    })();
  </script>
</body>
</html>
