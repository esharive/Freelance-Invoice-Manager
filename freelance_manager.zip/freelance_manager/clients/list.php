<?php
// clients/list.php
// Responsive, attractive clients list with Bootstrap 5, small animations and JS interactivity.
// Place in /freelance_manager/clients/list.php

session_start();

// Compute a robust base path for building links (auto-detect where this script lives).
$base_dir = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
$BASE_PATH = $base_dir === '/' ? '' : $base_dir;

if (!isset($_SESSION['user_id'])) {
    header('Location: ' . $BASE_PATH . '/login.php');
    exit;
}
require_once __DIR__ . '/../config/db.php';

$uid = (int)$_SESSION['user_id'];

// helper
function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

// fetch clients
$stmt = $conn->prepare("SELECT id,name,email,phone,company,created_at FROM clients WHERE user_id=? ORDER BY created_at DESC");
$stmt->bind_param('i', $uid);
$stmt->execute();
$res = $stmt->get_result();
$clients = [];
while ($row = $res->fetch_assoc()) $clients[] = $row;
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Clients — Freelance Manager</title>

  <!-- Bootstrap & Icons -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    :root{
      --bg:#f4f7fb;
      --card:#fff;
      --brand:#0d6efd;
      --muted:#6c757d;
      --radius:12px;
      --shadow: 0 8px 28px rgba(11,78,200,0.06);
    }
    body{font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Arial;background:var(--bg);color:#0b1a2b}
    .container-wide{max-width:1200px}
    .app-header{background:linear-gradient(90deg,#fff,#fbfdff);padding:18px;border-radius:12px;box-shadow:var(--shadow);margin-bottom:18px}
    .card-panel{background:var(--card);border-radius:var(--radius);box-shadow:var(--shadow);padding:18px}
    .fade-up{opacity:0;transform:translateY(10px);transition:all .42s cubic-bezier(.2,.9,.3,1)}
    .fade-up.in{opacity:1;transform:none}
    .muted{color:var(--muted)}
    .table-hover tbody tr:hover{background:#fbfdff}
    .empty-state{padding:40px;text-align:center;color:var(--muted);background:linear-gradient(180deg,#fff,#fbfdff);border-radius:8px}
    .search-input{max-width:420px}
    @media (max-width:767px){
      .search-input{display:none}
    }
  </style>
</head>
<body>
  <div class="container container-wide py-4">
    <!-- header -->
    <div class="d-flex align-items-center justify-content-between app-header fade-up" id="pageHeader">
      <div>
        <h3 class="mb-0" style="font-weight:700">Clients</h3>
        <div class="muted small">Manage your clients — contact details, companies and quick actions.</div>
      </div>

      <div class="d-flex gap-2 align-items-center">
        <div class="input-group search-input">
          <span class="input-group-text bg-white border-0"><i class="bi bi-search"></i></span>
          <input id="clientSearch" class="form-control border-0" placeholder="Search name, company or email">
        </div>

        <a href="<?= $BASE_PATH ?>/clients/add.php" class="btn btn-primary btn-sm">
          <i class="bi bi-plus-lg me-1"></i> Add client
        </a>
        <a href="<?= $BASE_PATH ?>/index.php" class="btn btn-outline-secondary btn-sm">home</a>
      </div>
    </div>

    <!-- main panel -->
    <div class="card-panel fade-up" id="mainPanel">
      <?php if (empty($clients)): ?>
        <div class="empty-state">
          <h5>No clients yet</h5>
          <p class="muted">Add your first client to start creating client-specific projects and invoices.</p>
          <a href="<?= $BASE_PATH ?>/clients/add.php" class="btn btn-primary mt-2"><i class="bi bi-person-plus me-1"></i> Add client</a>
        </div>
      <?php else: ?>
        <div class="table-responsive">
          <table class="table table-hover align-middle">
            <thead>
              <tr>
                <th class="small text-muted">#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Company</th>
                <th>Added</th>
                <th class="text-end">Actions</th>
              </tr>
            </thead>
            <tbody id="clientsTableBody">
              <?php foreach ($clients as $i => $c): ?>
                <tr data-search="<?php echo h(strtolower($c['name'].' '.$c['company'].' '.$c['email'])); ?>">
                  <td class="small text-muted"><?php echo $i+1; ?></td>
                  <td><strong><?php echo h($c['name']); ?></strong></td>
                  <td><?php if ($c['email']): ?><a href="mailto:<?php echo h($c['email']); ?>"><?php echo h($c['email']); ?></a><?php else: ?>—<?php endif; ?></td>
                  <td><?php echo h($c['phone']); ?></td>
                  <td><?php echo h($c['company']); ?></td>
                  <td class="muted small"><?php echo h($c['created_at']); ?></td>
                  <td class="text-end">
                    <div class="btn-group" role="group" aria-label="actions">
                      <button class="btn btn-sm btn-outline-secondary" onclick="showClient(<?php echo (int)$c['id']; ?>)">
                        <i class="bi bi-eye"></i> View
                      </button>
                      <a class="btn btn-sm btn-outline-primary" href="<?= $BASE_PATH ?>/clients/edit.php?id=<?php echo (int)$c['id']; ?>">
                        <i class="bi bi-pencil"></i> Edit
                      </a>
                      <button class="btn btn-sm btn-outline-danger" onclick="confirmDelete(<?php echo (int)$c['id']; ?>, '<?php echo h(addslashes($c['name'])); ?>')">
                        <i class="bi bi-trash"></i> Delete
                      </button>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>

    <div class="text-center muted small mt-3">Tip: Use the search box to quickly find clients. Click "View" for details.</div>
  </div>

  <!-- Client details modal -->
  <div class="modal fade" id="clientModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Client</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body" id="clientModalBody">
          <!-- populated dynamically -->
          <div class="text-center muted">Loading…</div>
        </div>
        <div class="modal-footer">
          <a id="modalEdit" class="btn btn-primary" href="#"><i class="bi bi-pencil"></i> Edit</a>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Delete confirmation modal -->
  <div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <form method="post" id="deleteForm">
          <div class="modal-header">
            <h5 class="modal-title">Delete client</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body" id="deleteModalBody">
            Are you sure you want to delete this client?
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <!-- Delete action will be a GET to clients/delete.php?id=ID (kept simple) -->
            <a id="deleteConfirmBtn" class="btn btn-danger" href="#"><i class="bi bi-trash"></i> Delete</a>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Scripts -->
  <script>
    // expose base path to JS (safely encoded)
    const BASE_PATH = <?= json_encode($BASE_PATH); ?>;
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // Entrance animations
    document.addEventListener('DOMContentLoaded', function(){
      document.querySelectorAll('.fade-up').forEach((el, idx) => {
        setTimeout(()=> el.classList.add('in'), 60 + idx*80);
      });
    });

    // Client-side search: filter rows by data-search attr
    document.getElementById('clientSearch')?.addEventListener('input', function(){
      const q = this.value.trim().toLowerCase();
      document.querySelectorAll('#clientsTableBody tr').forEach(row => {
        const txt = row.getAttribute('data-search') || '';
        row.style.display = (!q || txt.indexOf(q) !== -1) ? '' : 'none';
      });
    });

    // Show client details (fetch minimal data via fetch API to avoid exposing everything)
    // We'll request server endpoint clients/view_ajax.php?id=ID which should return JSON
    // If not present, we'll fallback to simple inline details
    function showClient(id){
      const modal = new bootstrap.Modal(document.getElementById('clientModal'));
      const body = document.getElementById('clientModalBody');
      const editBtn = document.getElementById('modalEdit');
      body.innerHTML = '<div class="text-center muted">Loading…</div>';
      editBtn.href = BASE_PATH + '/clients/edit.php?id=' + encodeURIComponent(id);

      // Try to fetch a JSON endpoint (optional). We'll fail gracefully.
      fetch(BASE_PATH + '/clients/view_ajax.php?id=' + encodeURIComponent(id), {credentials: 'same-origin'})
        .then(r => {
          if (!r.ok) throw new Error('No ajax view available');
          return r.json();
        })
        .then(data => {
          // expected fields: id,name,email,phone,company,created_at,address (optional),notes
          let html = '<div><h5>' + escapeHtml(data.name) + '</h5>';
          html += '<div class="muted small mb-2">Added: ' + escapeHtml(data.created_at || '') + '</div>';
          html += '<p><strong>Email:</strong> ' + (data.email ? '<a href="mailto:' + escapeHtml(data.email) + '">' + escapeHtml(data.email) + '</a>' : '—') + '<br>';
          html += '<strong>Phone:</strong> ' + escapeHtml(data.phone || '') + '<br>';
          html += '<strong>Company:</strong> ' + escapeHtml(data.company || '') + '</p>';
          if (data.address) html += '<p><strong>Address:</strong><br>' + escapeHtml(data.address) + '</p>';
          if (data.notes) html += '<p><strong>Notes:</strong><br>' + escapeHtml(data.notes) + '</p>';
          html += '</div>';
          body.innerHTML = html;
        })
        .catch(err=>{
          // fallback: find the row matching id by reading hrefs in edit link
          let found = null;
          document.querySelectorAll('#clientsTableBody tr').forEach(r=>{
            const link = r.querySelector('a[href*="edit.php?id="]');
            if (link && link.getAttribute('href').indexOf('id='+id) !== -1) found = r;
          });
          if (found) {
            const name = found.children[1].innerText;
            const email = found.children[2].innerText;
            const phone = found.children[3].innerText;
            const company = found.children[4].innerText;
            const added = found.children[5].innerText;
            let html = '<div><h5>' + escapeHtml(name) + '</h5>';
            html += '<div class="muted small mb-2">Added: ' + escapeHtml(added) + '</div>';
            html += '<p><strong>Email:</strong> ' + (email ? ('<a href="mailto:' + escapeHtml(email) + '">' + escapeHtml(email) + '</a>') : '—') + '<br>';
            html += '<strong>Phone:</strong> ' + escapeHtml(phone) + '<br>';
            html += '<strong>Company:</strong> ' + escapeHtml(company) + '</p></div>';
            body.innerHTML = html;
          } else {
            body.innerHTML = '<div class="text-center muted">Details unavailable.</div>';
          }
        });

      modal.show();
    }

    // Delete confirmation
    function confirmDelete(id, name){
      const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
      document.getElementById('deleteModalBody').innerHTML = 'Are you sure you want to delete <strong>' + escapeHtml(name) + '</strong>? This action cannot be undone. All projects and invoices linked to this client will also be affected.';
      document.getElementById('deleteConfirmBtn').href = BASE_PATH + '/clients/delete.php?id=' + encodeURIComponent(id);
      deleteModal.show();
    }

    // basic HTML escape
    function escapeHtml(s){
      if (!s && s !== 0) return '';
      return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
    }
  </script>
</body>
</html>
