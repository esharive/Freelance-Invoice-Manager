<?php
session_start();

// Compute a robust base path for building links (auto-detect where this script lives).
$base_dir = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
$BASE_PATH = $base_dir === '/' ? '' : $base_dir;

if (!isset($_SESSION['user_id'])) {
    header('Location: ' . $BASE_PATH . '/login.php');
    exit;
}

require_once __DIR__ . '/../config/db.php';

// small helper
function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

// CSRF token for deletion
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
}
$csrf = $_SESSION['csrf_token'];

$uid = (int) $_SESSION['user_id'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$id) {
    header('Location: ' . $BASE_PATH . '/clients/list.php');
    exit;
}

$errors = [];

// POST: perform delete (with CSRF check)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf) {
        $errors[] = 'Invalid request (CSRF token). Please try again.';
    } else {
        $del = $conn->prepare("DELETE FROM clients WHERE id=? AND user_id=?");
        if ($del) {
            $del->bind_param('ii', $id, $uid);
            $del->execute();
            $del->close();
            // Redirect back to clients list
            header('Location: ' . $BASE_PATH . '/clients/list.php');
            exit;
        } else {
            $errors[] = 'Database error. Could not prepare delete.';
        }
    }
}

// Fetch client for confirmation
$stmt = $conn->prepare("SELECT id,name FROM clients WHERE id=? AND user_id=? LIMIT 1");
if (!$stmt) {
    // Something wrong — redirect to list
    header('Location: ' . $BASE_PATH . '/clients/list.php');
    exit;
}
$stmt->bind_param('ii', $id, $uid);
$stmt->execute();
$res = $stmt->get_result();
$client = $res->fetch_assoc();
$stmt->close();

if (!$client) {
    header('Location: ' . $BASE_PATH . '/clients/list.php');
    exit;
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Delete Client — Freelance Manager</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body{font-family:Inter,system-ui, -apple-system, "Segoe UI", Roboto, Arial; background:#f4f7fb; padding:36px;}
    .card{max-width:720px;margin:28px auto;padding:22px;border-radius:12px;box-shadow:0 12px 30px rgba(11,24,40,0.06);background:#fff}
    .muted{color:#6c757d}
  </style>
</head>
<body>
  <div class="card">
    <div class="d-flex justify-content-between align-items-start mb-3">
      <div>
        <h4 style="margin:0">Delete client</h4>
        <div class="muted small">This action is permanent — proceed with caution.</div>
      </div>
      <div>
        <a class="btn btn-outline-secondary btn-sm" href="<?= $BASE_PATH ?>/clients/list.php">Back to clients</a>
      </div>
    </div>

    <?php if (!empty($errors)): ?>
      <div class="alert alert-danger">
        <ul class="mb-0">
          <?php foreach ($errors as $e): ?>
            <li><?php echo h($e); ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <p>Are you sure you want to delete <strong><?php echo h($client['name']); ?></strong> ? This action cannot be undone.</p>

    <form method="post" class="d-flex gap-2">
      <input type="hidden" name="csrf_token" value="<?php echo h($csrf); ?>">
      <button type="submit" class="btn btn-danger">Yes, permanently delete</button>
      <a class="btn btn-outline-secondary" href="<?= $BASE_PATH ?>/clients/list.php">Cancel</a>
    </form>
  </div>
</body>
</html>
