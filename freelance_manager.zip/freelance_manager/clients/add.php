<?php
// clients/add.php
// Ultra-attractive Bootstrap5 client add page with animations & JS interactivity
// Place at /freelance_manager/clients/add.php (works even if the project lives under /my_works)

session_start();

// Compute a robust base path for building links (auto-detect where this script lives).
$base_dir = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
$BASE_PATH = $base_dir === '/' ? '' : $base_dir;

if (!isset($_SESSION['user_id'])) {
    header('Location: ' . $BASE_PATH . '/login.php');
    exit;
}
require_once __DIR__ . '/../config/db.php';

// small helper
function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
}
$csrf = $_SESSION['csrf_token'];

$errors = [];
$old = ['name'=>'','email'=>'','phone'=>'','company'=>'','notes'=>''];

// handle POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // basic CSRF check
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf) {
        $errors[] = 'Invalid request. Please try again.';
    }

    $name    = trim($_POST['name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $phone   = trim($_POST['phone'] ?? '');
    $company = trim($_POST['company'] ?? '');
    $notes   = trim($_POST['notes'] ?? '');

    // repopulate old
    $old = ['name'=>$name,'email'=>$email,'phone'=>$phone,'company'=>$company,'notes'=>$notes];

    // validations
    if ($name === '') {
        $errors[] = 'Client name is required.';
    }
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Enter a valid email address.';
    }
    if ($phone !== '' && strlen(preg_replace('/\D+/', '', $phone)) < 6) {
        $errors[] = 'Enter a valid phone number.';
    }

    if (empty($errors)) {
        $stmt = $conn->prepare("INSERT INTO clients (user_id, name, email, phone, company, notes) VALUES (?, ?, ?, ?, ?, ?)");
        $uid = (int)$_SESSION['user_id'];
        if ($stmt) {
            $stmt->bind_param('isssss', $uid, $name, $email, $phone, $company, $notes);
            if ($stmt->execute()) {
                // success flash and redirect to clients list
                $_SESSION['flash_success'] = 'Client "' . $name . '" added successfully.';
                header('Location: ' . $BASE_PATH . '/clients/list.php');
                exit;
            } else {
                $errors[] = 'Could not add client. Database error.';
            }
        } else {
            $errors[] = 'Database error: failed to prepare statement.';
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Add Client — Freelance Manager</title>

  <!-- Fonts / Icons / Bootstrap -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

  <style>
    :root{
      --bg: #f4f7fb;
      --card: #fff;
      --brand-1: #0d6efd;
      --brand-2: #0b5ed7;
      --muted: #6c757d;
      --radius: 14px;
    }
    html,body{height:100%}
    body{
      font-family: Inter, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
      background: linear-gradient(180deg,#f7f9ff 0%, var(--bg) 100%);
      color: #082032;
      margin:0;
      padding:24px;
    }

    .app-shell{max-width:1100px;margin:0 auto}
    .brand {
      display:flex;align-items:center;gap:12px;text-decoration:none;color:inherit;
    }
    .brand-logo{width:52px;height:52px;border-radius:12px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;
      background: linear-gradient(135deg,var(--brand-1),var(--brand-2));box-shadow:0 10px 30px rgba(11,78,200,0.12)}
    .card-panel{background:var(--card);border-radius:var(--radius);box-shadow:0 20px 40px rgba(11,78,200,0.06);padding:22px}
    .muted{color:var(--muted)}
    .form-floating .form-control:focus{box-shadow:0 0 0 .15rem rgba(13,110,253,0.12)}
    .btn-animate {
      transition: transform .18s cubic-bezier(.2,.9,.3,1), box-shadow .18s;
    }
    .btn-animate:active { transform: translateY(2px) scale(.995); }
    .pulse {
      animation: pulse 2.6s infinite;
      opacity: .06;
      border-radius: 12px;
      position: absolute;
      inset: -6px;
      z-index: -1;
      background: linear-gradient(135deg, rgba(13,110,253,0.14), rgba(11,78,215,0.04));
    }
    @keyframes slideIn { from { transform: translateY(18px); opacity:0 } to { transform:none; opacity:1 } }
    .enter { animation: slideIn .48s cubic-bezier(.2,.9,.3,1) both }
    /* validation UI */
    .invalid-feedback.show { display:block; }
    /* subtle floating labels animation for the hero-side preview */
    .preview-card{border-radius:12px;padding:14px;background:linear-gradient(180deg,#fff,#fbfdff);border:1px solid rgba(11,78,200,0.04)}
    @media (max-width:767px){
      .preview-card{display:none}
    }
  </style>
</head>
<body>
  <div class="app-shell">
    <!-- header -->
    <div class="d-flex align-items-center justify-content-between mb-4">
      <a href="<?= $BASE_PATH ?>/index.php" class="brand">
        <div class="brand-logo"><i class="bi bi-briefcase-fill"></i></div>
        <div>
          <div style="font-weight:700;font-size:1.05rem">Freelance<span style="color:var(--brand-2)">Manager</span></div>
          <div class="muted small">Invoices • Clients • Payments</div>
        </div>
      </a>

      <div class="d-flex gap-2 align-items-center">
        <a href="<?= $BASE_PATH ?>/clients/list.php" class="btn btn-outline-secondary btn-sm btn-animate"><i class="bi bi-chevron-left"></i> Back</a>
        <a href="<?= $BASE_PATH ?>/invoices/add.php" class="btn btn-primary btn-sm btn-animate"><i class="bi bi-receipt me-1"></i> New Invoice</a>
      </div>
    </div>

    <div class="row g-4">
      <!-- form column -->
      <div class="col-lg-7">
        <div class="card-panel enter position-relative overflow-hidden">
          <div class="pulse" aria-hidden="true"></div>
          <h4 style="font-weight:700" class="mb-1">Add a new client</h4>
          <div class="muted mb-3">Create a client profile — you'll be able to assign projects and invoices to this client.</div>

          <!-- Errors -->
          <?php if (!empty($errors)): ?>
            <div class="alert alert-danger" role="alert" id="errorsBox">
              <strong>Fix the following:</strong>
              <ul class="mb-0 mt-1">
                <?php foreach ($errors as $err): ?>
                  <li><?php echo h($err); ?></li>
                <?php endforeach; ?>
              </ul>
            </div>
          <?php endif; ?>

          <form id="addClientForm" method="post" novalidate>
            <input type="hidden" name="csrf_token" value="<?php echo h($csrf); ?>">

            <div class="mb-3 form-floating">
              <input type="text" name="name" id="name" class="form-control form-control-lg" placeholder="Client name" required value="<?php echo h($old['name']); ?>">
              <label for="name">Client name <span class="text-danger">*</span></label>
              <div class="invalid-feedback">Please enter the client name.</div>
            </div>

            <div class="row g-3">
              <div class="col-md-6 form-floating">
                <input type="email" name="email" id="email" class="form-control" placeholder="name@example.com" value="<?php echo h($old['email']); ?>">
                <label for="email">Email</label>
                <div class="invalid-feedback">Enter a valid email address.</div>
              </div>
              <div class="col-md-6 form-floating">
                <input type="tel" name="phone" id="phone" class="form-control" placeholder="+234..." value="<?php echo h($old['phone']); ?>">
                <label for="phone">Phone</label>
                <div class="invalid-feedback">Enter a valid phone number.</div>
              </div>
            </div>

            <div class="form-floating mt-3">
              <input type="text" name="company" id="company" class="form-control" placeholder="Company name" value="<?php echo h($old['company']); ?>">
              <label for="company">Company (optional)</label>
            </div>

            <div class="form-floating mt-3">
              <textarea name="notes" id="notes" class="form-control" placeholder="Notes about client" style="height:120px;"><?php echo h($old['notes']); ?></textarea>
              <label for="notes">Notes (optional)</label>
            </div>

            <div class="d-flex gap-2 align-items-center mt-4">
              <button id="submitBtn" type="submit" class="btn btn-primary btn-lg btn-animate">
                <i class="bi bi-person-plus me-2"></i> Add client
              </button>

              <button id="previewBtn" type="button" class="btn btn-outline-secondary btn-lg" data-bs-toggle="modal" data-bs-target="#previewModal">
                <i class="bi bi-card-text me-1"></i> Preview
              </button>

              <div id="savingIndicator" class="ms-3 text-success small" style="display:none">
                <i class="bi bi-check2-circle"></i> Saved
              </div>
            </div>

            <div class="muted small mt-3">You can edit this client later. We won't share client details with anyone.</div>
          </form>
        </div>
      </div>

      <!-- preview / tips column -->
      <div class="col-lg-5">
        <div class="preview-card enter">
          <div class="d-flex justify-content-between align-items-start">
            <div>
              <h5 class="mb-1">Live preview</h5>
              <div class="muted small">See how the client card will appear in your list</div>
            </div>
            <div class="small muted">Preview</div>
          </div>

          <div id="livePreview" class="mt-3" style="min-height:160px">
            <div style="border-radius:10px;padding:14px;background:#fff;border:1px solid rgba(11,78,200,0.04)">
              <div class="d-flex align-items-start gap-3">
                <div style="width:56px;height:56px;border-radius:10px;background:linear-gradient(135deg,var(--brand-1),var(--brand-2));display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:1.1rem">C</div>
                <div>
                  <div id="pvName" style="font-weight:700">Client name</div>
                  <div id="pvCompany" class="muted small">Company</div>
                  <div class="mt-2 small"><span id="pvEmail">email@example.com</span> • <span id="pvPhone">+000000</span></div>
                </div>
              </div>
            </div>
          </div>

          <div class="mt-4">
            <h6 style="font-weight:700">Quick tips</h6>
            <ul class="muted small">
              <li>Use full client name for easy searching.</li>
              <li>Add an email so invoices can be emailed directly.</li>
              <li>Fill notes with billing terms or contact preference.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Preview modal (large) -->
  <div class="modal fade" id="previewModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-md modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Client preview</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body" id="previewModalBody">
          <!-- populated by JS -->
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <a id="openListAfterAdd" class="btn btn-primary" href="<?= $BASE_PATH ?>/clients/list.php">Go to clients</a>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // expose base path to JS (safely encoded)
    const BASE_PATH = <?= json_encode($BASE_PATH); ?>;

    // small helpers
    const $ = (sel) => document.querySelector(sel);
    const $$ = (sel) => Array.from(document.querySelectorAll(sel));

    // Live preview updates
    const fields = ['name','email','phone','company','notes'];
    function updatePreview(){
      const name = $('#name').value.trim() || 'Client name';
      const email = $('#email').value.trim() || 'email@example.com';
      const phone = $('#phone').value.trim() || '+000000';
      const company = $('#company').value.trim() || 'Company';
      $('#pvName').innerText = name;
      $('#pvEmail').innerText = email;
      $('#pvPhone').innerText = phone;
      $('#pvCompany').innerText = company;
      // first-letter avatar
      const avatarEl = document.querySelector('.preview-card [style*="background"]');
      if (avatarEl) avatarEl.innerText = name.charAt(0).toUpperCase() || 'C';
    }
    fields.forEach(f => {
      document.getElementById(f).addEventListener('input', updatePreview);
    });
    // init preview
    updatePreview();

    // Client-side validation and nice button animation
    const form = document.getElementById('addClientForm');
    const submitBtn = document.getElementById('submitBtn');
    const savingIndicator = document.getElementById('savingIndicator');

    form.addEventListener('submit', function(e){
      // simple client-side validation (mirrors server)
      const name = $('#name').value.trim();
      const email = $('#email').value.trim();
      const phone = $('#phone').value.trim();

      let clientErrors = [];
      if (!name) clientErrors.push('Name is required.');
      if (email && !/^\S+@\S+\.\S+$/.test(email)) clientErrors.push('Enter a valid email.');
      if (phone && phone.replace(/\D/g,'').length < 6) clientErrors.push('Enter a valid phone.');

      if (clientErrors.length) {
        e.preventDefault();
        // show inline validation
        const errorsBox = document.getElementById('errorsBox');
        if (errorsBox) {
          errorsBox.querySelector('ul').innerHTML = clientErrors.map(s => '<li>'+s+'</li>').join('');
        } else {
          const box = document.createElement('div');
          box.className = 'alert alert-danger';
          box.id = 'errorsBox';
          box.innerHTML = '<strong>Fix the following:</strong><ul class="mb-0">'+clientErrors.map(s => '<li>'+s+'</li>').join('')+'</ul>';
          form.parentNode.insertBefore(box, form);
        }
        // focus first invalid
        if (!name) $('#name').focus();
        return false;
      }

      // nice animated submit
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Adding...';
      savingIndicator.style.display = 'inline-block';
      // let the normal POST proceed (we do not intercept to AJAX to keep server logic simple)
    });

    // Populate preview modal on open
    const previewModal = document.getElementById('previewModal');
    previewModal.addEventListener('show.bs.modal', function(){
      const body = document.getElementById('previewModalBody');
      body.innerHTML = `
        <div style="border-radius:10px;padding:14px;background:#fff;border:1px solid rgba(11,78,200,0.04)">
          <div style="display:flex;gap:12px;align-items:flex-start">
            <div style="width:56px;height:56px;border-radius:10px;background:linear-gradient(135deg,#0d6efd,#0b5ed7);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:1.2rem">
              ${escapeHtml($('#name').value.trim().charAt(0).toUpperCase() || 'C')}
            </div>
            <div>
              <div style="font-weight:700">${escapeHtml($('#name').value.trim() || 'Client name')}</div>
              <div class="muted small">${escapeHtml($('#company').value.trim() || 'Company')}</div>
              <div class="mt-2 small"><a href="mailto:${escapeHtml($('#email').value.trim() || 'email@example.com')}">${escapeHtml($('#email').value.trim() || 'email@example.com')}</a> • ${escapeHtml($('#phone').value.trim() || '+000000')}</div>
              <div class="mt-2">${escapeHtml($('#notes').value.trim() || '')}</div>
            </div>
          </div>
        </div>
      `;
      // also update modal's "Go to clients" link to include base path
      const goBtn = document.getElementById('openListAfterAdd');
      if (goBtn) goBtn.href = BASE_PATH + '/clients/list.php';
    });

    function escapeHtml(s){ return String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'",'&#039;'); }
  </script>
</body>
</html>
