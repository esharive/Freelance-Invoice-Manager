<?php
// invoices/view.php - modern, responsive, interactive invoice view (item-level paid/remaining + payment_item breakdown)
session_start();

// ensure a single base path constant (adjust if your site path changes)
if (!defined('APP_BASE')) {
    define('APP_BASE', '/my_works/freelance_manager/');
}

if (!isset($_SESSION['user_id'])) {
    header('Location: ' . APP_BASE . 'login.php');
    exit;
}
require_once __DIR__ . '/../config/db.php';

$uid = (int)$_SESSION['user_id'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$receipt_payment_id = isset($_GET['receipt']) ? (int)$_GET['receipt'] : 0;

function get_currency_symbol($code) {
    $map = [
        'NGN'=>'₦','USD'=>'$','EUR'=>'€','GBP'=>'£',
        'JPY'=>'¥','CNY'=>'¥','CAD'=>'C$','AUD'=>'A$'
    ];
    return $map[$code] ?? $code;
}

if (!$id && !$receipt_payment_id) {
    die('No invoice id.');
}

/* ---------- Flash (if any) ---------- */
$flash = $_SESSION['flash_warning'] ?? null;
unset($_SESSION['flash_warning']);

/* ---------------------------
   1) If ?receipt=PAYMENT_ID -> render printable receipt
   --------------------------- */
if ($receipt_payment_id) {
    $stmt = $conn->prepare("
      SELECT pay.*, i.id AS invoice_id, i.currency AS invoice_currency,
             p.title AS project_title, c.name AS client_name, c.company AS client_company
      FROM payments pay
      JOIN invoices i ON pay.invoice_id = i.id
      JOIN projects p ON i.project_id = p.id
      JOIN clients c ON p.client_id = c.id
      WHERE pay.id = ? AND c.user_id = ?
      LIMIT 1
    ");
    $stmt->bind_param('ii', $receipt_payment_id, $uid);
    $stmt->execute();
    $pay = $stmt->get_result()->fetch_assoc();
    if (!$pay) die('Payment not found or access denied.');

    $symbol = get_currency_symbol($pay['currency']);
    ?>
    <!doctype html>
    <html lang="en">
    <head>
      <meta charset="utf-8">
      <title>Receipt #<?php echo (int)$pay['id']; ?></title>
      <meta name="viewport" content="width=device-width,initial-scale=1" />
      <style>
        body{font-family:Arial,Helvetica,sans-serif;padding:20px;max-width:720px;margin:auto}
        .box{border:1px solid #ddd;padding:20px;border-radius:8px}
        .row{display:flex;justify-content:space-between;margin:8px 0}
        h2{text-align:center;margin-top:0}
        @media print { button{display:none} }
      </style>
    </head>
    <body>
      <div class="box">
        <h2>Payment Receipt</h2>
        <div class="row"><strong>Receipt #</strong><div>#<?php echo (int)$pay['id']; ?></div></div>
        <div class="row"><strong>Invoice #</strong><div>#<?php echo (int)$pay['invoice_id']; ?></div></div>
        <div class="row"><strong>Project</strong><div><?php echo htmlspecialchars($pay['project_title']); ?></div></div>
        <div class="row"><strong>Client</strong><div><?php echo htmlspecialchars($pay['client_name']) . ($pay['client_company'] ? ' — '.htmlspecialchars($pay['client_company']) : ''); ?></div></div>
        <div class="row"><strong>Amount Paid</strong><div><?php echo $symbol . ' ' . number_format($pay['amount'], 2); ?></div></div>
        <div class="row"><strong>Method</strong><div><?php echo htmlspecialchars($pay['method']); ?></div></div>
        <div class="row"><strong>Transaction Ref</strong><div><?php echo htmlspecialchars($pay['transaction_ref']); ?></div></div>
        <div class="row"><strong>Paid at</strong><div><?php echo htmlspecialchars($pay['paid_at']); ?></div></div>
        <hr>
        <p style="text-align:center">Thank you for your payment.</p>
        <div style="text-align:center;margin-top:12px">
          <button onclick="window.print()">Print / Save PDF</button>
        </div>
      </div>
    </body>
    </html>
    <?php
    exit;
}

/* ---------------------------
   2) Normal invoice view: fetch invoice, items, payments
   --------------------------- */

// fetch invoice + client + project, ensure ownership
$stmt = $conn->prepare("
  SELECT i.*, i.invoice_number, p.title AS project_title, p.description AS project_description,
         c.name AS client_name, c.email AS client_email, c.phone AS client_phone, c.company AS client_company,
         u.name AS user_name
  FROM invoices i
  JOIN projects p ON i.project_id = p.id
  JOIN clients c ON p.client_id = c.id
  LEFT JOIN users u ON c.user_id = u.id
  WHERE i.id = ? AND c.user_id = ?
  LIMIT 1
");
$stmt->bind_param('ii', $id, $uid);
$stmt->execute();
$inv = $stmt->get_result()->fetch_assoc();
if (!$inv) die('Invoice not found or access denied.');

// detect payment_items table
$has_payment_items = false;
$check = $conn->query("SHOW TABLES LIKE 'payment_items'");
if ($check && $check->num_rows > 0) $has_payment_items = true;

// items (if any) — now include qty_paid (sum of payment_items.qty)
$items = [];
if ($has_payment_items) {
    $items_stmt = $conn->prepare("
      SELECT ii.id, ii.description, ii.qty, ii.unit_price, ii.line_total,
             IFNULL(SUM(pi.qty),0) AS qty_paid
      FROM invoice_items ii
      LEFT JOIN payment_items pi ON pi.invoice_item_id = ii.id
      WHERE ii.invoice_id = ?
      GROUP BY ii.id, ii.description, ii.qty, ii.unit_price, ii.line_total
      ORDER BY ii.id ASC
    ");
} else {
    $items_stmt = $conn->prepare("SELECT id, description, qty, unit_price, line_total, 0 AS qty_paid FROM invoice_items WHERE invoice_id = ? ORDER BY id ASC");
}
$items_stmt->bind_param('i', $id);
$items_stmt->execute();
$items_res = $items_stmt->get_result();
if ($items_res) $items = $items_res->fetch_all(MYSQLI_ASSOC);

// payments
$ps = $conn->prepare("SELECT * FROM payments WHERE invoice_id = ? ORDER BY paid_at DESC, id DESC");
$ps->bind_param('i', $id);
$ps->execute();
$payments_res = $ps->get_result();
$payments_arr = $payments_res ? $payments_res->fetch_all(MYSQLI_ASSOC) : [];

// if payment_items exist and payments present, fetch payment_items grouped by payment
$payment_items_map = []; // payment_id => array of items (invoice_item_id, description, qty, amount)
if ($has_payment_items && !empty($payments_arr)) {
    $payment_ids = array_map(function($p){ return (int)$p['id']; }, $payments_arr);
    $inList = implode(',', $payment_ids);
    // join payment_items to invoice_items to get description
    $pi_stmt = $conn->prepare("
      SELECT pi.payment_id, pi.invoice_item_id, pi.qty, pi.amount, ii.description
      FROM payment_items pi
      LEFT JOIN invoice_items ii ON ii.id = pi.invoice_item_id
      WHERE pi.payment_id IN ($inList)
      ORDER BY pi.payment_id DESC, pi.id ASC
    ");
    if ($pi_stmt) {
        $pi_stmt->execute();
        $pi_res = $pi_stmt->get_result();
        while ($row = $pi_res->fetch_assoc()) {
            $pid = (int)$row['payment_id'];
            if (!isset($payment_items_map[$pid])) $payment_items_map[$pid] = [];
            $payment_items_map[$pid][] = $row;
        }
    }
}

// totals
$total_paid = 0.0;
foreach ($payments_arr as $p) $total_paid += (float)$p['amount'];

$computed_total = 0.0;
foreach ($items as $it) $computed_total += (float)$it['line_total'];

$display_amount = ($computed_total > 0) ? $computed_total : (float)$inv['amount'];
$balance = round($display_amount - $total_paid, 2);

$symbol = get_currency_symbol($inv['currency'] ?? '');
$invoice_number = htmlspecialchars($inv['invoice_number'] ?? $inv['id']);
$user_company = htmlspecialchars($inv['user_company'] ?? ($_SESSION['user_name'] ?? 'Your Business'));
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Invoice <?php echo $invoice_number; ?> — Freelance Manager</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">

  <style>
    :root{--bg:#f4f7fb;--card:#fff;--muted:#6c757d;--brand:#0d6efd;--accent:#0b5ed7;--radius:12px}
    body{font-family:'Inter', system-ui, -apple-system, 'Segoe UI', Roboto, Arial; background:var(--bg); margin:0; color:#0b1a2b}
    .container-main{padding:28px}
    .card-plain{background:var(--card);border-radius:12px;padding:18px;box-shadow:0 10px 30px rgba(11,24,40,0.06)}
    .header-row{display:flex;align-items:flex-start;justify-content:space-between;gap:16px}
    .muted{color:var(--muted)}
    .badge-paid{background:#e6f4ea;color:#08512b;padding:.28rem .6rem;border-radius:999px}
    .badge-unpaid{background:#fff4f2;color:#8a1a1a;padding:.28rem .6rem;border-radius:999px;border:1px solid rgba(255,0,0,0.04)}
    .table-items th, .table-items td{vertical-align:middle}
    .controls .btn{border-radius:8px}
    .fade-up{opacity:0;transform:translateY(10px);transition:all .42s cubic-bezier(.2,.9,.3,1)}
    .fade-up.in{opacity:1;transform:none}
    .item-paid-note{font-size:.85rem;color:#2f6f43}
    @media (max-width:900px){ .header-row{flex-direction:column;align-items:stretch} .controls{text-align:left} }
    .small-muted{font-size:.9rem;color:var(--muted)}
  </style>
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container-fluid">
      <a class="navbar-brand d-flex align-items-center gap-2" href="<?php echo APP_BASE; ?>index.php">
        <div style="width:42px;height:42px;border-radius:8px;background:linear-gradient(135deg,var(--brand),var(--accent));display:flex;align-items:center;justify-content:center;color:#fff"><i class="bi bi-briefcase-fill"></i></div>
        <div style="font-weight:700;color:var(--brand)">FreelanceManager</div>
      </a>
      <div class="ms-auto d-flex align-items-center gap-2">
        <div class="me-2 muted small"><?php echo htmlspecialchars($_SESSION['user_name'] ?? '') ?></div>
        <a class="btn btn-sm btn-light" href="<?php echo APP_BASE; ?>index.php"><i class="bi bi-speedometer2"></i></a>
        <a class="btn btn-sm btn-outline-secondary" href="<?php echo APP_BASE; ?>logout.php"><i class="bi bi-box-arrow-right"></i></a>
      </div>
    </div>
  </nav>

  <div class="container-main container">
    <?php if ($flash): ?>
      <div class="alert alert-warning"><?php echo htmlspecialchars($flash); ?></div>
    <?php endif; ?>

    <div class="card-plain fade-up" data-delay="60">
      <div class="header-row">
        <div>
          <h3 style="margin:0;font-weight:700">Invoice <?php echo $invoice_number; ?></h3>
          <div class="muted">#<?php echo $invoice_number; ?> • Created: <?php echo htmlspecialchars($inv['created_at']); ?> • Due: <?php echo htmlspecialchars($inv['due_date']); ?></div>
        </div>

        <div class="text-end controls">
          <div style="margin-bottom:8px">
            <?php if (($inv['status'] ?? '') === 'paid'): ?>
              <span class="badge-paid">Paid</span>
            <?php elseif (($inv['status'] ?? '') === 'partially_paid'): ?>
              <span class="badge" style="background:#fff4e6;color:#7a4a00;padding:.28rem .6rem;border-radius:999px">Partially paid</span>
            <?php else: ?>
              <span class="badge-unpaid">Unpaid</span>
            <?php endif; ?>
          </div>

          <div class="d-flex gap-2 justify-content-end">
            <button id="copyInv" class="btn btn-outline-secondary btn-sm"><i class="bi bi-clipboard"></i> Copy #</button>
            <a class="btn btn-outline-primary btn-sm" href="<?php echo APP_BASE; ?>invoices/download_pdf.php?id=<?php echo (int)$inv['id']; ?>"><i class="bi bi-download"></i> Download</a>
            <a class="btn btn-outline-success btn-sm" href="<?php echo APP_BASE; ?>invoices/email_invoice.php?id=<?php echo (int)$inv['id']; ?>" target="_blank"><i class="bi bi-envelope"></i> Email</a>
            <a class="btn btn-primary btn-sm" href="<?php echo APP_BASE; ?>invoices/edit.php?id=<?php echo (int)$inv['id']; ?>"><i class="bi bi-pencil"></i> Edit</a>
          </div>
        </div>
      </div>

      <hr>

      <div class="row g-3">
        <div class="col-md-7">
          <h5 style="margin:0 0 8px 0">Bill to</h5>
          <div><strong><?php echo htmlspecialchars($inv['client_name']); ?></strong><?php echo $inv['client_company'] ? ' — '.htmlspecialchars($inv['client_company']) : ''; ?></div>
          <?php if ($inv['client_email']): ?><div class="muted small"><?php echo htmlspecialchars($inv['client_email']); ?></div><?php endif; ?>
          <?php if ($inv['client_phone']): ?><div class="muted small"><?php echo htmlspecialchars($inv['client_phone']); ?></div><?php endif; ?>
          <div class="mt-3">
            <strong>Project:</strong> <?php echo htmlspecialchars($inv['project_title']); ?><br>
            <?php if (!empty($inv['project_description'])): ?><div class="small-muted mt-2"><?php echo nl2br(htmlspecialchars($inv['project_description'])); ?></div><?php endif; ?>
          </div>
        </div>

        <div class="col-md-5 text-md-end">
          <div style="font-weight:700"><?php echo $user_company; ?></div>
          <div class="muted small"><?php echo htmlspecialchars($_SESSION['user_email'] ?? ''); ?></div>
        </div>
      </div>

      <hr>

      <!-- items -->
      <div class="table-responsive">
        <table class="table table-bordered table-items mb-0">
          <thead class="table-light">
            <tr>
              <th>Description</th>
              <th style="width:110px" class="text-end">Qty</th>
              <th style="width:110px" class="text-end">Paid</th>
              <th style="width:160px" class="text-end">Unit</th>
              <th style="width:160px" class="text-end">Line</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!empty($items)): ?>
              <?php foreach ($items as $it): 
                 $qty_total = (float)$it['qty'];
                 $qty_paid  = (float)$it['qty_paid'];
                 $remaining  = max(0, $qty_total - $qty_paid);
              ?>
                <tr>
                  <td><?php echo nl2br(htmlspecialchars($it['description'])); ?>
                    <?php if ($qty_paid > 0): ?>
                      <div class="item-paid-note"><small>Paid: <?php echo htmlspecialchars($qty_paid); ?> — Remaining: <?php echo htmlspecialchars($remaining); ?></small></div>
                    <?php endif; ?>
                  </td>
                  <td class="text-end"><?php echo htmlspecialchars($qty_total); ?></td>
                  <td class="text-end"><?php echo htmlspecialchars($qty_paid); ?></td>
                  <td class="text-end"><?php echo $symbol . ' ' . number_format((float)$it['unit_price'], 2); ?></td>
                  <td class="text-end"><?php echo $symbol . ' ' . number_format((float)$it['line_total'], 2); ?></td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr>
                <td colspan="5"><?php echo nl2br(htmlspecialchars($inv['project_description'] ?: 'Invoice amount')); ?></td>
              </tr>
            <?php endif; ?>

            <tr>
              <td colspan="4" class="text-end"><strong>Total</strong></td>
              <td class="text-end"><strong><?php echo $symbol . ' ' . number_format($display_amount, 2); ?></strong></td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- payments summary -->
      <div class="row mt-3">
        <div class="col-md-6">
          <h6>Payments</h6>
          <?php if (empty($payments_arr)): ?>
            <div class="muted">No payments recorded yet.</div>
          <?php else: ?>
            <div class="table-responsive">
              <table class="table table-sm table-striped mb-0">
                <thead><tr><th>ID</th><th>Amount</th><th>Method</th><th>Transaction</th><th>Paid at</th><th></th></tr></thead>
                <tbody>
                  <?php foreach ($payments_arr as $p): ?>
                    <tr>
                      <td><?php echo (int)$p['id']; ?></td>
                      <td class="text-end"><?php echo get_currency_symbol($p['currency']) . ' ' . number_format((float)$p['amount'], 2); ?></td>
                      <td><?php echo htmlspecialchars($p['method']); ?></td>
                      <td><?php echo htmlspecialchars($p['transaction_ref']); ?></td>
                      <td><?php echo htmlspecialchars($p['paid_at']); ?></td>
                      <td class="text-end"><a class="btn btn-sm btn-outline-secondary" href="<?php echo APP_BASE; ?>invoices/view.php?id=<?php echo (int)$inv['id']; ?>&receipt=<?php echo (int)$p['id']; ?>" target="_blank">Receipt</a></td>
                    </tr>
                    <?php
                    // if we have payment_items for this payment, show them immediately under the payment
                    $pid = (int)$p['id'];
                    if (!empty($payment_items_map[$pid])):
                    ?>
                      <tr>
                        <td colspan="6" class="ps-4">
                          <div class="small-muted">Items paid in this payment:</div>
                          <ul class="small mb-0">
                            <?php foreach ($payment_items_map[$pid] as $pit): ?>
                              <li><?php echo htmlspecialchars($pit['description'] ?: '[item]'); ?> — qty: <?php echo htmlspecialchars($pit['qty']); ?> — amount: <?php echo get_currency_symbol($p['currency']) . ' ' . number_format((float)$pit['amount'], 2); ?></li>
                            <?php endforeach; ?>
                          </ul>
                        </td>
                      </tr>
                    <?php endif; ?>
                  <?php endforeach; ?>
                  <tr>
                    <td><strong>Total paid</strong></td>
                    <td class="text-end"><strong><?php echo $symbol . ' ' . number_format($total_paid, 2); ?></strong></td>
                    <td colspan="4"></td>
                  </tr>
                  <tr>
                    <td><strong>Balance</strong></td>
                    <td class="text-end"><strong><?php echo $symbol . ' ' . number_format($balance, 2); ?></strong></td>
                    <td colspan="4"></td>
                  </tr>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
        </div>

        <div class="col-md-6 text-md-end align-self-center">
          <div class="d-flex justify-content-md-end gap-2 mt-2">
            <a href="<?php echo APP_BASE; ?>invoices/download_pdf.php?id=<?php echo (int)$inv['id']; ?>" class="btn btn-outline-primary">⬇ Download</a>
            <a href="<?php echo APP_BASE; ?>invoices/email_invoice.php?id=<?php echo (int)$inv['id']; ?>" target="_blank" class="btn btn-outline-success">📧 Email</a>
            <a href="<?php echo APP_BASE; ?>payments/add.php?invoice_id=<?php echo (int)$inv['id']; ?>" class="btn btn-warning">💰 Record Payment</a>
            <button onclick="window.print()" class="btn btn-light">🖨 Print</button>
            <a href="<?php echo APP_BASE; ?>invoices/list.php" class="btn btn-link">Back</a>
          </div>
        </div>
      </div>
    </div>

  </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // small UI behavior
  document.addEventListener('DOMContentLoaded', function(){
    document.querySelectorAll('.fade-up').forEach((el, i)=> setTimeout(()=> el.classList.add('in'), (el.dataset.delay||40) + i*30));

    // copy invoice number
    document.getElementById('copyInv')?.addEventListener('click', function(){
      const txt = '<?php echo addslashes($invoice_number); ?>';
      navigator.clipboard?.writeText(txt).then(()=> {
        this.innerHTML = '<i class="bi bi-clipboard-check"></i> Copied';
        setTimeout(()=> this.innerHTML = '<i class="bi bi-clipboard"></i> Copy #', 1800);
      }, ()=> {
        alert('Copy failed. Invoice #: ' + txt);
      });
    });
  });
</script>
</body>
</html>
