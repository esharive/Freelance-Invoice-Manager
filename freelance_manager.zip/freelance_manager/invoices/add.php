<?php
// invoices/add.php — corrected path version (Bootstrap + secure session)
session_start();

// BASE_PATH (explicit and fixed to your deployment folder)
$BASE_PATH = '/my_works/freelance_manager';

if (!isset($_SESSION['user_id'])) {
    header('Location: ' . $BASE_PATH . '/login.php');
    exit;
}

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../lib/invoice_helpers.php';

$uid = (int)$_SESSION['user_id'];
$errors = [];

// CSRF setup
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
$csrf_token = $_SESSION['csrf_token'];

// Currency options
$currency_options = ['NGN','USD','EUR','GBP'];
function get_currency_symbol($code){
    $map = ['NGN'=>'₦','USD'=>'$','EUR'=>'€','GBP'=>'£'];
    return $map[$code] ?? $code;
}

// Fetch user’s projects
$pstmt = $conn->prepare("
  SELECT p.id, p.title, c.name AS client_name
  FROM projects p
  JOIN clients c ON p.client_id = c.id
  WHERE c.user_id = ?
  ORDER BY c.name, p.title
");
$pstmt->bind_param('i', $uid);
$pstmt->execute();
$projects = $pstmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Default form state
$old = [
  'project_id' => '',
  'currency' => $currency_options[0],
  'due_date' => '',
  'items' => array_fill(0, 6, ['desc'=>'','qty'=>'','price'=>''])
];

// POST handling
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf_token) {
        $errors[] = 'Invalid CSRF token. Please try again.';
    }

    $project_id = (int)($_POST['project_id'] ?? 0);
    $due_date   = trim($_POST['due_date'] ?? '');
    $currency   = strtoupper(trim($_POST['currency'] ?? $currency_options[0]));
    if (!in_array($currency, $currency_options)) $currency = $currency_options[0];

    $descs  = $_POST['item_desc'] ?? [];
    $qtys   = $_POST['item_qty'] ?? [];
    $prices = $_POST['item_price'] ?? [];

    $old['project_id'] = $project_id;
    $old['currency']   = $currency;
    $old['due_date']   = $due_date;

    $computed = compute_items_total($descs, $qtys, $prices);
    $items  = $computed['items'];
    $amount = $computed['total'];

    // Validation
    if (!$project_id) $errors[] = 'Project is required.';
    if (empty($items)) $errors[] = 'Add at least one valid invoice item.';
    if ($amount <= 0) $errors[] = 'Invoice total must be greater than zero.';

    // Verify ownership
    $chk = $conn->prepare("
      SELECT p.id FROM projects p
      JOIN clients c ON p.client_id = c.id
      WHERE p.id=? AND c.user_id=? LIMIT 1
    ");
    $chk->bind_param('ii', $project_id, $uid);
    $chk->execute();
    if ($chk->get_result()->num_rows === 0) $errors[] = 'Invalid project selection.';

    if (empty($errors)) {
        $conn->begin_transaction();
        try {
            $ins = $conn->prepare("INSERT INTO invoices (project_id, amount, status, due_date, currency) VALUES (?, ?, ?, ?, ?)");
            $status = 'unpaid';
            $ins->bind_param('idsss', $project_id, $amount, $status, $due_date, $currency);
            $ins->execute();
            $invoice_id = $conn->insert_id;

            $invnum = 'INV-' . date('Y') . '-' . str_pad($invoice_id, 6, '0', STR_PAD_LEFT);
            $upd = $conn->prepare("UPDATE invoices SET invoice_number=? WHERE id=?");
            $upd->bind_param('si', $invnum, $invoice_id);
            $upd->execute();

            $ins_item = $conn->prepare("INSERT INTO invoice_items (invoice_id, description, qty, unit_price, line_total) VALUES (?, ?, ?, ?, ?)");
            foreach ($items as $it) {
                $desc = trim($it['description']);
                $qty  = (float)$it['qty'];
                $unit = (float)$it['unit_price'];
                $line = (float)$it['line_total'];
                $ins_item->bind_param('isddd', $invoice_id, $desc, $qty, $unit, $line);
                $ins_item->execute();
            }

            $conn->commit();
            header('Location: ' . $BASE_PATH . '/invoices/list.php');
            exit;
        } catch (Exception $e) {
            $conn->rollback();
            $errors[] = 'Could not create invoice: ' . $e->getMessage();
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Create Invoice — Freelance Manager</title>
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
  <style>
    body{font-family:'Inter',system-ui,-apple-system,'Segoe UI',Roboto,Arial;background:#f5f8fc;color:#0b1a2b;}
    .page{max-width:1100px;margin:30px auto;padding:18px;}
    .card-panel{background:#fff;border-radius:14px;padding:22px;box-shadow:0 12px 35px rgba(0,0,0,0.05);}
    .fade-up{opacity:0;transform:translateY(10px);transition:all .45s ease-out;}
    .fade-up.in{opacity:1;transform:none;}
  </style>
</head>
<body>
<nav class="navbar navbar-light bg-white shadow-sm">
  <div class="container-fluid">
    <a class="navbar-brand d-flex align-items-center gap-2" href="<?= $BASE_PATH ?>/home.php">
      <div style="width:36px;height:36px;border-radius:8px;background:linear-gradient(135deg,#0d6efd,#0b5ed7);display:flex;align-items:center;justify-content:center;color:#fff;">
        <i class="bi bi-briefcase-fill"></i>
      </div>
      <strong style="color:#0d6efd">FreelanceManager</strong>
    </a>
    <a href="<?= $BASE_PATH ?>/invoices/list.php" class="btn btn-outline-secondary btn-sm">Back to invoices</a>
  </div>
</nav>

<main class="page">
  <div class="card-panel fade-up" id="mainCard">
    <h4>Create Invoice</h4>
    <p class="text-muted">Fill in invoice details below.</p>

    <?php if ($errors): ?>
      <div class="alert alert-danger">
        <ul class="mb-0"><?php foreach($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?></ul>
      </div>
    <?php endif; ?>

    <?php if (empty($projects)): ?>
      <div class="alert alert-info">
        No projects found. <a href="<?= $BASE_PATH ?>/projects/add.php">Create one</a> first.
      </div>
    <?php else: ?>

    <form method="post">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
      <div class="row g-3">
        <div class="col-md-6">
          <label class="form-label">Project</label>
          <select name="project_id" class="form-select" required>
            <option value="">— choose project —</option>
            <?php foreach ($projects as $p): ?>
              <option value="<?= (int)$p['id'] ?>" <?= $p['id']==$old['project_id']?'selected':'' ?>>
                <?= htmlspecialchars($p['client_name'].' — '.$p['title']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-3">
          <label class="form-label">Currency</label>
          <select name="currency" class="form-select">
            <?php foreach ($currency_options as $c): ?>
              <option value="<?= $c ?>" <?= $c==$old['currency']?'selected':'' ?>>
                <?= $c . ' — ' . get_currency_symbol($c) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-3">
          <label class="form-label">Due date</label>
          <input type="date" name="due_date" class="form-control" value="<?= htmlspecialchars($old['due_date']) ?>">
        </div>
      </div>

      <hr>
      <h6>Invoice Items</h6>
      <div class="table-responsive">
        <table class="table table-bordered" id="itemsTable">
          <thead class="table-light">
            <tr>
              <th>Description</th>
              <th class="text-end">Qty</th>
              <th class="text-end">Unit Price</th>
              <th class="text-end">Line Total</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($old['items'] as $it): ?>
            <tr>
              <td><input type="text" name="item_desc[]" class="form-control" value="<?= $it['desc'] ?>"></td>
              <td><input type="number" step="0.01" name="item_qty[]" class="form-control text-end" value="<?= $it['qty'] ?>"></td>
              <td><input type="number" step="0.01" name="item_price[]" class="form-control text-end" value="<?= $it['price'] ?>"></td>
              <td class="text-end align-middle"><span class="line-total">0.00</span></td>
              <td class="text-center align-middle"><button type="button" class="btn btn-sm btn-outline-danger remove-row"><i class="bi bi-trash"></i></button></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
          <tfoot>
            <tr>
              <td colspan="3" class="text-end"><strong>Total</strong></td>
              <td class="text-end"><strong id="grandTotal">0.00</strong></td>
              <td></td>
            </tr>
          </tfoot>
        </table>
      </div>

      <div class="d-flex justify-content-between mt-2">
        <div>
          <button type="button" id="addRow" class="btn btn-outline-primary btn-sm"><i class="bi bi-plus-lg"></i> Add Row</button>
          <button type="button" id="clearRows" class="btn btn-outline-secondary btn-sm">Clear Empty</button>
        </div>
        <button type="submit" class="btn btn-primary">Create Invoice</button>
      </div>
    </form>
    <?php endif; ?>
  </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded',()=>{
  document.getElementById('mainCard').classList.add('in');

  const fmt = n => (isNaN(n=+n)?'0.00':n.toFixed(2));
  const recompute = ()=>{
    let grand=0;
    document.querySelectorAll('#itemsTable tbody tr').forEach(tr=>{
      const q=+tr.querySelector('[name="item_qty[]"]').value||0;
      const p=+tr.querySelector('[name="item_price[]"]').value||0;
      const line=q*p;
      tr.querySelector('.line-total').textContent=fmt(line);
      grand+=line;
    });
    document.getElementById('grandTotal').textContent=fmt(grand);
  };
  document.getElementById('itemsTable').addEventListener('input',recompute);
  document.getElementById('addRow').addEventListener('click',()=>{
    const tr=document.createElement('tr');
    tr.innerHTML=`<td><input type="text" name="item_desc[]" class="form-control"></td>
      <td><input type="number" step="0.01" name="item_qty[]" class="form-control text-end"></td>
      <td><input type="number" step="0.01" name="item_price[]" class="form-control text-end"></td>
      <td class="text-end align-middle"><span class="line-total">0.00</span></td>
      <td class="text-center align-middle"><button type="button" class="btn btn-sm btn-outline-danger remove-row"><i class="bi bi-trash"></i></button></td>`;
    document.querySelector('#itemsTable tbody').appendChild(tr);
  });
  document.querySelector('#itemsTable tbody').addEventListener('click',e=>{
    if(e.target.closest('.remove-row')){ e.target.closest('tr').remove(); recompute(); }
  });
  document.getElementById('clearRows').addEventListener('click',()=>{
    document.querySelectorAll('#itemsTable tbody tr').forEach(tr=>{
      const desc=tr.querySelector('[name="item_desc[]"]').value.trim();
      const qty=tr.querySelector('[name="item_qty[]"]').value.trim();
      const price=tr.querySelector('[name="item_price[]"]').value.trim();
      if(!desc&&!qty&&!price) tr.remove();
    });
    recompute();
  });
  recompute();
});
</script>
</body>
</html>
