<?php
// invoices/list.php - styled, responsive, interactive invoice list (standalone)
session_start();

// ensure a single base path constant (adjust if your site path changes)
if (!defined('APP_BASE')) {
    define('APP_BASE', '/my_works/freelance_manager/');
}

if (!isset($_SESSION['user_id'])) {
    header('Location: ' . APP_BASE . 'login.php');
    exit;
}
require_once __DIR__ . '/../config/db.php';
$uid = (int)$_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'User';

// helper: currency symbols
function get_currency_symbol($code) {
    $map = ['NGN'=>'₦','USD'=>'$','EUR'=>'€','GBP'=>'£'];
    return $map[$code] ?? $code;
}
function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

// detect if invoices.is_locked column exists (safe)
$has_is_locked = false;
$colCheck = $conn->query("SHOW COLUMNS FROM `invoices` LIKE 'is_locked'");
if ($colCheck && $colCheck->num_rows > 0) {
    $has_is_locked = true;
    $colCheck->free();
}

// fetch invoices for this user
$select_lock = $has_is_locked ? "COALESCE(i.is_locked,0) AS is_locked," : "0 AS is_locked,";
$sql = "
    SELECT i.id, COALESCE(i.invoice_number, i.id) AS invoice_number, i.amount, i.currency, i.status, i.due_date, i.created_at,
           {$select_lock}
           p.title AS project_title, c.name AS client_name
    FROM invoices i
    JOIN projects p ON i.project_id = p.id
    JOIN clients c ON p.client_id = c.id
    WHERE c.user_id = ?
    ORDER BY i.created_at DESC
";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die('DB prepare error: ' . h($conn->error));
}
$stmt->bind_param('i', $uid);
$stmt->execute();
$res = $stmt->get_result();
$invoices = $res->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// counts for header
$counts = ['total'=>count($invoices), 'paid'=>0, 'partially_paid'=>0, 'unpaid'=>0];
foreach ($invoices as $inv) {
    $s = $inv['status'] ?? 'unpaid';
    if ($s === 'paid') $counts['paid']++;
    elseif ($s === 'partially_paid') $counts['partially_paid']++;
    else $counts['unpaid']++;
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Invoices — Freelance Manager</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">

  <style>
    :root{--bg:#f4f7fb;--card:#fff;--muted:#6c757d;--brand:#0d6efd;--accent:#0b5ed7;--radius:12px;}
    body{font-family:'Inter',system-ui,-apple-system,'Segoe UI',Roboto,Arial;background:var(--bg);margin:0;color:#0b1a2b}
    .topbar{background:#fff;box-shadow:0 6px 18px rgba(11,24,40,0.04)}
    .container-main{padding:22px;}
    .panel{background:var(--card);border-radius:12px;padding:16px;box-shadow:0 8px 30px rgba(11,24,40,0.04)}
    .muted{color:var(--muted)}
    .fade-up{opacity:0;transform:translateY(10px);transition:all .42s cubic-bezier(.2,.9,.3,1)}
    .fade-up.in{opacity:1;transform:none}
    .table-modern th{background:transparent;border-bottom:1px solid rgba(0,0,0,0.06)}
    .status-badge{padding:.28rem .6rem;border-radius:999px;font-weight:700}
    .badge-paid{background:#e6f4ea;color:#084b2f}
    .badge-unpaid{background:#fff3f2;color:#8a1a1a;border:1px solid rgba(255,0,0,0.06)}
    .action-btn{border-radius:8px}
    .small-muted{font-size:.9rem;color:var(--muted)}
    .locked-badge{background:#f1f3f5;color:#495057;padding:.25rem .5rem;border-radius:0.5rem;font-weight:600;margin-left:.5rem}
    @media (max-width:900px){ .controls-row{flex-direction:column;gap:.6rem} }
  </style>
</head>
<body>

<!-- topbar -->
<nav class="topbar navbar navbar-expand-lg navbar-light sticky-top">
  <div class="container-fluid px-3">
    <a class="navbar-brand d-flex align-items-center gap-2" href="<?php echo APP_BASE; ?>index.php">
      <div style="width:40px;height:40px;border-radius:8px;background:linear-gradient(135deg,var(--brand),var(--accent));display:flex;align-items:center;justify-content:center;color:#fff">
        <i class="bi bi-receipt"></i>
      </div>
      <div style="font-weight:700;color:var(--brand)">FreelanceManager</div>
    </a>

    <div class="ms-auto d-flex align-items-center gap-2">
      <a class="btn btn-outline-secondary btn-sm" href="<?php echo APP_BASE; ?>invoices/add.php"><i class="bi bi-plus-lg"></i> New Invoice</a>
      <a class="btn btn-light btn-sm" href="<?php echo APP_BASE; ?>index.php"><i class="bi bi-speedometer2"></i></a>
      <a class="btn btn-light btn-sm" href="<?php echo APP_BASE; ?>logout.php" title="Logout"><i class="bi bi-box-arrow-right"></i></a>
    </div>
  </div>
</nav>

<div class="container-main container-fluid">
  <div class="row mb-3">
    <div class="col-md-8">
      <h4 style="margin:0">Invoices</h4>
      <div class="small-muted">Manage your invoices — view, edit, send, or record payments.</div>
    </div>
    <div class="col-md-4 text-md-end align-self-center mt-2 mt-md-0">
      <button id="exportCsv" class="btn btn-outline-primary btn-sm"><i class="bi bi-file-earmark-arrow-down"></i> Export CSV</button>
    </div>
  </div>

  <div class="row g-3">
    <div class="col-12">
      <div class="panel fade-up" data-delay="80">
        <div class="d-flex align-items-center justify-content-between mb-3">
          <div class="d-flex gap-3 align-items-center controls-row">
            <div>
              <input id="q" class="form-control" placeholder="Search invoice #, client, project..." style="min-width:260px">
            </div>
            <div>
              <select id="statusFilter" class="form-select">
                <option value="">All statuses</option>
                <option value="unpaid">Unpaid</option>
                <option value="partially_paid">Partially paid</option>
                <option value="paid">Paid</option>
              </select>
            </div>
            <div>
              <select id="pageSize" class="form-select">
                <option value="10">10 rows</option>
                <option value="25" selected>25 rows</option>
                <option value="50">50 rows</option>
              </select>
            </div>
          </div>

          <div class="small-muted">Total: <strong id="totalCount"><?php echo (int)$counts['total']; ?></strong> — Paid: <?php echo (int)$counts['paid']; ?> • Partially: <?php echo (int)$counts['partially_paid']; ?> • Unpaid: <?php echo (int)$counts['unpaid']; ?></div>
        </div>

        <?php if (empty($invoices)): ?>
          <div class="small-muted">No invoices yet. <a href="<?php echo APP_BASE; ?>invoices/add.php">Create an invoice</a>.</div>
        <?php else: ?>
          <div class="table-responsive">
            <table id="invoicesTable" class="table table-hover align-middle">
              <thead class="table-modern">
                <tr>
                  <th>Invoice</th>
                  <th>Client</th>
                  <th>Project</th>
                  <th class="text-end">Amount</th>
                  <th>Status</th>
                  <th>Due</th>
                  <th>Created</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($invoices as $inv): 
                  $locked = ((int)($inv['is_locked'] ?? 0) === 1) || (strtolower($inv['status'] ?? '') === 'paid');
                ?>
                  <tr data-status="<?php echo h($inv['status']); ?>" data-invoice="<?php echo h($inv['invoice_number']); ?>" data-client="<?php echo h($inv['client_name']); ?>" data-project="<?php echo h($inv['project_title']); ?>" data-currency="<?php echo h($inv['currency']); ?>">
                    <td><?php echo h($inv['invoice_number']); ?></td>
                    <td><?php echo h($inv['client_name']); ?></td>
                    <td><?php echo h($inv['project_title']); ?></td>
                    <td class="text-end"><?php echo h(get_currency_symbol($inv['currency'])) . ' ' . number_format((float)$inv['amount'],2) . ' <span class="small-muted">(' . h($inv['currency']) . ')</span>'; ?></td>
                    <td>
                      <?php if ($inv['status'] === 'paid'): ?>
                        <span class="status-badge badge-paid">Paid</span>
                      <?php elseif ($inv['status'] === 'partially_paid'): ?>
                        <span class="status-badge" style="background:#fff4e6;color:#6a3b00">Partially</span>
                      <?php else: ?>
                        <span class="status-badge badge-unpaid">Unpaid</span>
                      <?php endif; ?>
                      <?php if ($locked): ?>
                        <span class="locked-badge" title="Locked: paid or restricted"><i class="bi bi-lock-fill"></i> Locked</span>
                      <?php endif; ?>
                    </td>
                    <td><?php echo h($inv['due_date']); ?></td>
                    <td><?php echo h($inv['created_at']); ?></td>
                    <td>
                      <div class="btn-group" role="group" aria-label="actions">
                        <a class="btn btn-sm btn-outline-primary" href="<?php echo APP_BASE; ?>invoices/view.php?id=<?php echo (int)$inv['id']; ?>" target="_blank" title="View"><i class="bi bi-eye"></i></a>

                        <?php if (!$locked): ?>
                          <a class="btn btn-sm btn-outline-secondary" href="<?php echo APP_BASE; ?>invoices/edit.php?id=<?php echo (int)$inv['id']; ?>" title="Edit"><i class="bi bi-pencil"></i></a>
                          <a class="btn btn-sm btn-success" href="<?php echo APP_BASE; ?>invoices/mark_paid.php?id=<?php echo (int)$inv['id']; ?>" title="Mark paid"><i class="bi bi-check2-circle"></i></a>
                        <?php else: ?>
                          <button class="btn btn-sm btn-secondary" disabled title="Invoice fully paid / locked"><i class="bi bi-lock"></i></button>
                        <?php endif; ?>

                        <a class="btn btn-sm btn-danger" href="<?php echo APP_BASE; ?>invoices/delete.php?id=<?php echo (int)$inv['id']; ?>" onclick="return confirm('Delete this invoice?');" title="Delete"><i class="bi bi-trash"></i></a>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>

          <!-- pagination controls -->
          <div class="d-flex justify-content-between align-items-center mt-3">
            <div class="small-muted">Showing <span id="showingRange">—</span></div>
            <div>
              <button id="prevPage" class="btn btn-sm btn-outline-secondary me-1">Prev</button>
              <button id="nextPage" class="btn btn-sm btn-outline-secondary">Next</button>
            </div>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<!-- scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
(function(){
  // simple client-side search, filter, pagination, CSV export
  const q = document.getElementById('q');
  const statusFilter = document.getElementById('statusFilter');
  const pageSizeEl = document.getElementById('pageSize');
  const table = document.getElementById('invoicesTable');
  const tbody = table?.querySelector('tbody');
  const rows = tbody ? Array.from(tbody.querySelectorAll('tr')) : [];
  const prevBtn = document.getElementById('prevPage');
  const nextBtn = document.getElementById('nextPage');
  const showingRange = document.getElementById('showingRange');
  const exportBtn = document.getElementById('exportCsv');
  let page = 1;
  let pageSize = parseInt(pageSizeEl.value,10) || 25;

  function applyFilters() {
    const term = (q.value || '').toLowerCase().trim();
    const status = statusFilter.value;
    const filtered = rows.filter(r=>{
      if (status && r.dataset.status !== status) return false;
      if (!term) return true;
      return (r.dataset.invoice||'').toLowerCase().includes(term) ||
             (r.dataset.client||'').toLowerCase().includes(term) ||
             (r.dataset.project||'').toLowerCase().includes(term);
    });
    return filtered;
  }

  function renderPage() {
    const filtered = applyFilters();
    const total = filtered.length;
    const totalPages = Math.max(1, Math.ceil(total / pageSize));
    if (page > totalPages) page = totalPages;
    const start = (page-1)*pageSize;
    const end = Math.min(total, start + pageSize);

    rows.forEach(r => r.style.display = 'none');
    for (let i = start; i < end; i++) {
      const tr = filtered[i];
      if (tr) {
        tr.style.display = '';
      }
    }
    showingRange.textContent = (total===0) ? '0' : (start+1) + '–' + end + ' of ' + total;
    prevBtn.disabled = page <= 1;
    nextBtn.disabled = page >= totalPages;
    document.getElementById('totalCount').textContent = total;
  }

  // events
  q.addEventListener('input', function(){ page = 1; renderPage(); });
  statusFilter.addEventListener('change', function(){ page = 1; renderPage(); });
  pageSizeEl.addEventListener('change', function(){ pageSize = parseInt(this.value,10); page = 1; renderPage(); });
  prevBtn.addEventListener('click', function(){ if (page>1) { page--; renderPage(); }});
  nextBtn.addEventListener('click', function(){ page++; renderPage(); });

  // CSV export of visible rows
  exportBtn.addEventListener('click', function(){
    const visible = rows.filter(r=> r.style.display !== 'none');
    if (visible.length === 0) { alert('No rows to export.'); return; }
    const cols = ['Invoice','Client','Project','Amount','Currency','Status','Due','Created'];
    let csv = cols.join(',') + '\n';
    visible.forEach(r=>{
      const cells = r.querySelectorAll('td');
      const currency = r.dataset.currency || '';
      const row = [
        '"' + (cells[0]?.innerText.trim().replace(/"/g,'""')||'') + '"',
        '"' + (cells[1]?.innerText.trim().replace(/"/g,'""')||'') + '"',
        '"' + (cells[2]?.innerText.trim().replace(/"/g,'""')||'') + '"',
        '"' + (cells[3]?.innerText.trim().replace(/"/g,'""')||'') + '"',
        '"' + (currency || '') + '"',
        '"' + (cells[4]?.innerText.trim().replace(/"/g,'""')||'') + '"',
        '"' + (cells[5]?.innerText.trim().replace(/"/g,'""')||'') + '"',
        '"' + (cells[6]?.innerText.trim().replace(/"/g,'""')||'') + '"'
      ];
      csv += row.join(',') + '\n';
    });
    const blob = new Blob([csv], {type: 'text/csv;charset=utf-8;'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'invoices_export_' + new Date().toISOString().slice(0,10) + '.csv';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  });

  // initial render; small staggered entrance animation
  document.addEventListener('DOMContentLoaded', function(){
    document.querySelectorAll('.fade-up').forEach((el,i)=> setTimeout(()=> el.classList.add('in'), (el.dataset.delay||40) + i*30));
    renderPage();
  });
})();
</script>
</body>
</html>
