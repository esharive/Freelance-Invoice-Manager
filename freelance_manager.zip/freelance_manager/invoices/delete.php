<?php
// invoices/delete.php
// Delete an invoice and its related rows (payments, items) - safe, transactional, styled UI

// --- Ensure a single base URL for this app (change this once if you move the folder) ---
if (!defined('BASE_URL')) {
    // note: must start with a slash; points to public_html/my_works/freelance_manager
    define('BASE_URL', '/my_works/freelance_manager');
}

session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}
require_once __DIR__ . '/../config/db.php';

$uid = (int)$_SESSION['user_id'];
$id  = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    header('Location: ' . BASE_URL . '/invoices/list.php');
    exit;
}

// CSRF token
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
$csrf_token = $_SESSION['csrf_token'];

$errors = [];

// Ownership check: make sure invoice belongs to a client owned by this user
$chk = $conn->prepare("
  SELECT i.id, i.invoice_number, i.amount, p.title AS project_title, c.name AS client_name, i.created_at
  FROM invoices i
  JOIN projects p ON i.project_id = p.id
  JOIN clients c ON p.client_id = c.id
  WHERE i.id = ? AND c.user_id = ?
  LIMIT 1
");
$chk->bind_param('ii', $id, $uid);
$chk->execute();
$inv = $chk->get_result()->fetch_assoc();

if (!$inv) {
    // either missing or not allowed
    $_SESSION['flash_warning'] = 'Invoice not found or access denied.';
    header('Location: ' . BASE_URL . '/invoices/list.php');
    exit;
}

// Handle POST (delete confirmed)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf_token) {
        $errors[] = 'Invalid request (CSRF).';
    } else {
        // perform transactional delete of invoice, invoice_items, payments
        $conn->begin_transaction();
        try {
            // Delete payments (if any)
            $d1 = $conn->prepare("DELETE FROM payments WHERE invoice_id = ?");
            if (!$d1) throw new Exception('Prepare failed (payments): ' . $conn->error);
            $d1->bind_param('i', $id);
            if ($d1->execute() === false) throw new Exception('Execute failed (payments): ' . $d1->error);

            // Delete invoice items
            $d2 = $conn->prepare("DELETE FROM invoice_items WHERE invoice_id = ?");
            if (!$d2) throw new Exception('Prepare failed (items): ' . $conn->error);
            $d2->bind_param('i', $id);
            if ($d2->execute() === false) throw new Exception('Execute failed (items): ' . $d2->error);

            // Delete invoice
            $d3 = $conn->prepare("DELETE FROM invoices WHERE id = ?");
            if (!$d3) throw new Exception('Prepare failed (invoice): ' . $conn->error);
            $d3->bind_param('i', $id);
            if ($d3->execute() === false) throw new Exception('Execute failed (invoice): ' . $d3->error);

            $conn->commit();

            // flash and redirect
            $_SESSION['flash_success'] = 'Invoice deleted successfully.';
            header('Location: ' . BASE_URL . '/invoices/list.php');
            exit;
        } catch (Exception $e) {
            $conn->rollback();
            $errors[] = 'Could not delete invoice: ' . $e->getMessage();
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Delete Invoice #<?php echo (int)$inv['id']; ?> — Freelance Manager</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body{font-family:Inter,system-ui,-apple-system,'Segoe UI',Roboto,Arial;background:#f4f7fb;color:#0b1a2b}
    .container{max-width:920px;margin:36px auto;padding:12px}
    .panel{background:#fff;border-radius:12px;padding:22px;box-shadow:0 20px 40px rgba(11,24,40,0.06)}
    .muted{color:#6c757d}
    .danger-cta{background:linear-gradient(90deg,#ff6b6b,#ff3b30);border:0}
    .fade-uptiny{opacity:0;transform:translateY(8px);transition:all .36s ease}
    .fade-uptiny.show{opacity:1;transform:none}
  </style>
</head>
<body>
  <nav class="navbar navbar-light bg-white shadow-sm">
    <div class="container-fluid">
      <a class="navbar-brand d-flex align-items-center gap-2" href="<?php echo BASE_URL; ?>/index.php">
        <div style="width:34px;height:34px;border-radius:8px;background:linear-gradient(135deg,#0d6efd,#0b5ed7);display:flex;align-items:center;justify-content:center;color:#fff"><i class="bi bi-briefcase-fill"></i></div>
        <strong style="color:#0d6efd">FreelanceManager</strong>
      </a>
      <div class="ms-auto">
        <a class="btn btn-outline-secondary btn-sm" href="<?php echo BASE_URL; ?>/invoices/view.php?id=<?php echo (int)$inv['id']; ?>"><i class="bi bi-arrow-left"></i> Back to invoice</a>
      </div>
    </div>
  </nav>

  <main class="container">
    <div class="panel fade-uptiny" id="panel">
      <div class="d-flex justify-content-between align-items-start mb-3">
        <div>
          <h4 class="mb-0">Delete Invoice</h4>
          <div class="muted small">Please confirm — this will remove the invoice and any associated items & payments.</div>
        </div>
        <div class="text-end">
          <div class="small muted">Invoice</div>
          <div style="font-weight:700">#<?php echo htmlspecialchars($inv['invoice_number'] ?? $inv['id']); ?></div>
        </div>
      </div>

      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
          <ul class="mb-0"><?php foreach ($errors as $e): ?><li><?php echo htmlspecialchars($e); ?></li><?php endforeach; ?></ul>
        </div>
      <?php endif; ?>

      <div class="row g-3 mb-3">
        <div class="col-md-8">
          <p><strong>Client / Project</strong><br>
            <?php echo htmlspecialchars($inv['client_name'] ?? '—'); ?> — <?php echo htmlspecialchars($inv['project_title'] ?? '—'); ?>
          </p>
          <p><strong>Amount</strong><br><?php echo number_format($inv['amount'] ?? 0, 2); ?></p>
          <p class="text-warning small"><i class="bi bi-exclamation-triangle-fill"></i> This action cannot be undone. Deleted data cannot be recovered.</p>
        </div>

        <div class="col-md-4 text-end align-self-start">
          <div class="small muted">Created</div>
          <div><?php echo htmlspecialchars($inv['created_at'] ?? ''); ?></div>
        </div>
      </div>

      <form method="post" id="deleteForm" class="d-flex gap-2 justify-content-end">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
        <a href="<?php echo BASE_URL; ?>/invoices/view.php?id=<?php echo (int)$inv['id']; ?>" class="btn btn-outline-secondary">Cancel</a>
        <button type="button" id="confirmBtn" class="btn btn-danger">Yes, delete invoice</button>
        <button type="submit" id="submitBtn" class="btn btn-danger d-none">Deleting...</button>
      </form>

      <div class="mt-3 small muted">If you prefer not to delete permanently consider editing the invoice status to <em>cancelled</em> or implement soft-delete in the DB.</div>
    </div>
  </main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function(){
  // entrance animation
  document.getElementById('panel').classList.add('show');

  const confirmBtn = document.getElementById('confirmBtn');
  const submitBtn = document.getElementById('submitBtn');
  const deleteForm = document.getElementById('deleteForm');

  confirmBtn.addEventListener('click', function(){
    if (confirm('Are you sure you want to permanently delete this invoice and all associated data? This cannot be undone.')) {
      // show a short "Deleting..." UX to avoid double-click
      confirmBtn.classList.add('d-none');
      submitBtn.classList.remove('d-none');
      // submit the form
      deleteForm.submit();
    }
  });

});
</script>
</body>
</html>
