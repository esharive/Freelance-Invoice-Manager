<?php
// invoices/edit.php - edit invoice metadata & its itemized lines (safe with paid-item locking)
// (Updated: inputs show REMAINING qty when part-paid; server treats posted qty accordingly.)

session_start();

// IMPORTANT: define the app base path relative to domain root so all links/redirects resolve
if (!defined('APP_BASE')) {
    // Update this if your site path changes. Leading slash ensures domain-root relative.
    define('APP_BASE', '/my_works/freelance_manager/');
}

if (!isset($_SESSION['user_id'])) {
    header('Location: ' . APP_BASE . 'login.php');
    exit;
}

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../lib/invoice_helpers.php'; // compute_items_total()

$uid = (int)($_SESSION['user_id'] ?? 0);
$errors = [];

$currency_options = ['NGN','USD','EUR','GBP'];

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
}
$csrf_token = $_SESSION['csrf_token'];

// invoice id
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$id) die('No invoice id.');

// fetch invoice and ownership
$stmt = $conn->prepare("
  SELECT i.*, p.title AS project_title, p.id AS project_id, c.name AS client_name, c.user_id AS client_user_id
  FROM invoices i
  JOIN projects p ON i.project_id = p.id
  JOIN clients c ON p.client_id = c.id
  WHERE i.id = ? AND c.user_id = ?
  LIMIT 1
");
$stmt->bind_param('ii', $id, $uid);
$stmt->execute();
$inv = $stmt->get_result()->fetch_assoc();
if (!$inv) die('Invoice not found or access denied.');

// ---------------------------------------------------
// detect if payment_items table exists
// ---------------------------------------------------
$has_payment_items = false;
$check = $conn->query("SHOW TABLES LIKE 'payment_items'");
if ($check && $check->num_rows > 0) $has_payment_items = true;

// ---------------------------------------------------
// fetch existing items + qty_paid (if available)
// ---------------------------------------------------
$existing_items = [];
if ($has_payment_items) {
    $qi = $conn->prepare("
      SELECT ii.id, ii.description, ii.qty AS qty_total, ii.unit_price, ii.line_total,
             IFNULL(SUM(pi.qty),0) AS qty_paid
      FROM invoice_items ii
      LEFT JOIN payment_items pi ON pi.invoice_item_id = ii.id
      WHERE ii.invoice_id = ?
      GROUP BY ii.id, ii.description, ii.qty, ii.unit_price, ii.line_total
      ORDER BY ii.id ASC
    ");
} else {
    $qi = $conn->prepare("
      SELECT ii.id, ii.description, ii.qty AS qty_total, ii.unit_price, ii.line_total,
             0 AS qty_paid
      FROM invoice_items ii
      WHERE ii.invoice_id = ?
      ORDER BY ii.id ASC
    ");
}
$qi->bind_param('i', $id);
$qi->execute();
$resItems = $qi->get_result();
while ($row = $resItems->fetch_assoc()) {
    $row['qty_total'] = (float)$row['qty_total'];
    $row['qty_paid'] = (float)$row['qty_paid'];
    $row['unit_price'] = (float)$row['unit_price'];
    $existing_items[] = $row;
}

// Prepare $old used to prefill form (handle POST fallback)
$old = [
    'currency' => $inv['currency'] ?? $currency_options[0],
    'due_date' => $inv['due_date'] ?? '',
    'items' => []
];

// Build old items from DB (initial load): **display remaining as input value**
if (!empty($existing_items)) {
    foreach ($existing_items as $r) {
        $remaining = max(0, $r['qty_total'] - $r['qty_paid']);
        $old['items'][] = [
            'id' => $r['id'],
            'desc' => $r['description'],
            // NOTE: for paid items, we store the remaining qty in the editable input
            'qty' => (string)$remaining,
            // for new/unpaid items this is the full qty
            'price' => (string)$r['unit_price'],
            'qty_paid' => $r['qty_paid'],
            'qty_total' => $r['qty_total'],
        ];
    }
}
// ensure at least 6 rows for UI
for ($i = count($old['items']); $i < 6; $i++) {
    $old['items'][] = ['id'=>0,'desc'=>'','qty'=>'','price'=>'','qty_paid'=>0,'qty_total'=>0];
}

// flash warning
$flash_warning = $_SESSION['flash_warning'] ?? null;
if ($flash_warning) unset($_SESSION['flash_warning']);

// If invoice fully paid, lock editing
$invoice_locked = (isset($inv['status']) && $inv['status'] === 'paid');

// ------------------------
// POST handling (save)
// ------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf_token) {
        $errors[] = 'Invalid request (CSRF). Try again.';
    }

    // If invoice locked server-side, block edits
    if ($invoice_locked) {
        $errors[] = 'Invoice is fully paid and may not be edited.';
    }

    $due_date = trim($_POST['due_date'] ?? '') ?: null;
    $currency = strtoupper(trim($_POST['currency'] ?? $inv['currency'] ?? $currency_options[0]));
    if (!in_array($currency, $currency_options)) $currency = $inv['currency'] ?? $currency_options[0];

    // arrays from form (item_id[], item_desc[], item_qty[] (remaining or total depending), item_price[], item_paid[])
    $ids    = $_POST['item_id'] ?? [];
    $descs  = $_POST['item_desc'] ?? [];
    $qtys   = $_POST['item_qty'] ?? [];       // for paid items: this is REMAINING; for unpaid/new: this is TOTAL
    $prices = $_POST['item_price'] ?? [];
    $paid_arr = $_POST['item_paid'] ?? [];    // hidden field we added: the already-paid qty for each row (0 if none)

    // rebuild old for repopulation in case of validation error
    $old['currency'] = $currency;
    $old['due_date'] = $due_date;
    $old['items'] = [];
    $rowsCount = max(count($ids), count($descs), count($qtys), count($prices), count($paid_arr), 6);
    for ($r = 0; $r < $rowsCount; $r++) {
        $old['items'][$r] = [
            'id' => (int)($ids[$r] ?? 0),
            'desc' => htmlspecialchars($descs[$r] ?? '', ENT_QUOTES, 'UTF-8'),
            'qty'  => htmlspecialchars($qtys[$r] ?? '', ENT_QUOTES, 'UTF-8'),
            'price'=> htmlspecialchars($prices[$r] ?? '', ENT_QUOTES, 'UTF-8'),
            'qty_paid' => isset($paid_arr[$r]) ? (float)$paid_arr[$r] : 0,
        ];
    }

    // reload up-to-date qty_paid for posted existing ids (defensive)
    $qtyPaidMap = [];
    if ($has_payment_items) {
        $postedIds = array_values(array_filter(array_map('intval', $ids), function($v){ return $v>0; }));
        $inList = count($postedIds) ? implode(',', $postedIds) : '0';
        $q2 = $conn->prepare("SELECT invoice_item_id, IFNULL(SUM(qty),0) AS qty_paid FROM payment_items WHERE invoice_item_id IN ($inList) GROUP BY invoice_item_id");
        if ($q2) {
            $q2->execute();
            $rr = $q2->get_result();
            while ($ro = $rr->fetch_assoc()) {
                $qtyPaidMap[(int)$ro['invoice_item_id']] = (float)$ro['qty_paid'];
            }
        }
    }

    // Build arrays for DB changes:
    // For existing items: compute new_total_qty = qty_paid + posted_remaining (when qty_paid>0)
    $items_to_update = []; // [id => ['description','qty_total','unit_price','qty_paid']]
    $items_to_insert = []; // new items with total qty
    // track posted existing ids
    $posted_existing_ids = [];

    for ($r = 0; $r < $rowsCount; $r++) {
        $iid = (int)($ids[$r] ?? 0);
        $desc = trim($descs[$r] ?? '');
        $posted_qty = ($qtys[$r] ?? '') === '' ? 0 : (float)$qtys[$r];
        $price = ($prices[$r] ?? '') === '' ? 0 : (float)$prices[$r];
        $posted_paid = isset($paid_arr[$r]) ? (float)$paid_arr[$r] : 0;

        // ignore fully empty row
        if ($iid === 0 && $desc === '' && $posted_qty == 0 && $price == 0) continue;

        if ($iid > 0) {
            // existing item: find authoritative qty_paid
            $qty_paid = $qtyPaidMap[$iid] ?? $posted_paid ?? 0.0;

            // If there is a paid portion, the form's qty input is REMAINING
            if ($qty_paid > 0.0001) {
                $remaining = max(0, $posted_qty); // posted_qty is remaining (editable)
                $new_total = $qty_paid + $remaining;
            } else {
                // no paid portion: posted_qty is full total
                $new_total = max(0, $posted_qty);
            }

            // cannot reduce total below qty_paid (safety)
            if ($new_total < $qty_paid - 0.0001) {
                $errors[] = "Item #{$iid} cannot be reduced below already-paid quantity ({$qty_paid}).";
            }

            // accept update; ensure we keep qty_paid value for server checks later
            $items_to_update[$iid] = [
                'id' => $iid,
                'description' => $desc,
                'qty_total' => $new_total,
                'unit_price' => $price,
                'qty_paid' => $qty_paid
            ];
            $posted_existing_ids[] = $iid;
        } else {
            // new row: posted_qty is total for new item
            if ($desc === '' && $posted_qty == 0 && $price == 0) continue;
            if ($posted_qty <= 0 || $price < 0) {
                $errors[] = 'New items require a positive quantity and non-negative unit price.';
            } else {
                $items_to_insert[] = [
                    'description' => $desc,
                    'qty' => $posted_qty,
                    'unit_price' => $price,
                    'line_total' => round($posted_qty * $price, 2)
                ];
            }
        }
    }

    // final guard: make sure user did not REMOVE an original item that had qty_paid > 0
    $existing_ids_map = [];
    foreach ($existing_items as $ex) $existing_ids_map[(int)$ex['id']] = $ex;
    foreach ($existing_ids_map as $orig_id => $origRow) {
        if (!in_array($orig_id, $posted_existing_ids)) {
            if ((float)$origRow['qty_paid'] > 0.0001) {
                $errors[] = "Cannot remove item '{$origRow['description']}' because part of it has already been paid (qty paid: {$origRow['qty_paid']}).";
            }
        }
    }

    // Build compute arrays for authoritative total calculation (use qty_total values)
    $compute_descs = [];
    $compute_qtys = [];
    $compute_prices = [];

    foreach ($items_to_update as $it) {
        $compute_descs[] = $it['description'];
        $compute_qtys[]  = $it['qty_total'];
        $compute_prices[] = $it['unit_price'];
    }
    foreach ($items_to_insert as $ni) {
        $compute_descs[] = $ni['description'];
        $compute_qtys[]  = $ni['qty'];
        $compute_prices[] = $ni['unit_price'];
    }

    $computed = compute_items_total($compute_descs, $compute_qtys, $compute_prices);
    $items_for_save = $computed['items'];
    $amount = $computed['total'];

    if (empty($items_for_save)) $errors[] = 'Add at least one item.';
    if ($amount <= 0) $errors[] = 'Invoice total must be greater than zero.';

    if (empty($errors)) {
        $conn->begin_transaction();
        try {
            // update invoice metadata (amount, due_date, currency)
            $upd = $conn->prepare("UPDATE invoices SET amount = ?, due_date = ?, currency = ? WHERE id = ?");
            if (!$upd) throw new Exception('Prepare failed (upd invoice): ' . $conn->error);
            $upd->bind_param('dssi', $amount, $due_date, $currency, $id);
            if ($upd->execute() === false) throw new Exception('Execute failed (upd invoice): ' . $upd->error);

            // Prepare statements for item operations
            $ins_item = $conn->prepare("INSERT INTO invoice_items (invoice_id, description, qty, unit_price, line_total) VALUES (?, ?, ?, ?, ?)");
            if (!$ins_item) throw new Exception('Prepare failed (ins_item): ' . $conn->error);
            $upd_item = $conn->prepare("UPDATE invoice_items SET description = ?, qty = ?, unit_price = ?, line_total = ? WHERE id = ?");
            if (!$upd_item) throw new Exception('Prepare failed (upd_item): ' . $conn->error);
            $del_item = $conn->prepare("DELETE FROM invoice_items WHERE id = ? AND invoice_id = ?");
            if (!$del_item) throw new Exception('Prepare failed (del_item): ' . $conn->error);

            // 1) Delete allowed originals that user removed and had no paid amount
            foreach ($existing_ids_map as $orig_id => $origRow) {
                if (!in_array($orig_id, $posted_existing_ids)) {
                    // origRow qty_paid was zero or we would have errored above
                    $del_item->bind_param('ii', $orig_id, $id);
                    if ($del_item->execute() === false) throw new Exception('Could not delete item #' . $orig_id . ': ' . $del_item->error);
                }
            }

            // 2) Update existing items
            foreach ($items_to_update as $eid => $it) {
                $orig = $existing_ids_map[$eid] ?? null;
                if (!$orig) continue;

                // If qty_paid > 0, keep description & unit_price locked to original to avoid tampering with paid portion
                if ($it['qty_paid'] > 0.0001) {
                    $new_desc = $orig['description'];
                    $new_price = (float)$orig['unit_price'];
                } else {
                    $new_desc = $it['description'];
                    $new_price = $it['unit_price'];
                }
                $new_qty_total = (float)$it['qty_total'];
                if ($new_qty_total <= 0) {
                    // deletion (only allowed if qty_paid==0, but we've checked)
                    if ($it['qty_paid'] > 0) throw new Exception("Cannot delete item #{$eid} with paid qty.");
                    $del_item->bind_param('ii', $eid, $id);
                    if ($del_item->execute() === false) throw new Exception('Could not delete item #' . $eid . ': ' . $del_item->error);
                    continue;
                }
                $line_total = round($new_qty_total * $new_price, 2);
                $upd_item->bind_param('sdddi', $new_desc, $new_qty_total, $new_price, $line_total, $eid);
                if ($upd_item->execute() === false) throw new Exception('Could not update item #' . $eid . ': ' . $upd_item->error);
            }

            // 3) Insert new items
            foreach ($items_to_insert as $ni) {
                $line_total = round($ni['qty'] * $ni['unit_price'], 2);
                $ins_item->bind_param('isddd', $id, $ni['description'], $ni['qty'], $ni['unit_price'], $line_total);
                if ($ins_item->execute() === false) throw new Exception('Could not insert item: ' . $ins_item->error);
            }

            $conn->commit();

            // Reconcile payments & status (total-paid vs new amount)
            $ps = $conn->prepare("SELECT IFNULL(SUM(amount),0) AS total_paid FROM payments WHERE invoice_id = ?");
            $ps->bind_param('i', $id);
            $ps->execute();
            $paid_row = $ps->get_result()->fetch_assoc();
            $total_paid = (float)$paid_row['total_paid'];

            if ($total_paid >= round($amount, 2) && $amount > 0) {
                $now = date('Y-m-d H:i:s');
                $upd2 = $conn->prepare("UPDATE invoices SET status = 'paid', paid_at = ? WHERE id = ?");
                $upd2->bind_param('si', $now, $id);
                $upd2->execute();
            } elseif ($total_paid > 0 && $total_paid < round($amount, 2)) {
                $upd2 = $conn->prepare("UPDATE invoices SET status = 'partially_paid', paid_at = NULL WHERE id = ?");
                $upd2->bind_param('i', $id);
                $upd2->execute();
            } else {
                $upd2 = $conn->prepare("UPDATE invoices SET status = 'unpaid', paid_at = NULL WHERE id = ?");
                $upd2->bind_param('i', $id);
                $upd2->execute();
            }

            // currency change warning
            if ($inv['currency'] !== $currency) {
                $ps2 = $conn->prepare("SELECT COUNT(*) AS cnt FROM payments WHERE invoice_id = ?");
                $ps2->bind_param('i', $id);
                $ps2->execute();
                $cnt_row = $ps2->get_result()->fetch_assoc();
                $payments_count = (int)$cnt_row['cnt'];
                if ($payments_count > 0) {
                    $_SESSION['flash_warning'] = "Invoice currency changed from {$inv['currency']} to {$currency}. This invoice has {$payments_count} payment(s). Please review payments and exchange rates.";
                }
            }

            header('Location: ' . APP_BASE . 'invoices/view.php?id=' . (int)$id);
            exit;
        } catch (Exception $e) {
            $conn->rollback();
            $errors[] = 'Error updating invoice: ' . $e->getMessage();
        }
    }
} // end POST

// helper currency symbol
function get_currency_symbol($code) {
    $map = ['NGN'=>'₦','USD'=>'$','EUR'=>'€','GBP'=>'£','JPY'=>'¥','CNY'=>'¥','CAD'=>'C$','AUD'=>'A$'];
    return $map[$code] ?? $code;
}

// re-fetch up-to-date existing items with qty_paid (for display after POST)
$existing_items = [];
if ($has_payment_items) {
    $qi = $conn->prepare("
      SELECT ii.id, ii.description, ii.qty AS qty_total, ii.unit_price, ii.line_total,
             IFNULL(SUM(pi.qty),0) AS qty_paid
      FROM invoice_items ii
      LEFT JOIN payment_items pi ON pi.invoice_item_id = ii.id
      WHERE ii.invoice_id = ?
      GROUP BY ii.id, ii.description, ii.qty, ii.unit_price, ii.line_total
      ORDER BY ii.id ASC
    ");
} else {
    $qi = $conn->prepare("
      SELECT ii.id, ii.description, ii.qty AS qty_total, ii.unit_price, ii.line_total,
             0 AS qty_paid
      FROM invoice_items ii
      WHERE ii.invoice_id = ?
      ORDER BY ii.id ASC
    ");
}
$qi->bind_param('i', $id);
$qi->execute();
$resItems = $qi->get_result();
while ($row = $resItems->fetch_assoc()) {
    $row['qty_total'] = (float)$row['qty_total'];
    $row['qty_paid'] = (float)$row['qty_paid'];
    $row['unit_price'] = (float)$row['unit_price'];
    $existing_items[] = $row;
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Edit Invoice — Freelance Manager</title>
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
  <style>
    :root{--brand:#0d6efd;--muted:#6c757d}
    body{font-family:'Inter',system-ui,-apple-system,'Segoe UI',Roboto,Arial;background:#f4f7fb;color:#0b1a2b;margin:0}
    .container-main{max-width:1100px;margin:28px auto;padding:18px}
    .panel{background:#fff;border-radius:12px;padding:20px;box-shadow:0 12px 28px rgba(11,24,40,0.06)}
    .muted{color:var(--muted)}
    .line-total {font-weight:600}
    .small-muted{font-size:.9rem;color:var(--muted)}
    .fade-in{opacity:0;transform:translateY(6px);transition:all .42s cubic-bezier(.2,.9,.3,1)}
    .fade-in.show{opacity:1;transform:none}
    .control-btn{border-radius:8px}
    .paid-badge{background:#e6f4ea;color:#0b6b3b;padding:.2rem .45rem;border-radius:8px;font-weight:700}
    .locked{background:#f8f9fa}
    @media (max-width:767px){ .desk-only{display:none} }
  </style>
</head>
<body>
  <!-- topbar -->
  <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container-fluid">
      <a class="navbar-brand d-flex align-items-center gap-2" href="<?php echo APP_BASE; ?>index.php">
        <div style="width:36px;height:36px;border-radius:8px;background:linear-gradient(135deg,#0d6efd,#0b5ed7);display:flex;align-items:center;justify-content:center;color:#fff"><i class="bi bi-briefcase-fill"></i></div>
        <strong style="color:var(--brand)">FreelanceManager</strong>
      </a>
      <div class="ms-auto">
        <a class="btn btn-outline-secondary btn-sm" href="<?php echo APP_BASE; ?>invoices/list.php"><i class="bi bi-arrow-left"></i> Back</a>
      </div>
    </div>
  </nav>

  <main class="container-main">
    <div class="panel fade-in" id="mainPanel">
      <div class="d-flex justify-content-between align-items-start mb-3">
        <div>
          <h4 style="margin:0">Edit Invoice <small class="text-muted">#<?php echo htmlspecialchars($inv['invoice_number'] ?? $inv['id']); ?></small></h4>
          <div class="small-muted">Project: <?php echo htmlspecialchars($inv['project_title']); ?> — Client: <?php echo htmlspecialchars($inv['client_name']); ?></div>
        </div>
        <div class="text-end">
          <?php if ($flash_warning): ?>
            <div class="alert alert-warning mb-0"><?php echo htmlspecialchars($flash_warning); ?></div>
          <?php endif; ?>
        </div>
      </div>

      <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
          <ul class="mb-0">
            <?php foreach ($errors as $e): ?><li><?php echo htmlspecialchars($e); ?></li><?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>

      <?php if ($invoice_locked): ?>
        <div class="alert alert-info">
          This invoice is fully paid and is locked from further edits. If you need to make changes, consider creating a credit or new invoice.
        </div>
      <?php endif; ?>

      <form method="post" id="editInvoiceForm" novalidate <?php echo $invoice_locked ? 'aria-disabled="true"' : ''; ?>>
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
        <div class="row g-3">
          <div class="col-md-4">
            <label class="form-label">Currency</label>
            <select name="currency" class="form-select" <?php echo $invoice_locked ? 'disabled' : ''; ?>>
              <?php foreach ($currency_options as $c): ?>
                <option value="<?php echo $c; ?>" <?php if ($c === ($old['currency'] ?? $inv['currency'])) echo 'selected'; ?>>
                  <?php echo $c . ' — ' . get_currency_symbol($c); ?>
                </option>
              <?php endforeach; ?>
            </select>
            <div class="form-text small-muted">Changing currency will warn if payments exist.</div>
          </div>
          <div class="col-md-4">
            <label class="form-label">Due date (optional)</label>
            <input type="date" name="due_date" class="form-control" value="<?php echo htmlspecialchars($old['due_date'] ?? $inv['due_date']); ?>" <?php echo $invoice_locked ? 'disabled' : ''; ?>>
          </div>
          <div class="col-md-4 text-end align-self-end">
            <a class="btn btn-outline-secondary btn-sm" href="<?php echo APP_BASE; ?>invoices/view.php?id=<?php echo (int)$id; ?>">View invoice</a>
            <?php if (!$invoice_locked): ?>
              <button type="submit" class="btn btn-primary">Save changes</button>
            <?php else: ?>
              <button type="button" class="btn btn-secondary" disabled>Locked</button>
            <?php endif; ?>
          </div>
        </div>

        <hr class="my-3">

        <h6>Line items</h6>
        <div class="table-responsive">
          <table class="table table-sm table-bordered" id="itemsTable">
            <thead class="table-light">
              <tr>
                <th>Description</th>
                <th style="width:120px" class="text-end">Qty (editable = remaining)</th>
                <th style="width:160px" class="text-end">Unit price</th>
                <th style="width:160px" class="text-end">Line total</th>
                <th class="desk-only" style="width:64px"></th>
              </tr>
            </thead>
            <tbody>
              <?php
                // prefer $old from POST when available, otherwise use current existing_items for display
                $rows_display = $old['items'];
                // if no POST old items (first load) build from existing_items (we already prepared $old earlier)
                if (empty($old['items']) || count($old['items']) === 0) {
                    $rows_display = [];
                    foreach ($existing_items as $ei) {
                        $remaining = max(0, $ei['qty_total'] - $ei['qty_paid']);
                        $rows_display[] = [
                            'id' => $ei['id'],
                            'desc' => $ei['description'],
                            'qty' => (string)$remaining,             // show remaining in input
                            'price' => (string)$ei['unit_price'],
                            'qty_paid' => $ei['qty_paid'],
                            'qty_total' => $ei['qty_total']
                        ];
                    }
                    for ($i = count($rows_display); $i < 6; $i++) $rows_display[] = ['id'=>0,'desc'=>'','qty'=>'','price'=>'','qty_paid'=>0,'qty_total'=>0];
                }
                foreach ($rows_display as $row):
                    $id_row = (int)($row['id'] ?? 0);
                    $desc = $row['desc'] ?? '';
                    $qty = $row['qty'] ?? '';
                    $price = $row['price'] ?? '';
                    $qty_paid = isset($row['qty_paid']) ? (float)$row['qty_paid'] : 0.0;
                    $qty_total = isset($row['qty_total']) ? (float)$row['qty_total'] : 0.0;
                    $editable = !$invoice_locked; // we permit editing remaining (but server will protect paid portion)
              ?>
                <tr data-paid="<?php echo htmlspecialchars($qty_paid); ?>" data-total="<?php echo htmlspecialchars($qty_total); ?>" class="<?php echo $qty_paid > 0 ? 'locked' : ''; ?>">
                  <td>
                    <input type="hidden" name="item_id[]" value="<?php echo $id_row; ?>">
                    <!-- pass the already-paid amount back too -->
                    <input type="hidden" name="item_paid[]" value="<?php echo htmlspecialchars($qty_paid); ?>">
                    <input type="text" name="item_desc[]" class="form-control" value="<?php echo htmlspecialchars($desc); ?>" placeholder="Description" <?php echo ($invoice_locked || ($qty_paid > 0 && $qty_paid>0) ? 'readonly' : ''); ?>>
                    <?php if ($qty_paid > 0): ?>
                      <div class="small-muted mt-1">Paid: <span class="paid-badge"><?php echo htmlspecialchars($qty_paid); ?></span> — Unpaid (editable): <?php echo htmlspecialchars(max(0, $qty_total - $qty_paid)); ?></div>
                    <?php endif; ?>
                  </td>

                  <td>
                    <?php if ($qty_paid > 0): ?>
                      <div class="d-flex align-items-center justify-content-end gap-2">
                        <!-- value is remaining qty -->
                        <input type="number" name="item_qty[]" class="form-control text-end remaining-qty" step="0.01" value="<?php echo htmlspecialchars($qty); ?>" min="0" <?php echo $invoice_locked ? 'disabled' : ''; ?> >
                        <div class="small-muted" style="min-width:40px;text-align:right"><small>paid</small></div>
                      </div>
                    <?php else: ?>
                      <!-- unpaid/new: input is full total -->
                      <input type="number" name="item_qty[]" class="form-control text-end" step="0.01" value="<?php echo htmlspecialchars($qty); ?>" <?php echo $invoice_locked ? 'disabled' : ''; ?>>
                    <?php endif; ?>
                  </td>

                  <td>
                    <input type="number" name="item_price[]" class="form-control text-end" step="0.01" value="<?php echo htmlspecialchars($price); ?>" <?php echo ($invoice_locked || ($qty_paid > 0 && $qty_paid>0) ? 'readonly' : ''); ?>>
                    <?php if ($qty_paid > 0): ?>
                      <div class="small-muted mt-1">Unit price locked for paid portion</div>
                    <?php endif; ?>
                  </td>

                  <td class="text-end align-middle"><span class="line-total">0.00</span></td>
                  <td class="text-center desk-only align-middle">
                    <?php if ($invoice_locked || $qty_paid > 0): ?>
                      <button type="button" class="btn btn-sm btn-outline-secondary" disabled title="Cannot remove paid item"><i class="bi bi-lock"></i></button>
                    <?php else: ?>
                      <button type="button" class="btn btn-sm btn-outline-danger remove-row" title="Remove"><i class="bi bi-trash"></i></button>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
            <tfoot>
              <tr>
                <td colspan="2" class="text-end"><strong>Total</strong></td>
                <td class="text-end"><strong id="grandTotal">0.00</strong></td>
                <td colspan="2"></td>
              </tr>
            </tfoot>
          </table>
        </div>

        <div class="d-flex justify-content-between align-items-center mt-3">
          <div>
            <?php if (!$invoice_locked): ?>
              <button type="button" id="addRow" class="btn btn-outline-primary btn-sm"><i class="bi bi-plus-lg"></i> Add row</button>
              <button type="button" id="clearEmpty" class="btn btn-outline-secondary btn-sm">Clear empty rows</button>
            <?php endif; ?>
          </div>
          <div class="small-muted">Invoices are saved server-side. Payments will be reconciled automatically. Paid portions are locked.</div>
        </div>
      </form>
    </div>
  </main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function(){
  document.getElementById('mainPanel').classList.add('show');

  function fmt(n){ n = parseFloat(n); if (isNaN(n)) return '0.00'; return n.toFixed(2); }

  // recompute line totals and grand total
  function recompute(){
    let grand = 0;
    document.querySelectorAll('#itemsTable tbody tr').forEach(tr=>{
      const qtyEl = tr.querySelector('input[name="item_qty[]"]');
      const priceEl = tr.querySelector('input[name="item_price[]"]');
      const ltEl = tr.querySelector('.line-total');
      const paid = parseFloat(tr.dataset.paid || 0) || 0;
      const totalOriginal = parseFloat(tr.dataset.total || 0) || 0;

      let inputQty = parseFloat(qtyEl?.value || 0) || 0;

      // If this row had paid amount, the input is remaining; actual total = paid + remaining
      let actualQty = paid > 0 ? (paid + inputQty) : inputQty;

      const price = parseFloat(priceEl?.value || 0) || 0;
      const line = actualQty * price;
      if (ltEl) ltEl.textContent = fmt(line);
      grand += line;
    });
    document.getElementById('grandTotal').textContent = fmt(grand);
  }

  // initial compute
  recompute();

  // delegate input changes
  document.getElementById('itemsTable').addEventListener('input', function(e){
    if (e.target.matches('input[name="item_qty[]"], input[name="item_price[]"]')) recompute();
  });

  // add row (untouched behavior for new items - qty is total)
  document.getElementById('addRow')?.addEventListener('click', function(){
    const tbody = document.querySelector('#itemsTable tbody');
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>
        <input type="hidden" name="item_id[]" value="0">
        <input type="hidden" name="item_paid[]" value="0">
        <input type="text" name="item_desc[]" class="form-control" placeholder="Description">
      </td>
      <td><input type="number" name="item_qty[]" class="form-control text-end" step="0.01" value=""></td>
      <td><input type="number" name="item_price[]" class="form-control text-end" step="0.01" value=""></td>
      <td class="text-end align-middle"><span class="line-total">0.00</span></td>
      <td class="text-center desk-only align-middle"><button type="button" class="btn btn-sm btn-outline-danger remove-row"><i class="bi bi-trash"></i></button></td>`;
    tbody.appendChild(tr);
    recompute();
  });

  // remove row (delegated)
  document.querySelector('#itemsTable tbody').addEventListener('click', function(e){
    if (e.target.closest('.remove-row')) {
      const tr = e.target.closest('tr');
      tr.remove();
      recompute();
    }
  });

  // clear empty rows
  document.getElementById('clearEmpty')?.addEventListener('click', function(){
    document.querySelectorAll('#itemsTable tbody tr').forEach(tr=>{
      const desc = (tr.querySelector('input[name="item_desc[]"]')?.value || '').trim();
      const qty = (tr.querySelector('input[name="item_qty[]"]')?.value || '').trim();
      const price = (tr.querySelector('input[name="item_price[]"]')?.value || '').trim();
      if (desc === '' && qty === '' && price === '') tr.remove();
    });
    recompute();
  });

  // client-side submit guard
  document.getElementById('editInvoiceForm').addEventListener('submit', function(e){
    if (this.hasAttribute('aria-disabled')) {
      e.preventDefault();
      alert('This invoice is locked (fully paid) and cannot be edited.');
      return;
    }
    let found = false;
    document.querySelectorAll('#itemsTable tbody tr').forEach(tr=>{
      const desc = (tr.querySelector('input[name="item_desc[]"]')?.value || '').trim();
      const qty = parseFloat(tr.querySelector('input[name="item_qty[]"]')?.value || 0) || 0;
      const price = parseFloat(tr.querySelector('input[name="item_price[]"]')?.value || 0) || 0;
      if (desc !== '' && qty > 0) found = true;
    });
    if (!found) {
      e.preventDefault();
      alert('Add at least one item with description and a quantity > 0 before saving.');
    } else {
      const btn = this.querySelector('button[type="submit"]');
      if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Saving...';
      }
    }
  });
});
</script>
</body>
</html>
