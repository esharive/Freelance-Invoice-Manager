<?php
// invoices/download_pdf.php
// Streams an invoice PDF (forces download). Saves a copy to ../invoices_pdfs/ as well.
// Uses Dompdf and DejaVu Sans as default font so currency symbols (₦, €, £, etc.) render properly.

// --- Ensure a single base URL for this app (change once if you move the folder) ---
if (!defined('BASE_URL')) {
    // must start with a slash; points to public_html/my_works/freelance_manager
    define('BASE_URL', '/my_works/freelance_manager');
}

session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

require_once __DIR__ . '/../config/db.php';

// require Composer autoload (dompdf)
$autoload = __DIR__ . '/../vendor/autoload.php';
if (!file_exists($autoload)) {
    showErrorPage('Missing Composer autoload. Run <code>composer install</code> in the project root.');
    exit;
}
require_once $autoload;

use Dompdf\Dompdf;
use Dompdf\Options;

// helper to render a styled error/feedback page (user-facing)
function showErrorPage($message, $backUrl = null) {
    // Default back URL uses BASE_URL (do this inside function because BASE_URL may not be available at compile time)
    $backUrl = $backUrl ?: (defined('BASE_URL') ? BASE_URL . '/invoices/list.php' : '/invoices/list.php');

    // simple styled page (Bootstrap 5 from CDN)
    ?>
    <!doctype html>
    <html lang="en">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width,initial-scale=1">
      <title>Invoice PDF — Error</title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
      <style>
        body{background:#f4f7fb;color:#0b1a2b;font-family:Inter,system-ui,Arial;margin:0;padding:32px}
        .card{border-radius:12px;box-shadow:0 10px 30px rgba(16,24,40,0.06)}
        .brand{color:#0d6efd;font-weight:700}
        .muted{color:#6c757d}
        .center {max-width:920px;margin:36px auto}
        .pulse{animation:pulse 1.6s ease-in-out infinite}
        @keyframes pulse{0%{transform:translateY(0)}50%{transform:translateY(-4px)}100%{transform:translateY(0)}}
      </style>
    </head>
    <body>
      <div class="center">
        <div class="card p-4">
          <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
              <div class="brand"><i class="bi bi-briefcase-fill"></i> FreelanceManager</div>
              <div class="muted small">Invoices & Clients</div>
            </div>
            <div class="text-end">
              <div class="small muted">Account</div>
              <div><?php echo htmlspecialchars($_SESSION['user_name'] ?? ''); ?></div>
            </div>
          </div>

          <div class="p-3 border rounded bg-white">
            <h4 class="mb-2">Could not generate PDF</h4>
            <p class="muted"><?php echo $message; ?></p>
            <div class="mt-3">
              <a href="<?php echo htmlspecialchars($backUrl); ?>" class="btn btn-primary me-2">Back</a>
              <a href="<?php echo defined('BASE_URL') ? BASE_URL : '/'; ?>/invoices/view.php?id=<?php echo (int)($_GET['id'] ?? 0); ?>" class="btn btn-outline-secondary">Open invoice</a>
            </div>
          </div>

          <div class="text-muted small mt-3">If this persists, check server memory, Dompdf installation, and that fonts are available (DejaVu Sans recommended).</div>
        </div>
      </div>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
    <?php
    exit;
}

// ensure Dompdf classes exist
if (!class_exists('Dompdf\Dompdf')) {
    showErrorPage('Dompdf library not found. Run <code>composer require dompdf/dompdf</code>.');
    exit;
}

// require a numeric invoice id
$uid = (int)$_SESSION['user_id'];
$id  = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    showErrorPage('Invalid invoice id.');
    exit;
}

// fetch invoice + project + client (ownership check)
$stmt = $conn->prepare("
  SELECT i.*, p.title AS project_title, p.description AS project_description,
         c.name AS client_name, c.email AS client_email, c.phone AS client_phone, c.company AS client_company
  FROM invoices i
  JOIN projects p ON i.project_id = p.id
  JOIN clients c ON p.client_id = c.id
  WHERE i.id = ? AND c.user_id = ?
  LIMIT 1
");
if (!$stmt) {
    showErrorPage('Database error (prepare invoice): ' . htmlspecialchars($conn->error));
    exit;
}
$stmt->bind_param('ii', $id, $uid);
$stmt->execute();
$inv = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$inv) {
    showErrorPage('Invoice not found or access denied.');
    exit;
}

// fetch line items (if you use invoice_items)
$items = [];
$si = $conn->prepare("SELECT description, qty, unit_price, line_total FROM invoice_items WHERE invoice_id = ? ORDER BY id ASC");
if ($si) {
    $si->bind_param('i', $id);
    $si->execute();
    $resItems = $si->get_result();
    while ($row = $resItems->fetch_assoc()) {
        $items[] = $row;
    }
    $si->close();
}

// currency symbol map (ensure common symbols)
$symbol_map = ['NGN'=>'₦','USD'=>'$','EUR'=>'€','GBP'=>'£','JPY'=>'¥','CNY'=>'¥','CAD'=>'C$','AUD'=>'A$'];
$currency   = $inv['currency'] ?? '';
$symbol     = $symbol_map[$currency] ?? $currency;

// Build HTML for PDF. Use DejaVu Sans in CSS to make sure special symbols render.
$html = '<!doctype html><html><head><meta charset="utf-8"><style>
@font-face{font-family: "DejaVu Sans"; src: local("DejaVu Sans"); }
body{font-family:"DejaVu Sans", Arial, Helvetica, sans-serif; padding:20px; color:#222; font-size:14px}
.header{display:flex;justify-content:space-between;align-items:center}
.header .left h2{margin:0 0 4px 0}
.small{font-size:0.9rem;color:#666}
.table{width:100%;border-collapse:collapse;margin-top:18px}
.table th,.table td{border:1px solid #ddd;padding:10px;text-align:left;vertical-align:top}
.table th{background:#f7f9fc}
.right{text-align:right}
.total-row td{font-weight:700}
.footer{margin-top:18px;color:#555;font-size:0.95rem}
.meta{font-size:0.9rem;color:#333}
</style></head><body>';

$html .= '<div class="header">';
$html .= '<div class="left"><h2>Your Business Name</h2><div class="small">'.htmlspecialchars($_SESSION['user_name'] ?? '').'</div></div>';
$html .= '<div class="right meta"><strong>Invoice #'.htmlspecialchars($inv['invoice_number'] ?? $inv['id']).'</strong><br>Created: '.htmlspecialchars($inv['created_at']).'<br>Due: '.htmlspecialchars($inv['due_date']).'</div>';
$html .= '</div>';

$html .= '<h3 style="margin-top:18px">Bill to</h3>';
$html .= '<div><strong>'.htmlspecialchars($inv['client_name']).'</strong>';
if (!empty($inv['client_company'])) $html .= ' — '.htmlspecialchars($inv['client_company']);
if (!empty($inv['client_email']))   $html .= '<br>'.htmlspecialchars($inv['client_email']);
if (!empty($inv['client_phone']))   $html .= '<br>'.htmlspecialchars($inv['client_phone']);
$html .= '</div>';

// Items table
$html .= '<table class="table" cellpadding="0" cellspacing="0">';
$html .= '<thead><tr><th style="width:55%">Description</th><th style="width:10%">Qty</th><th style="width:17%">Unit</th><th style="width:18%" class="right">Line total</th></tr></thead><tbody>';

if (!empty($items)) {
    foreach ($items as $it) {
        $desc = nl2br(htmlspecialchars($it['description']));
        $qty  = number_format((float)$it['qty'], 2);
        $unit = number_format((float)$it['unit_price'], 2);
        $line = number_format((float)$it['line_total'], 2);
        $html .= "<tr><td>{$desc}</td><td>{$qty}</td><td>{$symbol} {$unit}</td><td class='right'>{$symbol} {$line}</td></tr>";
    }
} else {
    // fallback: show the invoice amount if no line items exist
    $html .= '<tr><td colspan="4">No itemized lines — single amount invoice</td></tr>';
}

$html .= '<tr class="total-row"><td colspan="3" class="right">Total</td><td class="right">'.$symbol.' '.number_format((float)$inv['amount'],2).'</td></tr>';
$html .= '</tbody></table>';

$html .= '<div class="footer">';
$html .= '<p>Status: <strong>'.htmlspecialchars($inv['status']).'</strong></p>';
$html .= '<p>Thank you for your business.</p>';
$html .= '</div>';

$html .= '</body></html>';

// Setup Dompdf with options
$options = new Options();
$options->set('isRemoteEnabled', true);
// Use DejaVu Sans so unicode symbols show correctly
$options->set('defaultFont', 'DejaVu Sans');

$dompdf = new Dompdf($options);

try {
    // ensure UTF-8
    $dompdf->loadHtml($html, 'UTF-8');
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();

    // Save copy to server (optional; helps re-download later)
    $output = $dompdf->output();
    $timestamp = date('Ymd_His');
    $filename = 'invoice_' . ($inv['invoice_number'] ?? $inv['id']) . '_' . $timestamp . '.pdf';
    $saveDir = __DIR__ . '/../invoices_pdfs/';
    if (!is_dir($saveDir)) @mkdir($saveDir, 0755, true);
    $savePath = $saveDir . $filename;
    @file_put_contents($savePath, $output);

    // Stream to browser and force download
    // Attachment => true forces download
    $dompdf->stream($filename, ["Attachment" => true]);
    exit;
} catch (Exception $e) {
    // On error show friendly page
    showErrorPage('Failed to generate PDF: ' . htmlspecialchars($e->getMessage()), (defined('BASE_URL') ? BASE_URL : '') . '/invoices/view.php?id=' . (int)$id);
    exit;
}
