<?php
// invoices/pdf.php
session_start();

// ensure a single base path constant (adjust if your site path changes)
if (!defined('APP_BASE')) {
    define('APP_BASE', '/my_works/freelance_manager/');
}

if (!isset($_SESSION['user_id'])) {
    header('Location: ' . APP_BASE . 'login.php');
    exit;
}
require_once __DIR__ . '/../config/db.php';

// require Composer autoload (safe check)
$vendorAutoload = __DIR__ . '/../vendor/autoload.php';
if (file_exists($vendorAutoload)) {
    require_once $vendorAutoload;
}

// If Dompdf classes are not present this will still error later — keeping original behavior
use Dompdf\Dompdf;
use Dompdf\Options;

$uid = (int)($_SESSION['user_id'] ?? 0);
$id  = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$id) die('No invoice id.');

// fetch invoice + project + client + user company profile
$stmt = $conn->prepare("
  SELECT i.*, p.title AS project_title, p.description AS project_description,
         c.name AS client_name, c.email AS client_email, c.phone AS client_phone, c.company AS client_company,
         u.company_name AS user_company, u.company_email AS user_email, u.company_phone AS user_phone, 
         u.company_address AS user_address, u.logo AS user_logo, 
         u.currency AS default_currency, u.invoice_number_format, u.default_payment_terms
  FROM invoices i
  JOIN projects p ON i.project_id = p.id
  JOIN clients c ON p.client_id = c.id
  JOIN users u ON c.user_id = u.id
  WHERE i.id = ? AND u.id = ?
  LIMIT 1
");
$stmt->bind_param('ii', $id, $uid);
$stmt->execute();
$inv = $stmt->get_result()->fetch_assoc();
if (!$inv) die('Invoice not found or access denied.');

// invoice number handling
$invoice_number = $inv['invoice_number'] ?? str_replace('{id}', $inv['id'], $inv['invoice_number_format']);

// currency symbol
$symbol_map = ['NGN'=>'₦','USD'=>'$','EUR'=>'€','GBP'=>'£'];
$currency   = $inv['currency'] ?: $inv['default_currency'];
$symbol     = $symbol_map[$currency] ?? $currency;

// logo
$logo_html = '';
if (!empty($inv['user_logo'])) {
    $logo_path = __DIR__ . '/../uploads/logos/' . $inv['user_logo'];
    if (file_exists($logo_path)) {
        $logo_html = '<img src="data:image/png;base64,' . base64_encode(file_get_contents($logo_path)) . '" style="max-height:60px;">';
    }
}

// build HTML for PDF
$html = '<!doctype html><html><head><meta charset="utf-8"><style>
body { font-family: DejaVu Sans, sans-serif; padding:20px; color:#333; font-size:14px }
.header { display:flex; justify-content:space-between; align-items:center }
table { width:100%; border-collapse:collapse; margin-top:20px }
th,td { border:1px solid #ccc; padding:8px; text-align:left; vertical-align:top }
.right { text-align:right }
</style></head><body>';

$html .= '<div class="header">';
$html .= '<div>';
if ($logo_html) $html .= $logo_html . '<br>';
$html .= '<h2>'.htmlspecialchars($inv['user_company']).'</h2>';
if ($inv['user_address']) $html .= '<div>'.nl2br(htmlspecialchars($inv['user_address'])).'</div>';
if ($inv['user_email'])   $html .= '<div>'.htmlspecialchars($inv['user_email']).'</div>';
if ($inv['user_phone'])   $html .= '<div>'.htmlspecialchars($inv['user_phone']).'</div>';
$html .= '</div>';
$html .= '<div><strong>Invoice '.$invoice_number.'</strong><br>Created: '.htmlspecialchars($inv['created_at']).'<br>Due: '.htmlspecialchars($inv['due_date']).'</div>';
$html .= '</div>';

$html .= '<h3>Bill to</h3><div><strong>'.htmlspecialchars($inv['client_name']).'</strong>';
if($inv['client_company']) $html .= ' — '.htmlspecialchars($inv['client_company']);
if($inv['client_email']) $html .= '<br>'.htmlspecialchars($inv['client_email']);
if($inv['client_phone']) $html .= '<br>'.htmlspecialchars($inv['client_phone']);
$html .= '</div>';

$html .= '<table><tr><th>Project</th><th>Description</th><th class="right">Amount</th></tr>';
$html .= '<tr><td>'.htmlspecialchars($inv['project_title']).'</td>';
$html .= '<td>'.nl2br(htmlspecialchars($inv['project_description'])).'</td>';
$html .= '<td class="right">'.$symbol.' '.number_format($inv['amount'],2).'</td></tr>';
$html .= '<tr><td colspan="2" class="right"><strong>Total</strong></td>';
$html .= '<td class="right"><strong>'.$symbol.' '.number_format($inv['amount'],2).'</strong></td></tr>';
$html .= '</table>';

$html .= '<p style="margin-top:20px">Status: <strong>'.htmlspecialchars($inv['status']).'</strong></p>';

if (!empty($inv['default_payment_terms'])) {
    $html .= '<p style="margin-top:20px"><strong>Payment Terms:</strong> '.htmlspecialchars($inv['default_payment_terms']).'</p>';
}

$html .= '<p style="margin-top:20px">Thank you for your business.</p>';

$html .= '</body></html>';

// Setup Dompdf
$options = new Options();
$options->set('isRemoteEnabled', true);
$options->set('defaultFont', 'DejaVu Sans'); // ✅ ensures proper currency rendering
$dompdf = new Dompdf($options);
$dompdf->loadHtml($html, 'UTF-8'); // ✅ force UTF-8
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

// prepare filename and save path
$timestamp = date('Ymd_His');
$filename = 'invoice_' . $inv['id'] . '_' . $timestamp . '.pdf';
$saveDir = __DIR__ . '/../invoices_pdfs/';
if (!is_dir($saveDir)) mkdir($saveDir, 0755, true);
$savePath = $saveDir . $filename;

// save to server
file_put_contents($savePath, $dompdf->output());

// stream to browser (preview inline)
$dompdf->stream($filename, ["Attachment" => 0]);

exit;
