<?php
// invoices/mark_paid.php — item-level payments (display paid + unpaid per item, live total)
session_start();

// ensure a single base path constant (adjust if your site path changes)
if (!defined('APP_BASE')) {
    define('APP_BASE', '/my_works/freelance_manager/');
}

if (!isset($_SESSION['user_id'])) {
    header('Location: ' . APP_BASE . 'login.php');
    exit;
}
require_once __DIR__ . '/../config/db.php';

$uid = (int)($_SESSION['user_id'] ?? 0);
$id  = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$id) { header('Location: ' . APP_BASE . 'invoices/list.php'); exit; }

// fetch invoice + client
$stmt = $conn->prepare("
    SELECT i.id, i.amount, i.currency, i.status, COALESCE(i.is_locked,0) AS is_locked,
           p.title AS project_title, c.user_id
    FROM invoices i
    JOIN projects p ON i.project_id = p.id
    JOIN clients c ON p.client_id = c.id
    WHERE i.id = ? AND c.user_id = ?
    LIMIT 1
");
$stmt->bind_param('ii', $id, $uid);
$stmt->execute();
$inv = $stmt->get_result()->fetch_assoc();
if (!$inv) die("Invoice not found or access denied.");

// fetch items with qty already paid (payment_items column is 'qty')
$itemStmt = $conn->prepare("
    SELECT ii.id, ii.description, ii.qty, ii.unit_price,
           IFNULL(SUM(pi.qty), 0) AS qty_paid
    FROM invoice_items ii
    LEFT JOIN payment_items pi ON pi.invoice_item_id = ii.id
    WHERE ii.invoice_id = ?
    GROUP BY ii.id, ii.description, ii.qty, ii.unit_price
    ORDER BY ii.id ASC
");
$itemStmt->bind_param('i', $id);
$itemStmt->execute();
$items_res = $itemStmt->get_result();
$items = $items_res ? $items_res->fetch_all(MYSQLI_ASSOC) : [];

// already locked?
$already_locked = ((int)$inv['is_locked'] === 1) || strtolower($inv['status']) === 'paid';

// csrf
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(16));
$csrf_token = $_SESSION['csrf_token'];

$errors = [];

// handle POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$already_locked) {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf_token) {
        $errors[] = "Invalid CSRF token.";
    } else {
        $method = trim($_POST['method'] ?? '');
        $currency = strtoupper(trim($_POST['currency'] ?? $inv['currency']));
        $tx = trim($_POST['transaction_ref'] ?? '');
        $paid_at = date('Y-m-d H:i:s');

        if ($method === '') $errors[] = "Payment method required.";

        $paid_items = $_POST['pay_item'] ?? []; // array invoice_item_id => qty_to_pay

        $total_amount = 0.0;
        $pay_data = [];

        // re-use items array (fresh from top) to validate what's left
        foreach ($items as $it) {
            $iid = (int)$it['id'];
            $qty_to_pay = isset($paid_items[$iid]) ? (float)$paid_items[$iid] : 0.0;
            if ($qty_to_pay > 0) {
                $max_left = (float)$it['qty'] - (float)$it['qty_paid'];
                if ($qty_to_pay > $max_left + 0.0001) {
                    $errors[] = "Cannot pay more than remaining qty for item: " . htmlspecialchars($it['description']);
                } else {
                    $line_amount = round($qty_to_pay * (float)$it['unit_price'], 2);
                    $total_amount += $line_amount;
                    $pay_data[] = [
                        'invoice_item_id' => $iid,
                        'qty' => $qty_to_pay,
                        'amount' => $line_amount
                    ];
                }
            }
        }

        if ($total_amount <= 0.0001) $errors[] = "Select at least one item/quantity to pay.";

        if (empty($errors)) {
            $conn->begin_transaction();
            try {
                // insert into payments
                $pstmt = $conn->prepare("INSERT INTO payments (invoice_id, amount, currency, method, transaction_ref, paid_at) VALUES (?, ?, ?, ?, ?, ?)");
                if (!$pstmt) throw new Exception('Prepare failed (payments insert): ' . $conn->error);
                $pstmt->bind_param('idssss', $id, $total_amount, $currency, $method, $tx, $paid_at);
                if (!$pstmt->execute()) throw new Exception('Execute failed (payments insert): ' . $pstmt->error);
                $payment_id = $conn->insert_id;

                // insert into payment_items
                $pis = $conn->prepare("INSERT INTO payment_items (payment_id, invoice_item_id, qty, amount) VALUES (?,?,?,?)");
                if (!$pis) throw new Exception('Prepare failed (payment_items insert): ' . $conn->error);
                foreach ($pay_data as $pd) {
                    $pis->bind_param('iiid', $payment_id, $pd['invoice_item_id'], $pd['qty'], $pd['amount']);
                    if (!$pis->execute()) throw new Exception('Execute failed (payment_items insert): ' . $pis->error);
                }

                // check if fully paid (all items)
                $checkSql = "
                    SELECT SUM(ii.qty) = SUM(IFNULL(pi_sum.total_qty,0)) AS fully_paid
                    FROM invoice_items ii
                    LEFT JOIN (
                        SELECT invoice_item_id, SUM(qty) AS total_qty
                        FROM payment_items
                        GROUP BY invoice_item_id
                    ) pi_sum ON pi_sum.invoice_item_id = ii.id
                    WHERE ii.invoice_id = ?
                ";
                $chk = $conn->prepare($checkSql);
                $chk->bind_param('i', $id);
                $chk->execute();
                $chkRow = $chk->get_result()->fetch_assoc();
                $is_full = (int)$chkRow['fully_paid'] === 1;

                if ($is_full) {
                    $upd = $conn->prepare("UPDATE invoices SET status='paid', is_locked=1, paid_at=? WHERE id=?");
                    $upd->bind_param('si', $paid_at, $id);
                    $upd->execute();
                } else {
                    $upd = $conn->prepare("UPDATE invoices SET status='partially_paid', is_locked=0, paid_at=NULL WHERE id=?");
                    $upd->bind_param('i', $id);
                    $upd->execute();
                }

                $conn->commit();
                header('Location: ' . APP_BASE . 'invoices/view.php?id=' . $id);
                exit;
            } catch (Exception $e) {
                $conn->rollback();
                $errors[] = "DB error: ".$e->getMessage();
            }
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Record Payment — Invoice #<?= (int)$inv['id'] ?></title>
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .muted{color:#6c757d}
    .right { text-align: right; }
  </style>
</head>
<body class="bg-light">
<div class="container py-4">
  <h3>Record Payment for Invoice #<?= (int)$inv['id'] ?></h3>
  <p class="text-muted"><?= htmlspecialchars($inv['project_title']) ?></p>

  <?php if ($already_locked): ?>
    <div class="alert alert-warning">This invoice is fully paid/locked. No further payments allowed.</div>
  <?php endif; ?>

  <?php if (!empty($errors)): ?>
    <div class="alert alert-danger"><ul><?php foreach ($errors as $e) echo "<li>".htmlspecialchars($e)."</li>"; ?></ul></div>
  <?php endif; ?>

  <?php if (!$already_locked): ?>
  <form method="post" id="markPaidForm">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
    <div class="table-responsive mb-3">
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>Item</th>
            <th class="text-end" style="width:90px">Qty</th>
            <th class="text-end" style="width:110px">Paid</th>
            <th class="text-end" style="width:110px">Remaining</th>
            <th class="text-end" style="width:120px">Unit Price</th>
            <th class="text-end" style="width:140px">Pay Now (qty)</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($items as $it):
            $qty_total = (float)$it['qty'];
            $qty_paid = (float)$it['qty_paid'];
            $remaining = max(0, $qty_total - $qty_paid);
            $unit = (float)$it['unit_price'];
        ?>
          <tr data-item-id="<?= (int)$it['id'] ?>" data-unit="<?= htmlspecialchars($unit) ?>" data-remaining="<?= htmlspecialchars($remaining) ?>">
            <td><?= htmlspecialchars($it['description']) ?></td>
            <td class="text-end"><?= $qty_total ?></td>
            <td class="text-end"><?= $qty_paid ?></td>
            <td class="text-end"><?= $remaining ?></td>
            <td class="text-end"><?= number_format($unit,2) ?></td>
            <td class="text-end">
              <?php if ($remaining > 0): ?>
                <input type="number" name="pay_item[<?= (int)$it['id'] ?>]" class="form-control pay-qty text-end" min="0" max="<?= $remaining ?>" step="0.01" value="0" style="width:120px;margin-left:auto">
              <?php else: ?>
                <span class="badge bg-success">Fully Paid</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div class="row g-3 align-items-end">
      <div class="col-md-4">
        <label class="form-label">Currency</label>
        <input type="text" name="currency" value="<?= htmlspecialchars($inv['currency']) ?>" class="form-control">
      </div>
      <div class="col-md-4">
        <label class="form-label">Payment Method</label>
        <select name="method" class="form-select" required>
          <option value="">Choose…</option>
          <option>Cash</option>
          <option>Bank Transfer</option>
          <option>Paystack</option>
          <option>Stripe</option>
          <option>Other</option>
        </select>
      </div>
      <div class="col-md-4">
        <label class="form-label">Transaction Ref (optional)</label>
        <input type="text" name="transaction_ref" class="form-control">
      </div>
    </div>

    <div class="d-flex justify-content-between align-items-center mt-3">
      <div>
        <button class="btn btn-primary" id="submitBtn">Record Payment</button>
        <a href="<?php echo APP_BASE; ?>invoices/view.php?id=<?= (int)$inv['id'] ?>" class="btn btn-secondary">Cancel</a>
      </div>
      <div class="text-end">
        <div class="muted">Total to record</div>
        <div style="font-weight:700;font-size:1.05rem" id="liveTotal"><?= htmlspecialchars($inv['currency']) ?> 0.00</div>
      </div>
    </div>
  </form>
  <?php endif; ?>
</div>

<script>
// live total calc and validation
document.addEventListener('DOMContentLoaded', function(){
  const rows = Array.from(document.querySelectorAll('tr[data-item-id]'));
  const liveTotalEl = document.getElementById('liveTotal');
  const currency = <?= json_encode(htmlspecialchars($inv['currency'])) ?> || '';
  function fmt(n){ n = parseFloat(n); if (isNaN(n)) return '0.00'; return n.toFixed(2); }

  function recompute() {
    let total = 0;
    rows.forEach(r=>{
      const remaining = parseFloat(r.dataset.remaining || 0) || 0;
      const unit = parseFloat(r.dataset.unit || 0) || 0;
      const input = r.querySelector('.pay-qty');
      if (!input) return;
      let q = parseFloat(input.value || 0) || 0;
      if (q < 0) q = 0;
      if (q > remaining) {
        input.value = remaining;
        q = remaining;
      }
      total += q * unit;
    });
    liveTotalEl.textContent = currency + ' ' + fmt(total);
    return total;
  }

  // wire input events
  document.querySelectorAll('.pay-qty').forEach(inp=>{
    inp.addEventListener('input', recompute);
    inp.addEventListener('change', recompute);
  });

  // initial compute
  recompute();

  // submit guard
  const form = document.getElementById('markPaidForm');
  const submitBtn = document.getElementById('submitBtn');
  form?.addEventListener('submit', function(e){
    // re-run server-side validation early: ensure total > 0
    const total = recompute();
    if (total <= 0) {
      e.preventDefault();
      alert('Select at least one item/quantity to pay.');
      return;
    }
    // disable button to avoid double-submit
    submitBtn.disabled = true;
    submitBtn.innerHTML = 'Recording...';
  });
});
</script>
</body>
</html>
