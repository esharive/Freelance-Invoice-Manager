<?php
// invoices/email_invoice.php
// Preview + send invoice by email with generated PDF attachment.
// - Builds HTML invoice preview (same content that will be attached as PDF).
// - Generates a PDF (Dompdf + DejaVu Sans to support ₦/€, etc.), saves a copy under invoices_pdfs/
// - Sends email using PHPMailer + SMTP (reads mailbox config from .env)
// - Shows a polished Bootstrap UI with preview, send button and result
//
// This file fixes the "undefined variable" errors by ensuring we DO NOT call sendMail()
// or reference $inv/$email_html/$to before fetching the invoice and building the HTML.

session_start();

// ensure a single base path constant (adjust if your site path changes)
if (!defined('APP_BASE')) {
    define('APP_BASE', '/my_works/freelance_manager/');
}

if (!isset($_SESSION['user_id'])) {
    header('Location: ' . APP_BASE . 'login.php');
    exit;
}

require_once __DIR__ . '/../config/db.php';
$uid = (int)($_SESSION['user_id'] ?? 0);

// Attempt to load Composer autoload (dompdf, phpmailer, phpdotenv)
$vendorAutoload = __DIR__ . '/../vendor/autoload.php';
$hasVendor = false;
if (file_exists($vendorAutoload)) {
    require_once $vendorAutoload;
    $hasVendor = true;
}

// optional local helper (legacy fallback)
$sendlib = __DIR__ . '/../lib/send_mail.php';
$hasSendLib = false;
if (file_exists($sendlib)) {
    require_once $sendlib; // may define sendMail()
    $hasSendLib = function_exists('sendMail');
}

// If phpdotenv is available on vendor, load .env (safe)
if ($hasVendor && class_exists('\Dotenv\Dotenv')) {
    try {
        \Dotenv\Dotenv::createImmutable(__DIR__ . '/..')->safeLoad();
    } catch (Throwable $e) {
        // ignore - env may not exist on local dev
    }
}

// helpers
function get_currency_symbol($code) {
    $map = ['NGN'=>'₦','USD'=>'$','EUR'=>'€','GBP'=>'£','JPY'=>'¥','CNY'=>'¥','CAD'=>'C$','AUD'=>'A$'];
    return $map[$code] ?? $code;
}
function h($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

// logging helper
function log_mail($message) {
    $logDir = __DIR__ . '/../storage/logs/';
    if (!is_dir($logDir)) {
        mkdir($logDir, 0755, true);
    }
    $logFile = $logDir . 'mail.log';
    $entry = '[' . date('Y-m-d H:i:s') . '] ' . $message . PHP_EOL;
    file_put_contents($logFile, $entry, FILE_APPEND);
}

// required invoice id
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    die('No invoice id.');
}

// fetch invoice + project + client (ownership)
$stmt = $conn->prepare("
  SELECT i.*, p.title AS project_title, p.description AS project_description,
         c.name AS client_name, c.email AS client_email, c.phone AS client_phone, c.company AS client_company
  FROM invoices i
  JOIN projects p ON i.project_id = p.id
  JOIN clients c ON p.client_id = c.id
  WHERE i.id = ? AND c.user_id = ?
  LIMIT 1
");
if (!$stmt) {
    die('DB error: ' . htmlspecialchars($conn->error));
}
$stmt->bind_param('ii', $id, $uid);
$stmt->execute();
$inv = $stmt->get_result()->fetch_assoc();
$stmt->close();
if (!$inv) die('Invoice not found or access denied.');

// fetch invoice items (if any)
$items = [];
$si = $conn->prepare("SELECT description, qty, unit_price, line_total FROM invoice_items WHERE invoice_id = ? ORDER BY id ASC");
if ($si) {
    $si->bind_param('i', $id);
    $si->execute();
    $resItems = $si->get_result();
    while ($row = $resItems->fetch_assoc()) $items[] = $row;
    $si->close();
}

$symbol = get_currency_symbol($inv['currency'] ?? '');

// Build the HTML content used for preview and PDF attachment
$pdf_invoice_html = '<!doctype html><html><head><meta charset="utf-8"><style>
@font-face{font-family:"DejaVu Sans"; src: local("DejaVu Sans");}
body{font-family:"DejaVu Sans",Arial,Helvetica,sans-serif;color:#222;font-size:14px;padding:20px}
.header{display:flex;justify-content:space-between;align-items:center}
.small{font-size:0.9rem;color:#666}
.table{width:100%;border-collapse:collapse;margin-top:18px}
.table th,.table td{border:1px solid #ddd;padding:10px;text-align:left;vertical-align:top}
.table th{background:#f7f9fc}
.right{text-align:right}
.total-row td{font-weight:700}
</style></head><body>';

$pdf_invoice_html .= '<div class="header"><div><h2>'.h($_SESSION['user_name'] ?? 'Your Business').'</h2><div class="small">Invoice from '.h($_SESSION['user_name'] ?? '').'</div></div>';
$pdf_invoice_html .= '<div class="right small"><strong>Invoice #'.h($inv['invoice_number'] ?? $inv['id']).'</strong><br>Created: '.h($inv['created_at']).'<br>Due: '.h($inv['due_date']).'</div></div>';

$pdf_invoice_html .= '<h3>Bill to</h3><div><strong>'.h($inv['client_name']).'</strong>';
if (!empty($inv['client_company'])) $pdf_invoice_html .= ' — '.h($inv['client_company']);
if (!empty($inv['client_email'])) $pdf_invoice_html .= '<br>'.h($inv['client_email']);
if (!empty($inv['client_phone'])) $pdf_invoice_html .= '<br>'.h($inv['client_phone']);
$pdf_invoice_html .= '</div>';

$pdf_invoice_html .= '<table class="table"><thead><tr><th style="width:60%">Description</th><th style="width:10%">Qty</th><th style="width:15%">Unit</th><th style="width:15%" class="right">Line total</th></tr></thead><tbody>';
if (!empty($items)) {
    foreach ($items as $it) {
        $desc = nl2br(h($it['description']));
        $qty = number_format((float)$it['qty'], 2);
        $unit = number_format((float)$it['unit_price'], 2);
        $line = number_format((float)$it['line_total'], 2);
        $pdf_invoice_html .= "<tr><td>{$desc}</td><td>{$qty}</td><td>{$symbol} {$unit}</td><td class='right'>{$symbol} {$line}</td></tr>";
    }
} else {
    // single-amount fallback
    $pdf_invoice_html .= '<tr><td colspan="3">Invoice amount</td><td class="right">'.$symbol.' '.number_format((float)$inv['amount'],2).'</td></tr>';
}
$pdf_invoice_html .= '<tr class="total-row"><td colspan="3" class="right">Total</td><td class="right">'.$symbol.' '.number_format((float)$inv['amount'],2).'</td></tr>';
$pdf_invoice_html .= '</tbody></table>';

$pdf_invoice_html .= '<p style="margin-top:18px">Status: <strong>'.h($inv['status']).'</strong></p>';
$pdf_invoice_html .= '<p style="margin-top:18px">Thank you for your business.</p>';
$pdf_invoice_html .= '</body></html>';

// variables for UI & sending
$send_result = null;
$sent_ok = false;
$errors = [];
$savePath = '';

// Prepare email metadata now (after invoice and html built)
$to = $inv['client_email'] ?? '';
$email_html = $pdf_invoice_html;
$subject = 'Invoice ' . ($inv['invoice_number'] ?? ('#' . $inv['id'])) . ' from ' . ($_SESSION['user_name'] ?? 'Freelance Manager');
$alt = strip_tags(str_replace(["\r","\n"],['',''],$email_html));

// If user requested to send email
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_email'])) {

    // 1) generate PDF if dompdf available
    if (class_exists('\Dompdf\Dompdf')) {
        try {
            $options = new \Dompdf\Options();
            $options->set('isRemoteEnabled', true);
            $options->set('defaultFont', 'DejaVu Sans');

            $dompdf = new \Dompdf\Dompdf($options);
            $dompdf->loadHtml($email_html, 'UTF-8');
            $dompdf->setPaper('A4', 'portrait');
            $dompdf->render();

            // save PDF copy
            $saveDir = __DIR__ . '/../invoices_pdfs/';
            if (!is_dir($saveDir)) mkdir($saveDir, 0755, true);
            $timestamp = date('Ymd_His');
            $safeInv = preg_replace('/[^A-Za-z0-9_\-]/', '_', ($inv['invoice_number'] ?? $inv['id']));
            $pdfFilename = "invoice_{$safeInv}_{$timestamp}.pdf";
            $savePath = $saveDir . $pdfFilename;
            file_put_contents($savePath, $dompdf->output());
        } catch (Throwable $e) {
            $errors[] = 'Could not generate PDF: ' . $e->getMessage();
            log_mail("PDF generation failed for invoice {$id}: " . $e->getMessage());
        }
    } else {
        $errors[] = 'Dompdf not installed — PDF will not be attached. Install dompdf via Composer to enable PDF attachments.';
        log_mail("Dompdf missing when trying to generate invoice {$id}");
    }

    // 2) Send email: prefer PHPMailer, fallback to sendMail() from lib/send_mail.php if available
    if (empty($errors)) {
        if (class_exists('\PHPMailer\PHPMailer\PHPMailer')) {
            try {
                $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
                $mail->isSMTP();
                $mail->Host = $_ENV['MAIL_HOST'] ?? ($_ENV['MAILER_HOST'] ?? 'smtp.gmail.com');
                $mail->SMTPAuth = true;
                $mail->Username = $_ENV['MAIL_USERNAME'] ?? ($_ENV['MAIL_USER'] ?? '');
                $mail->Password = $_ENV['MAIL_PASSWORD'] ?? ($_ENV['MAIL_PASS'] ?? '');
                $enc = strtolower($_ENV['MAIL_ENCRYPTION'] ?? ($_ENV['MAIL_ENC'] ?? 'tls'));
                if ($enc === 'ssl') {
                    $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
                    $mail->Port = isset($_ENV['MAIL_PORT']) ? (int)$_ENV['MAIL_PORT'] : 465;
                } else {
                    $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->Port = isset($_ENV['MAIL_PORT']) ? (int)$_ENV['MAIL_PORT'] : 587;
                }

                $fromEmail = $_ENV['MAIL_FROM'] ?? $_ENV['MAIL_USERNAME'] ?? 'no-reply@example.com';
                $fromName  = $_ENV['MAIL_FROM_NAME'] ?? ($_SESSION['user_name'] ?? 'Freelance Manager');
                $mail->setFrom($fromEmail, $fromName);

                if (empty($to)) throw new \Exception('Client has no email address.');

                $mail->addAddress($to, $inv['client_name'] ?? '');
                $mail->isHTML(true);
                $mail->Subject = $subject;
                $mail->Body = $email_html;
                $mail->AltBody = $alt;

                if (!empty($savePath) && file_exists($savePath)) {
                    $mail->addAttachment($savePath, basename($savePath));
                }

                $mail->send();
                $sent_ok = true;
                $send_result = 'Email sent successfully to ' . h($to) . '.';
                log_mail("Email sent to {$to} for invoice {$id}");
            } catch (Throwable $e) {
                $errors[] = 'Send failed: ' . $e->getMessage();
                if (isset($mail) && !empty($mail->ErrorInfo)) {
                    $errors[] = 'SMTP info: ' . $mail->ErrorInfo;
                    log_mail("SMTP send failed to {$to} for invoice {$id}: " . $mail->ErrorInfo);
                } else {
                    log_mail("Send failed to {$to} for invoice {$id}: " . $e->getMessage());
                }
            }
        } elseif ($hasSendLib) {
            // fallback to user-provided sendMail helper (might not support attachments)
            try {
                $res = sendMail($to, $inv['client_name'] ?? '', $subject, $email_html, $alt);
                if ($res === true) {
                    $sent_ok = true;
                    $send_result = 'Email sent (via send_mail helper) to ' . h($to) . '.';
                    log_mail("Email sent via send_mail helper to {$to} for invoice {$id}");
                } else {
                    $errors[] = 'send_mail helper returned an error: ' . (is_string($res) ? $res : 'unknown error');
                    log_mail("send_mail helper error to {$to} for invoice {$id}: " . (is_string($res) ? $res : 'unknown error'));
                }
            } catch (Throwable $e) {
                $errors[] = 'send_mail helper failed: ' . $e->getMessage();
                log_mail("send_mail helper failed to {$to} for invoice {$id}: " . $e->getMessage());
            }
        } else {
            $errors[] = 'No mailer available — install PHPMailer (via Composer) or provide lib/send_mail.php.';
            log_mail("No mailer available for invoice {$id}");
        }
    }
}

// UI output (Bootstrap)
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Email Invoice #<?php echo h($inv['invoice_number'] ?? $inv['id']); ?> — Freelance Manager</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body{font-family:Inter,system-ui,Arial;background:#f4f7fb;color:#0b1a2b}
    .container{max-width:1100px}
    .card-brand{border-radius:12px;box-shadow:0 8px 28px rgba(11,78,200,0.06)}
    .preview{background:#fff;border:1px solid #eef2ff;padding:14px;border-radius:8px}
    .muted{color:#6c757d}
    .fade-in {opacity:0;transform:translateY(8px);transition:all .44s cubic-bezier(.2,.9,.3,1)}
    .fade-in.in {opacity:1;transform:none}
  </style>
</head>
<body>
  <div class="container py-5">
    <div class="card p-4 card-brand mb-4">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <h4 class="mb-0">Email Invoice</h4>
          <div class="muted small">Preview and send invoice as PDF attachment</div>
        </div>
        <div class="text-end">
          <a class="btn btn-outline-secondary btn-sm" href="<?php echo APP_BASE; ?>invoices/view.php?id=<?php echo (int)$inv['id']; ?>"><i class="bi bi-eye"></i> Open invoice</a>
          <a class="btn btn-outline-primary btn-sm" href="<?php echo APP_BASE; ?>invoices/list.php">Back to invoices</a>
        </div>
      </div>
    </div>

    <?php if (!empty($errors)): ?>
      <div class="alert alert-danger">
        <strong>There were problems:</strong>
        <ul class="mb-0">
          <?php foreach ($errors as $err): ?>
            <li><?php echo h($err); ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <?php if ($send_result !== null && $sent_ok): ?>
      <div class="alert alert-success"><?php echo h($send_result); ?></div>
    <?php elseif ($send_result !== null && !$sent_ok): ?>
      <div class="alert alert-warning"><?php echo h($send_result); ?></div>
    <?php endif; ?>

    <div class="row g-4">
      <div class="col-lg-7">
        <div class="card p-3 preview fade-in" id="previewCard">
          <div class="d-flex justify-content-between align-items-start mb-2">
            <div>
              <h5 class="mb-0">Email preview</h5>
              <div class="muted small">This HTML will be sent as the email body and attached as PDF (if Dompdf is available).</div>
            </div>
            <div class="muted small text-end">
              To: <strong><?php echo h($inv['client_email'] ?: 'NO EMAIL'); ?></strong><br>
              <?php echo h($inv['client_name']); ?>
            </div>
          </div>

          <div class="border rounded p-3" style="background:#fff">
            <?php echo $email_html; ?>
          </div>

          <div class="mt-3 d-flex gap-2">
            <form method="post" onsubmit="return confirm('Send invoice email with attached PDF?');">
              <button type="submit" name="send_email" class="btn btn-primary"><i class="bi bi-envelope-fill"></i> Send invoice</button>
            </form>

            <a class="btn btn-outline-secondary" href="<?php echo APP_BASE; ?>invoices/download_pdf.php?id=<?php echo (int)$inv['id']; ?>" target="_blank"><i class="bi bi-download"></i> Download PDF</a>

            <a class="btn btn-outline-info" href="<?php echo APP_BASE; ?>invoices/view.php?id=<?php echo (int)$inv['id']; ?>" target="_blank"><i class="bi bi-eye"></i> Open live invoice</a>
          </div>
        </div>
      </div>

      <div class="col-lg-5">
        <div class="card p-3 fade-in" style="background:#fff;border-radius:12px">
          <h6>Message</h6>
          <p class="muted small">You can edit the message body in the source file if you want a different default message. The system will attach a PDF copy of the invoice when Dompdf is available.</p>

          <div class="mt-3">
            <div><strong>Invoice</strong> <?php echo h($inv['invoice_number'] ?? ('#'.$inv['id'])); ?></div>
            <div class="muted small">Amount: <?php echo h($symbol . ' ' . number_format((float)$inv['amount'],2)); ?></div>
            <div class="muted small">Client: <?php echo h($inv['client_name']); ?> (<?php echo h($inv['client_email']); ?>)</div>
          </div>

          <hr>

          <div>
            <h6>Mailer status</h6>
            <ul class="small muted">
              <li>Vendor/Composer: <?php echo $hasVendor ? 'available' : 'not installed'; ?></li>
              <li>Dompdf: <?php echo class_exists('\Dompdf\Dompdf') ? 'available' : 'not available'; ?></li>
              <li>PHPMailer: <?php echo class_exists('\PHPMailer\PHPMailer\PHPMailer') ? 'available' : 'not available'; ?></li>
              <li>send_mail helper: <?php echo $hasSendLib ? 'available' : 'not available'; ?></li>
            </ul>
            <div class="small text-muted">If SMTP is not configured for your local environment the send will fail. On production with proper SMTP credentials it should work.</div>
          </div>

        </div>

        <div class="card mt-3 p-3 fade-in" style="border-radius:12px;background:#fff">
          <h6 class="mb-2">Saved PDF (last generated)</h6>
          <?php
            $pdfDir = __DIR__ . '/../invoices_pdfs/';
            $lastPdf = null;
            if (is_dir($pdfDir)) {
                $pattern = $pdfDir . "invoice_*" . ($inv['invoice_number'] ?? $inv['id']) . "*";
                $files = glob($pattern) ?: [];
                if (!empty($files)) {
                    usort($files, function($a,$b){ return filemtime($b) - filemtime($a); });
                    $lastPdf = $files[0];
                }
            }
            if ($lastPdf && file_exists($lastPdf)):
                $webPath = APP_BASE . 'invoices_pdfs/' . basename($lastPdf);
          ?>
            <div class="small">Last saved PDF: <a href="<?php echo h($webPath); ?>" target="_blank"><?php echo h(basename($lastPdf)); ?></a></div>
          <?php else: ?>
            <div class="small muted">No saved PDF yet. Generating on send will save a copy.</div>
          <?php endif; ?>
        </div>

      </div>
    </div>

    <div class="text-center mt-4 muted small">Tip: when deploying to production, put SMTP credentials in your .env and consider background jobs for heavy email tasks.</div>

  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // small entrance animation trigger
    document.addEventListener('DOMContentLoaded', function(){
      document.querySelectorAll('.fade-in').forEach((el,i)=>{
        setTimeout(()=>el.classList.add('in'), 80 + i*80);
      });
    });
  </script>
</body>
</html>
